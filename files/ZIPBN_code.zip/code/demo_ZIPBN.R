# clear
rm(list = ls())
# set random seed
set.seed(202005)
# load necessary libraries
library(igraph)
library(pscl)
# load necessary functions
source("ZIPBNfunctions.R")

#----------------------------------------------------------------------------------------------------#
# simulate data
# set true parameters
n = 250   # sample size
p = 25    # number of node
A_true     = matrix(0, p, p)
alpha_true = matrix(0, p, p)
beta_true  = matrix(0, p, p)
delta_true = rep(0, p)
gamma_true = rep(0, p)

# generate a DAG with p edges
n_edge = p
while (sum(A_true == 1) < n_edge)
{
   id_edge = matrix(sample(1 : p, 2), ncol = 2)
   A_true[id_edge] = 1
   g_true = graph_from_adjacency_matrix(t(A_true))
   if (!(is_dag(g_true)))
      A_true[id_edge] = 0
}

alpha_true[A_true == 1] = runif(n_edge, 0.3, 1)
beta_true[A_true == 1]  = runif(n_edge, -1, -0.3)
delta_true[ ] = runif(p, -2, -1)
gamma_true[ ] = runif(p, 1, 2)

# generate a dataset
data = matrix(0, n, p)
order_nodes = as_ids(topo_sort(g_true))
for (j in order_nodes)
{
   pi = exp(data %*% alpha_true[j, ] + delta_true[j])
   pi = pi / (1 + pi)
   pi[is.nan(pi)] = 1
   lambda  = exp(data %*% beta_true[j, ] + gamma_true[j])
   data[ , j] = rpois(n, lambda) * (1 - rbinom(n, 1, pi))
}
table(data) 
mean(data == 0)   # proportion of zeros

#----------------------------------------------------------------------------------------------------#
# run the parallel-tempered MCMC for ZIPBN
# need for our MCMC implementation
MCMC      = 3000                 # number of MCMC iterations
BURNIN    = 1500                 # burn-in
prob_swap = 0.1                  # probability of the swapping step
p_adaptMH = 0.25                 # a multiplier for self-adaptation of the MH-proposal step size
n = nrow(data); p = ncol(data)   # sample size and node size

# hyperparameters for priors
priors = list()
priors$alpha = c(0.01, 0.01)
priors$beta  = c(0.01, 0.01)
priors$delta = c(0.01, 0.01)
priors$gamma = c(0.01, 0.01)
priors$A     = c(0.5, 0.5)

# starting values for MCMC
starting = list()
starting$alpha = matrix(0, p, p)
starting$beta  = matrix(0, p, p)
starting$delta = rep(0, p)
starting$gamma = rep(0, p)
starting$A     = matrix(0, p, p)
starting$tau   = c(10, 10, 1, 1)
starting$rho   = 1 / p
for (j in 1 : p)
{
   mle = zeroinfl(data[ , j] ~ 1 | 1, dist = "poisson")
   starting$delta[j] = mle$coefficients$zero
   starting$gamma[j] = mle$coefficients$count
}

# calculate logitPi and logLambda for each group with starting values
starting$logitPi   = tcrossprod(data, starting$alpha) + matrix(starting$delta, n, p, byrow = TRUE)
starting$logLambda = tcrossprod(data, starting$beta) + matrix(starting$gamma, n, p, byrow = TRUE)

# necessary objects for the parallel tempering
n_chains = 10
temps    = exp(seq(0, 1, length.out = n_chains))

# sd of the Metropolis sampler Normal proposal distribution
tuning = list()
for (m in 1 : n_chains)
{
   tuning[[m]] = list()
   tuning[[m]]$sigma_alpha = 1.0  * ((1.1)^(m - 1))
   tuning[[m]]$sigma_beta  = 0.5  * ((1.1)^(m - 1))
   tuning[[m]]$sigma_delta = 0.6  * ((1.1)^(m - 1))
   tuning[[m]]$sigma_gamma = 0.2 * ((1.1)^(m - 1))
   tuning[[m]]$sigma_A     = c(0.05, 0.05, 0.6, 0.2)
   tuning[[m]]$sigma_A_rev = c(0.5, 0.5, 1.2, 0.4) 
}


# initialize MCMC samples
mcmc_samples = list()
for (m in 1 : n_chains)
{
   mcmc_samples[[m]] = list()
   mcmc_samples[[m]]$alpha = array(NA, dim = c(p, p, MCMC))
   mcmc_samples[[m]]$beta  = array(NA, dim = c(p, p, MCMC))
   mcmc_samples[[m]]$delta = matrix(NA, p, MCMC)
   mcmc_samples[[m]]$gamma = matrix(NA, p, MCMC)
   mcmc_samples[[m]]$A     = array(NA, dim = c(p, p, MCMC))
   mcmc_samples[[m]]$tau   = matrix(NA, 4, MCMC)
   mcmc_samples[[m]]$rho   = rep(NA, MCMC)
}

# initialize acceptance indicators
acceptance = list()
for (m in 1 : n_chains)
{
   acceptance[[m]] = list()
   acceptance[[m]]$alpha = array(NA, dim = c(p, p, MCMC))
   acceptance[[m]]$beta  = array(NA, dim = c(p, p, MCMC))
   acceptance[[m]]$delta = matrix(NA, p, MCMC)
   acceptance[[m]]$gamma = matrix(NA, p, MCMC)
}

# initialize parameters
param = list()
for (m in 1 : n_chains)
{
   param[[m]] = starting
}

# run MCMC iterations
out = list()
for (t in 1 : MCMC)
{
   if (runif(1) > prob_swap)
   {
      # perform one-step update for all chains 
      for (m in 1 : n_chains)
      {
         # update each chain
         out[[m]] = update_chain(data, param[[m]], tuning[[m]], priors, temps[m])
         
         # save MCMC samples
         param[[m]] = out[[m]]$param
         mcmc_samples[[m]]$alpha[ , , t] = param[[m]]$alpha
         mcmc_samples[[m]]$beta[ , , t]  = param[[m]]$beta
         mcmc_samples[[m]]$delta[ , t]   = param[[m]]$delta
         mcmc_samples[[m]]$gamma[ , t]   = param[[m]]$gamma
         mcmc_samples[[m]]$A[ , , t]     = param[[m]]$A
         mcmc_samples[[m]]$tau[ , t]     = param[[m]]$tau
         mcmc_samples[[m]]$rho[t]        = param[[m]]$rho
         
         # save acceptance rates
         acceptance[[m]]$alpha[ , , t] = out[[m]]$acceptance$alpha
         acceptance[[m]]$beta[ , , t]  = out[[m]]$acceptance$beta
         acceptance[[m]]$delta[ , t]   = out[[m]]$acceptance$delta
         acceptance[[m]]$gamma[ , t]   = out[[m]]$acceptance$gamma
      }
   }
   else
   {
      # propose a swapping move
      # randomly choose chains to swap
      rand = sort(sample(1 : n_chains, 2))
      m1   = rand[1]
      m2   = rand[2]
      
      # calculate the MH ratio for swapping
      ratio_swap = log_dZIPBN(data, param[[m1]], priors, temps[m2]) + 
         log_dZIPBN(data, param[[m2]], priors, temps[m1]) -
         log_dZIPBN(data, param[[m1]], priors, temps[m1]) - 
         log_dZIPBN(data, param[[m2]], priors, temps[m2])
      ratio_swap = exp(ratio_swap)

      # accept swapping
      if (is.nan(ratio_swap)) ratio_swap = 0
      if (runif(1) < min(1, ratio_swap))
      {
         cat("swap the states of chains", m1, "and", m2, "\n")
         param_m1    = param[[m1]]
         param[[m1]] = param[[m2]]
         param[[m2]] = param_m1
      }   
      
      # save MCMC samples
      for (m in 1 : n_chains)
      {
         mcmc_samples[[m]]$alpha[ , , t] = param[[m]]$alpha
         mcmc_samples[[m]]$beta[ , , t]  = param[[m]]$beta
         mcmc_samples[[m]]$delta[ , t]   = param[[m]]$delta
         mcmc_samples[[m]]$gamma[ , t]   = param[[m]]$gamma
         mcmc_samples[[m]]$A[ , , t]     = param[[m]]$A
         mcmc_samples[[m]]$tau[ , t]     = param[[m]]$tau
         mcmc_samples[[m]]$rho[t]        = param[[m]]$rho
      }
   }
   
   # self-adaptation of the MH-proposal step size
   if (t %% 100 == 0) 
   {
      for (m in 1 : n_chains)
      {
         if (!is.nan(mean(acceptance[[m]]$alpha[ , , max(1, t - 500) : t], na.rm = TRUE)))
         {
            if (mean(acceptance[[m]]$alpha[ , , max(1, t - 500) : t], na.rm = TRUE) < 0.2)
               tuning[[m]]$sigma_alpha = tuning[[m]]$sigma_alpha * (1 - p_adaptMH)
            else if (mean(acceptance[[m]]$alpha[ , , max(1, t - 500) : t], na.rm = TRUE) > 0.7)
               tuning[[m]]$sigma_alpha = tuning[[m]]$sigma_alpha * (1 + p_adaptMH)
         }
         
         if (!is.nan(mean(acceptance[[m]]$beta[ , , max(1, t - 500) : t], na.rm = TRUE)))
         {
            if (mean(acceptance[[m]]$beta[ , , max(1, t - 500) : t], na.rm = TRUE) < 0.2)
               tuning[[m]]$sigma_beta = tuning[[m]]$sigma_beta * (1 - p_adaptMH)
            else if (mean(acceptance[[m]]$beta[ , , max(1, t - 500) : t], na.rm = TRUE) > 0.7)
               tuning[[m]]$sigma_beta = tuning[[m]]$sigma_beta * (1 + p_adaptMH)
         }
         
         if (mean(acceptance[[m]]$delta[ , max(1, t - 500) : t], na.rm = TRUE) < 0.2)
            tuning[[m]]$sigma_delta = tuning[[m]]$sigma_delta * (1 - p_adaptMH)
         else if (mean(acceptance[[m]]$delta[ , max(1, t - 500) : t], na.rm = TRUE) > 0.7)
            tuning[[m]]$sigma_delta = tuning[[m]]$sigma_delta * (1 + p_adaptMH)
         
         if (mean(acceptance[[m]]$gamma[ , max(1, t - 500) : t], na.rm = TRUE) < 0.2)
            tuning[[m]]$sigma_gamma = tuning[[m]]$sigma_gamma * (1 - p_adaptMH)
         else if (mean(acceptance[[m]]$gamma[ , max(1, t - 500) : t], na.rm = TRUE) > 0.7)
            tuning[[m]]$sigma_gamma = tuning[[m]]$sigma_gamma * (1 + p_adaptMH)
      }
   }
   
   # print progress
   if (t %% 100 == 0)
      cat("iter =", t, "\n")
}

#----------------------------------------------------------------------------------------------------#
# summarize the MCMC results 
# choose the cold chain
m = 1

# show acceptance rates
mean(acceptance[[m]]$alpha, na.rm = TRUE)
mean(acceptance[[m]]$beta, na.rm = TRUE)
mean(acceptance[[m]]$delta, na.rm = TRUE)
mean(acceptance[[m]]$gamma, na.rm = TRUE)

# burn-in
A_MCMC     = mcmc_samples[[m]]$A[ , , (BURNIN + 1) : MCMC]
alpha_MCMC = mcmc_samples[[m]]$alpha[ , , (BURNIN + 1) : MCMC]
beta_MCMC  = mcmc_samples[[m]]$beta[ , , (BURNIN + 1) : MCMC]
delta_MCMC = mcmc_samples[[m]]$delta[ , (BURNIN + 1) : MCMC]
gamma_MCMC = mcmc_samples[[m]]$gamma[ , (BURNIN + 1) : MCMC]
tau_MCMC   = mcmc_samples[[m]]$tau[ , (BURNIN + 1) : MCMC]
rho_MCMC   = mcmc_samples[[m]]$rho[(BURNIN + 1) : MCMC]

# estimate ZIPBN parameters based on the MCMC samples
A_est     = (apply(A_MCMC, c(1, 2), mean) > 0.5) + 0
alpha_est = apply(alpha_MCMC, c(1, 2), mean) * A_est
beta_est  = apply(beta_MCMC, c(1, 2), mean) * A_est
delta_est = rowMeans(delta_MCMC)
gamma_est = rowMeans(gamma_MCMC)
tau_est   = rowMeans(tau_MCMC)
rho_est   = mean(rho_MCMC)

# calculate TPR, FDR, and MCC for the network estimate
tbl_net = table(A_est, A_true)
tbl_net
TP  = tbl_net[2, 2]
TN  = tbl_net[1, 1]
FP  = tbl_net[2, 1]
FN  = tbl_net[1, 2]
TPR = TP / (TP + FN)
TPR
FDR = FP / (FP + TP)
FDR
MCC = (TP * TN - FP * FN) / sqrt(TP + FP) / sqrt(TP + FN) / sqrt(TN + FP) / sqrt(TN + FN)
MCC

# plot the network estimate
G_est = graph_from_adjacency_matrix(t(A_est))
par(mar=c(0, 0, 0, 0))
plot.igraph(G_est, vertex.shape = "none",vertex.size = 15, vertex.label.cex = 1.2,  
            edge.color = "black", edge.width = 0.5, edge.arrow.size = 0.5, 
            margin = 0, asp = 0.6)
