clear
%load seed1
load('GR.mat')
ind=logical(sum(G_est,3));

vv_est=v0_est.*(abs(v0_est)>repmat(repmat(t_est',n,1),1,1,p));
[I,J,K]=ind2sub(size(ln_est),find(ln_est));
inds = [I,J,K];

nfr = length(I);

Grate_vec = G_rate(:);
v0_est_vec = v0_est(:);
v0_upper_vec = v0_upper(:);
v0_lower_vec = v0_lower(:);
inds = inds(1:nfr,:);
lnrate_vec=lnrate(:);
save('Grate.txt','Grate_vec','-ascii')
save('v0_est.txt','v0_est_vec','-ascii')
save('v0_upper.txt','v0_upper_vec','-ascii')
save('v0_lower.txt','v0_lower_vec','-ascii')
save('inds.txt','inds','-ascii')
save('lnrate.txt','lnrate_vec','-ascii')
