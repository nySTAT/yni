function GR()

tmp = csvread('parameter.csv');
y = csvread('y.csv'); % n x p matrix
x = csvread('x.csv'); % n x q matrix of continuous covariates
z = csvread('z.csv'); % n x r matrix of discrete covariates
o = csvread('o.csv'); % p-dim vector of ordering

y = y(:,o);

if size(z,1)==1
    z=[];
end
if size(x,1)==1
    x=[];
end

N=tmp(1); % number of MCMC iterations
seed=tmp(2); % random seed
Np = 2;
Npo=N/10;
thin = 5;
burnin = floor(N/2);
cutoff=0.5;

n = size(y,1);
p = size(y,2);
q = size(x,2);
r = size(z,2);

tic;
v_est = zeros(n,p,p);
v_upper=v_est;
v_lower=v_est;
v0_est=v_est;
v0_upper=v_est;
v0_lower=v_est;
G_est = zeros(n,p,p);
betax_est = zeros(q,p,p);
betaX_est = cell(p,1);
betaZ_est = cell(p,1);
betamu_est = cell(p,1);
lin_est = zeros(q,p,p);
nlin_est = zeros(q,p,p);
ln_est = zeros(q,p,p);
categ_est = zeros(r,p,p);
G_rate = G_est;
linrate = lin_est;
nlinrate = nlin_est;
lnrate = ln_est;
categrate = categ_est;
const_est = zeros(p,p);
constrate = const_est;
t_est = zeros(p,1);
sigma_est = zeros(p,1);
ac_eta = zeros(p,1);
ac_eta2 = zeros(p,1);
ac_t = zeros(p,1);
ac_xi = zeros(p,1);

for i =1:p-1
    fprintf('==================================\n')
    fprintf('computing on %d th regression\n',i)
    fprintf('==================================\n')
    [lin_est0,nlin_est0,ln_est0,categ_est0,const_est0,~,linrate0,nlinrate0,lnrate0,categrate0,constrate0,ac_eta0,ac_eta20,ac_t0,ac_xi0,~,~,~,~,~,~,~,~,~,~,~]=CdregOrth_pilot(y(:,i),y(:,i+1:end),x,z,cutoff,N,thin,burnin,Np,seed);
    [betax_est0,betaX_est0,betaZ_est0,betamu_est0,~,~,~,~,v0_est0,v0_upper0,v0_lower0,v_est0,v_upper0,v_lower0,urate0,u_est0,~,~,~,~,~,~,~,~,~,t_est0,sigma_est0]=postMCMC(y(:,i),y(:,i+1:end),x,z,cutoff,[],[],[],lin_est0,nlin_est0,categ_est0,const_est0,Npo,floor(Npo/10),seed);
    %[v_est0,v0_est0,u_est0,betax_est0,betaX_est0,betaZ_est0,betamu_est0,lin_est0,nlin_est0,ln_est0,categ_est0,const_est0,ypred0,v_pred0,u_pred0,urate0,linrate0,nlinrate0,lnrate0,categrate0,constrate0,u_pred_rate0,t_est0,sigma_est0,countv0,countx0,countX0,countZ0,countmu0,countv_pred0,ac_eta0,ac_eta20,ac_t0,ac_xi0,~,~,~,~,~,~,~,~,~,~,~,~,~]=CdregOrth_pilot(y(:,i)*ystd(i),y(:,i+1:end),x,z,cutoff,yt(:,i+1:end),xt,zt,N,thin,burnin,Np,seed);
    %[v0_est0,v0_upper0,v0_lower0]=postMCMC(y(:,i)*ystd(i),y(:,i+1:end),x,z,cutoff,lin_est0,nlin_est0,categ_est0,const_est0,Npo,floor(Npo/10),seed);
    G_est(:,i,i+1:end) = u_est0;
    G_rate(:,i,i+1:end) = urate0;
    
    v_est(:,i,i+1:end) = v_est0;
    v_upper(:,i,i+1:end) = v_upper0;
    v_lower(:,i,i+1:end) = v_lower0;
    v0_est(:,i,i+1:end) = v0_est0;
    v0_upper(:,i,i+1:end) = v0_upper0;
    v0_lower(:,i,i+1:end) = v0_lower0;
    betax_est(:,i,i+1:end) = betax_est0;
    betaX_est{i} = betaX_est0;
    betaZ_est{i} = betaZ_est0;
    betamu_est{i} = betamu_est0;
    lin_est(:,i,i+1:end) = lin_est0;
    nlin_est(:,i,i+1:end) = nlin_est0;
    ln_est(:,i,i+1:end) = ln_est0;
    categ_est(:,i,i+1:end) = categ_est0;
    linrate(:,i,i+1:end) = linrate0;
    nlinrate(:,i,i+1:end) = nlinrate0;
    lnrate(:,i,i+1:end) = lnrate0;
    categrate(:,i,i+1:end) = categrate0;
    const_est(i,i+1:end)=const_est0;
    constrate(i,i+1:end)=constrate0;
    t_est(i) = t_est0;
    sigma_est(i) = sigma_est0;
    ac_eta(i) = ac_eta0;
    ac_eta2(i) = ac_eta20;
    ac_t(i) = ac_t0;
    ac_xi(i) = ac_xi0;
end
time=toc;
%ro(o) = 1:p;
%for i = 1:q
%    ln_est(i,:,:) = triu(logical(squeeze(ln_est(i,ro,ro))+squeeze(ln_est(i,ro,ro))'));
%end
%for i = 1:r
%    categ_est(i,:,:) = triu(logical(squeeze(categ_est(i,ro,ro))+squeeze(categ_est(i,ro,ro))'));
%end
%for i = 1:n
%    u_est(i,:,:) = triu(logical(squeeze(u_est(i,ro,ro))+squeeze(u_est(i,ro,ro))'));
%end

save('GR.mat');

