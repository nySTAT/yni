function [lin_est,nlin_est,ln_est,categ_est,const_est,urate,linrate,nlinrate,lnrate,categrate,constrate,ac_eta,ac_eta2,ac_t,ac_xi,betax,betaX,betaZ,betamu,const,lin,nlin,ln,categ,t,sigma]=CdregOrth_pilot(y,u,x,z,cutoff,N,thin,burnin,Np,seed)
%%
%varying coefficients regression with thresholding and reduced rank
%orthogonal basis matrix

%u_est: the structure of v_est, logical(v_est)

%proposal parameters
[etax_old,etaX_old,etaZ_old,etamu_old,xix_old,xiX_old,xiZ_old,ximu_old,betax_old,betaX_old,betaZ_old,betamu_old,gammax_old,gammaX_old,gammaZ_old,gammamu_old,taux_old,tauX_old,tauZ_old,taumu_old,sigma_old,omega_old]=CdregOrth_Gibbs(y,u,x,z,Np,seed);
%tic;
t_sd = .15;%0.075
%eta_sd = .1;
eta_sd2 = .2;
xi_sd = 0.5;
%mu_sd = 0.03;
rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end

[n,p]=size(u);
q = size(x,2);
r = size(z,2);


%design matrix
inte = ones(n,1)/sqrt(n);%intercept
%categorical
Z = double.empty(n,0);
Zind = [];
zmean = [];
zscale = [];
for i =1:r
    Ztmp = dummyvar(z(:,i));
    Ztmp = Ztmp(:,2:end);
    zmean = [zmean,mean(Ztmp)];
    Ztmp = Ztmp-repmat(mean(Ztmp),n,1);
    %zscale = [zscale,norm(Ztmp,'fro')*sqrt(n)/2*ones(1,size(Ztmp,2))];
    %Ztmp = Ztmp/norm(Ztmp,'fro')*sqrt(n)/2;
    zscale = [zscale,norm(Ztmp,'fro')*ones(1,size(Ztmp,2))];
    Ztmp = Ztmp/norm(Ztmp,'fro');
    Z = [Z,Ztmp];
    Zind = [Zind;i*ones(size(Ztmp,2),1)];
end
%continuous
order = 4; %order of splines
nknots = 16; %number of interior knots
M = order + nknots;
xx=bspline_quantileknots(order,nknots,x,x);
%xx = xx-repmat(mean(xx),[n,1]);
K = makeK(M);
Kinv = pinv(K);
X = double.empty(n,0);
Xind =[];
%x= x-repmat(mean(x),[n,1]);
for i = 1:q
    Xtmp = xx(:,(i-1)*M+1:i*M);
    [U,S,~]=svd(Xtmp*Kinv*Xtmp','econ');
    S = diag(S);
    nullvals = S < 10^-10;
    d = max(3, find( cumsum(S(~nullvals))/sum(S(~nullvals)) > .995 ,1));
    d = min(d, sum(~nullvals));
    Xtmp = U(:,1:d)*diag(sqrt(S(1:d)));
    Xtmp2 = [ones(n,1),x(:,i)];
    Xtmp = Xtmp- Xtmp2*(Xtmp2\Xtmp);
    Xtmp = Xtmp/norm(Xtmp,'fro');
    x(:,i) = x(:,i)-mean(x(:,i));
    x(:,i) = x(:,i)/norm(x(:,i),'fro');
    X = [X,Xtmp];
    Xind = [Xind;i*ones(size(Xtmp,2),1)];
end

%W=[x,X,Z];
dX = size(X,2);
dZ = size(Z,2);
%parameter
a_t = 0; b_t = 1;%uniform prior for t
a = 10^-4; b = 10^-4;%IG prior for sigma
a_tau = 5; b_tau = 100;
s0 = 2.5*10^-4;
a_w = 1/2;b_w=1/2;
%sigma_mu = 100;
%initialize
%beta0 = zeros(n,p,(N-burnin)/thin);%\tilde{beta}
%beta = zeros(n,p,(N-burnin)/thin);
%eta = zeros(qr,p,(N-burnin)/thin);
%etax = zeros(q,p,(N-burnin)/thin);
%etaX = zeros(q,p,(N-burnin)/thin);
%etaZ = zeros(r,p,(N-burnin)/thin);
% etax_old = .1*randn(q,p);
% etaX_old = .1*randn(q,p);
% etaZ_old = .1*randn(r,p);
% etamu_old = .1*randn(p,1);
%xi = zeros(q+dX+dZ,p,(N-burnin)/thin);
%xix = zeros(q,p,(N-burnin)/thin);
%xiX = zeros(dX,p,(N-burnin)/thin);
%xiZ = zeros(dZ,p,(N-burnin)/thin);
% xix_old = .1*randn(q,p);
% xiX_old = .1*randn(dX,p);
% xiZ_old = .1*randn(dZ,p);
% ximu_old = .1*randn(p,1);
%beta = zeros(q+dX+dZ,p,(N-burnin)/thin);
betax = zeros(q,p,(N-burnin)/thin);
betaX = zeros(dX,p,(N-burnin)/thin);
betaZ = zeros(dZ,p,(N-burnin)/thin);
betamu = zeros(p,(N-burnin)/thin);
% betax_old = etax_old.*xix_old;
% betaX_old = etaX_old(Xind,:).*xiX_old;
% betaZ_old = etaZ_old(Zind,:).*xiZ_old;
% betamu_old = etamu_old.*ximu_old;
% for i = 1:q
%     xibar=mean(abs(xix_old(i,:)),1);
%     etax_old(i,:) = etax_old(i,:).*xibar;
%     xix_old(i,:) = xix_old(i,:)./xibar;
%     xibar=mean(abs(xiX_old(Xind==i,:)),1);
%     etaX_old(i,:) = etaX_old(i,:).*xibar;
%     xiX_old(Xind==i,:) = xiX_old(Xind==i,:)./repmat(xibar,[sum(Xind==i),1]);
%     xibar=mean(abs(xiZ_old(Zind==i,:)),1);
%     etaZ_old(i,:) = etaZ_old(i,:).*xibar;
%     xiZ_old(Zind==i,:) = xiZ_old(Zind==i,:)./repmat(xibar,[sum(Zind==i),1]);
% end
% etamu_old = etamu_old.*abs(ximu_old);
% ximu_old = ximu_old./abs(ximu_old);
% mx = zeros(q,p,(N-burnin)/thin);
% mX = zeros(dX,p,(N-burnin)/thin);
% mZ = zeros(dZ,p,(N-burnin)/thin);
%mu = zeros(p,(N-burnin)/thin);
sigma = ones((N-burnin)/thin,1);%sigma^2
t = zeros((N-burnin)/thin,1);
t_old=t(1);
%tau = zeros(qr,p,(N-burnin)/thin);
% taux= ones(q,p,(N-burnin)/thin);
% tauX = ones(q,p,(N-burnin)/thin);
% tauZ = ones(r,p,(N-burnin)/thin);
%gamma = zeros(qr,p,(N-burnin)/thin);
gammax= s0*ones(q,p,(N-burnin)/thin);
gammaX = s0*ones(q,p,(N-burnin)/thin);
gammaZ = s0*ones(r,p,(N-burnin)/thin);
gammamu = s0*ones(p,(N-burnin)/thin);
%omega = ones((N-burnin)/thin,1);
v = zeros(n,p,(N-burnin)/thin);
v0 = zeros(n,p,(N-burnin)/thin);
ac_eta=0;
ac_eta2=0;
ac_xi =0;
ac_t=0;
%ac_mu=0;

%eta_old = eta(:,:,1);
% etax_old = etax(:,:,1);
% etaX_old = etaX(:,:,1);
% etaZ_old = etaZ(:,:,1);
% %xi_old = xi(:,:,1);
% xix_old = xix(:,:,1);
% xiX_old = xiX(:,:,1);
% xiZ_old = xiZ(:,:,1);
% %beta_old = beta(:,:,1);
% betax_old = betax(:,:,1);
% betaX_old = betaX(:,:,1);
% betaZ_old = betaZ(:,:,1);
%mu_old = mu(:,1);
% sigma_old = sigma(1);
% taux_old = ones(q,p);
% tauX_old = ones(q,p);
% tauZ_old = ones(r,p);
% taumu_old = ones(p,1);
% gammax_old = gammax(:,:,1);
% gammaX_old = gammaX(:,:,1);
% gammaZ_old = gammaZ(:,:,1);
% gammamu_old = gammamu(:,1);
% omega_old = .2;
%t_old = t(1);
regressor_old=zeros(n,p);
for j = 1:p
    regressor_old(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_old(:,j)+X*betaX_old(:,j)+Z*betaZ_old(:,j),t_old);
end
%algorithm begins
%tic;
ll_old = loglike(y,regressor_old,sigma_old);
iter=0;
for mc = 2:N
    %update eta
    if 0;%mod(mc,2)==0 %update in blocks
        for j = 1:p
            regressor_new = regressor_old;
            etax_new = etax_old(:,j) + eta_sd*randn(q,1);
            betax_new = etax_new.*xix_old(:,j);
            etaX_new = etaX_old(:,j) + eta_sd*randn(q,1);
            betaX_new = etaX_new(Xind).*xiX_old(:,j);
            etaZ_new = etaZ_old(:,j) + eta_sd*randn(r,1);
            betaZ_new = etaZ_new(Zind).*xiZ_old(:,j);
            etamu_new = etamu_old(j) + eta_sd*randn(1);
            betamu_new = etamu_new.*ximu_old(j);
            regressor_new(:,j) = u(:,j).*threshold(betamu_new*inte+x*betax_new+X*betaX_new+Z*betaZ_new,t_old);
            ll_new = loglike(y,regressor_new,sigma_old);
            lr = ll_new-ll_old-.5*(sum(etax_new.^2./gammax_old(:,j)./taux_old(:,j))...
                +sum(etaX_new.^2./gammaX_old(:,j)./tauX_old(:,j))+sum(etaZ_new.^2./gammaZ_old(:,j)./tauZ_old(:,j))+sum(etamu_new^2/gammamu_old(j)/taumu_old(j)))...
                +.5*(sum(etax_old(:,j).^2./gammax_old(:,j)./taux_old(:,j))...
                +sum(etaX_old(:,j).^2./gammaX_old(:,j)./tauX_old(:,j))+sum(etaZ_old(:,j).^2./gammaZ_old(:,j)./tauZ_old(:,j))+sum(etamu_old(j))^2/gammamu_old(j)/taumu_old(j));
            if lr > log(rand(1))
                ac_eta = ac_eta+1;
                ll_old=ll_new;
                etax_old(:,j) = etax_new;
                betax_old(:,j) = betax_new;
                etaX_old(:,j) = etaX_new;
                betaX_old(:,j) = betaX_new;
                etaZ_old(:,j) = etaZ_new;
                betaZ_old(:,j) = betaZ_new;
                etamu_old(j) = etamu_new;
                betamu_old(j) = betamu_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    else %update element-by-element
        for i = 1:q
            for j = 1:p
                regressor_new = regressor_old;
                etax_new = etax_old(:,j);
                etax_new(i) = etax_old(i,j) + eta_sd2*randn(1);
                betax_new = etax_new.*xix_old(:,j);
                regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_new+X*betaX_old(:,j)+Z*betaZ_old(:,j),t_old);
                ll_new = loglike(y,regressor_new,sigma_old);
                lr = ll_new-ll_old-.5*(etax_new(i).^2./gammax_old(i,j)./taux_old(i,j))...
                    +.5*(etax_old(i,j).^2./gammax_old(i,j)./taux_old(i,j));
                if lr > log(rand(1))
                    ac_eta2 = ac_eta2+1;
                    ll_old=ll_new;
                    etax_old(i,j) = etax_new(i);
                    betax_old(:,j) = betax_new;
                    regressor_old(:,j) = regressor_new(:,j);
                end
            end
        end
        for i = 1:q
            for j = 1:p
                regressor_new = regressor_old;
                etaX_new = etaX_old(:,j);
                etaX_new(i) = etaX_old(i,j) + eta_sd2*randn(1);
                betaX_new = etaX_new(Xind).*xiX_old(:,j);
                regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_old(:,j)+X*betaX_new+Z*betaZ_old(:,j),t_old);
                ll_new = loglike(y,regressor_new,sigma_old);
                lr = ll_new-ll_old-.5*(etaX_new(i).^2./gammaX_old(i,j)./tauX_old(i,j))...
                    +.5*(etaX_old(i,j).^2./gammaX_old(i,j)./tauX_old(i,j));
                if lr > log(rand(1))
                    ac_eta2 = ac_eta2+1;
                    ll_old=ll_new;
                    etaX_old(i,j) = etaX_new(i);
                    betaX_old(:,j) = betaX_new;
                    regressor_old(:,j) = regressor_new(:,j);
                end
            end
        end
        for i = 1:r
            for j = 1:p
                regressor_new = regressor_old;
                etaZ_new = etaZ_old(:,j);
                etaZ_new(i) = etaZ_old(i,j) + eta_sd2*randn(1);
                betaZ_new = etaZ_new(Zind).*xiZ_old(:,j);
                regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_old(:,j)+X*betaX_old(:,j)+Z*betaZ_new,t_old);
                ll_new = loglike(y,regressor_new,sigma_old);
                lr = ll_new-ll_old-.5*(etaZ_new(i).^2./gammaZ_old(i,j)./tauZ_old(i,j))...
                    +.5*(etaZ_old(i,j).^2./gammaZ_old(i,j)./tauZ_old(i,j));
                if lr > log(rand(1))
                    ac_eta2 = ac_eta2+1;
                    ll_old=ll_new;
                    etaZ_old(i,j) = etaZ_new(i);
                    betaZ_old(:,j) = betaZ_new;
                    regressor_old(:,j) = regressor_new(:,j);
                end
            end
        end
        for j = 1:p
            regressor_new = regressor_old;
            etamu_new = etamu_old(j) + eta_sd2*randn(1);
            betamu_new = etamu_new.*ximu_old(j);
            regressor_new(:,j) = u(:,j).*threshold(betamu_new*inte+x*betax_old(:,j)+X*betaX_old(:,j)+Z*betaZ_old(:,j),t_old);
            ll_new = loglike(y,regressor_new,sigma_old);
            lr = ll_new-ll_old-.5*(etamu_new.^2./gammamu_old(j)./taumu_old(j))...
                +.5*(etamu_old(j).^2./gammamu_old(j)./taumu_old(j));
            if lr > log(rand(1))
                ac_eta2 = ac_eta2+1;
                ll_old=ll_new;
                etamu_old(j) = etamu_new;
                betamu_old(j) = betamu_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    %betax_old = etax_old;
    
    %update
    mx_old=2*binornd(1,1./(1+exp(-2*xix_old)))-1;
    mX_old=2*binornd(1,1./(1+exp(-2*xiX_old)))-1;
    mZ_old=2*binornd(1,1./(1+exp(-2*xiZ_old)))-1;
    mmu_old=2*binornd(1,1./(1+exp(-2*ximu_old)))-1;
%     mx_old=mx_old*0;
%     mX_old=mX_old*0;
%     mZ_old=mZ_old*0;
%     mmu_old=mmu_old*0;
    
    %update xi
    for j = 1:p
        regressor_new = regressor_old;
        xix_new = xix_old(:,j) + xi_sd*randn(q,1);
        betax_new = etax_old(:,j).*xix_new;
        xiX_new = xiX_old(:,j) + xi_sd*randn(dX,1);
        betaX_new = etaX_old(Xind,j).*xiX_new;
        xiZ_new = xiZ_old(:,j) + xi_sd*randn(dZ,1);
        betaZ_new = etaZ_old(Zind,j).*xiZ_new;
        ximu_new = ximu_old(j) + xi_sd*randn(1);
        betamu_new = etamu_old(j).*ximu_new;
        regressor_new(:,j) = u(:,j).*threshold(betamu_new*inte+x*betax_new+X*betaX_new+Z*betaZ_new,t_old);
        ll_new = loglike(y,regressor_new,sigma_old);
        lr = ll_new-ll_old-.5*(sum(sum((xix_new-mx_old(:,j)).^2))+sum(sum((xiX_new-mX_old(:,j)).^2))+sum(sum((xiZ_new-mZ_old(:,j)).^2))+sum((ximu_new-mmu_old(j)).^2))...
            +.5*(sum(sum((xix_old(:,j)-mx_old(:,j)).^2))+sum(sum((xiX_old(:,j)-mX_old(:,j)).^2))+sum(sum((xiZ_old(:,j)-mZ_old(:,j)).^2))+sum((ximu_old(j)-mmu_old(j)).^2));
        if lr > log(rand(1))
            ac_xi = ac_xi+1;
            ll_old=ll_new;
            xix_old(:,j) = xix_new;
            betax_old(:,j) = betax_new;
            xiX_old(:,j) = xiX_new;
            betaX_old(:,j) = betaX_new;
            xiZ_old(:,j) = xiZ_new;
            betaZ_old(:,j) = betaZ_new;
            ximu_old(j) = ximu_new;
            betamu_old(j) = betamu_new;
            regressor_old(:,j) = regressor_new(:,j);
        end
    end
    
    
    %rescale eta and xi
    
    for i = 1:q
        xibar=mean(abs(xix_old(i,:)),1);
        etax_old(i,:) = etax_old(i,:).*xibar;
        xix_old(i,:) = xix_old(i,:)./xibar;
        xibar=mean(abs(xiX_old(Xind==i,:)),1);
        etaX_old(i,:) = etaX_old(i,:).*xibar;
        xiX_old(Xind==i,:) = xiX_old(Xind==i,:)./repmat(xibar,[sum(Xind==i),1]);
    end
    for i = 1:r
        xibar=mean(abs(xiZ_old(Zind==i,:)),1);
        etaZ_old(i,:) = etaZ_old(i,:).*xibar;
        xiZ_old(Zind==i,:) = xiZ_old(Zind==i,:)./repmat(xibar,[sum(Zind==i),1]);
    end
    etamu_old = etamu_old.*abs(ximu_old);
    ximu_old = ximu_old./abs(ximu_old);
    
    %update mu
    
    %     mu_new = mu_old + mu_sd*randn(p,1);
    %     regressor_new = u.*threshold(repmat(mu_new',[n,1])+x*betax_old+X*betaX_old+Z*betaZ_old,t_old,tm);
    %     ll_new = loglike(y,regressor_new,sigma_old);
    %     lr = ll_new-ll_old-.5*sum(mu_new.^2)/sigma_mu+.5*sum(mu_old.^2)/sigma_mu;
    %     if lr>log(rand(1))
    %         ac_mu = ac_mu + 1;
    %         mu_old = mu_new;
    %         regressor_old = regressor_new;
    %     end
    
    %     for j =1:p
    %         regressor_new = regressor_old;
    %         mu_new = mu_old(j)+mu_sd*randn(1);
    %         regressor_new(:,j) = u(:,j).*threshold(mu_new+x*betax_old(:,j)+X*betaX_old(:,j)+Z*betaZ_old(:,j),t_old,tm);
    %         ll_new = loglike(y,regressor_new,sigma_old);
    %         lr = ll_new-ll_old-.5*(mu_new^2)/sigma_mu+.5*(mu_old(j)^2)/sigma_mu;
    %         if lr>log(rand(1))
    %             ac_mu = ac_mu + 1;
    %             mu_old(j) = mu_new;
    %             regressor_old(:,j) = regressor_new(:,j);
    %         end
    %     end
    %update t
    t_new = rtnorm(t_old,t_sd,a_t,b_t);
    %       regressor_new = u.*threshold(kron((betamu_old.*(gammamu_old==1))',inte)+x*betax_old+X*betaX_old+Z*betaZ_old,t_new,tm);
    regressor_new = u.*threshold(kron(betamu_old',inte)+x*betax_old+X*betaX_old+Z*betaZ_old,t_new);
    ll_new = loglike(y,regressor_new,sigma_old);
    lr = ll_new-ll_old + log(dtnorm(t_old,t_new,t_sd,a_t,b_t)) - log(dtnorm(t_new,t_old,t_sd,a_t,b_t));
    if lr>log(rand(1))
        ac_t = ac_t + 1;
        t_old = t_new;
        regressor_old = regressor_new;
    end
    %t_old = 0;
    
    %update tau
    taux_old=1./gamrnd(a_tau+.5,1./(b_tau+etax_old.^2./gammax_old/2));
    tauX_old=1./gamrnd(a_tau+.5,1./(b_tau+etaX_old.^2./gammaX_old/2));
    tauZ_old=1./gamrnd(a_tau+.5,1./(b_tau+etaZ_old.^2./gammaZ_old/2));
    taumu_old=1./gamrnd(a_tau+.5,1./(b_tau+etamu_old.^2./gammamu_old/2));
    
    
    
    %update gammma
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etax_old.^2/2/s0./taux_old);
    gammax_old=binornd(1,ptmp./(1+ptmp));
    gammax_old(ptmp==Inf)=1;
    gammax_old(gammax_old==0)=s0;
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etaX_old.^2/2/s0./tauX_old);
    gammaX_old=binornd(1,ptmp./(1+ptmp));
    gammaX_old(ptmp==Inf)=1;
    gammaX_old(gammaX_old==0)=s0;
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etaZ_old.^2/2/s0./tauZ_old);
    gammaZ_old=binornd(1,ptmp./(1+ptmp));
    gammaZ_old(ptmp==Inf)=1;
    gammaZ_old(gammaZ_old==0)=s0;
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etamu_old.^2/2/s0./taumu_old);
    gammamu_old=binornd(1,ptmp./(1+ptmp));
    gammamu_old(ptmp==Inf)=1;
    gammamu_old(gammamu_old==0)=s0;
    
    %update omega
    ngamma=sum(sum(gammax_old==1))+sum(sum(gammaX_old==1))+sum(sum(gammaZ_old==1))+sum(gammamu_old==1);
    omega_old = betarnd(a_w+ngamma,b_w+(2*q+r+1)*p-ngamma);
    
    
    %update sigma
    sse = -(ll_old+.5*log(sigma_old))*2*sigma_old;
    sigma_old = 1/gamrnd(a+n/2,1/(b+sse/2));
    ll_old = -sse/2/sigma_old-.5*log(sigma_old);
    
    
    if mod(mc,2000)==0
        fprintf('%d steps finished\n',mc)
        fprintf('%d steps to go\n',N-mc)
    end
    %save samples every "thin" iterations
    if mod(mc,thin)==0&&mc>burnin
        iter = iter + 1;
        betax(:,:,iter)=betax_old;
        betaX(:,:,iter)=betaX_old;
        betaZ(:,:,iter)=betaZ_old;
        betamu(:,iter)=betamu_old;
        %etax(:,:,iter)=etax_old;
        %etaX(:,:,iter)=etaX_old;
        %etaZ(:,:,iter)=etaZ_old;
        %mx(:,:,iter) = mx_old;
        %mX(:,:,iter) = mX_old;
        %mZ(:,:,iter) = mZ_old;
        %xix(:,:,iter) = xix_old;
        %xiX(:,:,iter) = xiX_old;
        %xiZ(:,:,iter) = xiZ_old;
        t(iter) = t_old;
        %taux(:,:,iter)=taux_old;
        %tauX(:,:,iter)=tauX_old;
        %tauZ(:,:,iter)=tauZ_old;
        gammax(:,:,iter)=gammax_old;
        gammaX(:,:,iter)=gammaX_old;
        gammaZ(:,:,iter)=gammaZ_old;
        gammamu(:,iter)=gammamu_old;
        %omega(iter) = omega_old;
        sigma(iter) = sigma_old;
        %v(:,:,iter) = threshold(kron((betamu_old.*(gammamu_old==1))',inte)+x*(betax_old.*(gammax_old==1))+X*(betaX_old.*(gammaX_old(Xind,:)==1))+Z*(betaZ_old.*(gammaZ_old(Zind,:)==1)),t_old,tm);
        v0(:,:,iter) = kron((betamu_old.*(gammamu_old==1))',inte)+x*(betax_old.*(gammax_old==1))+X*(betaX_old.*(gammaX_old(Xind,:)==1))+Z*(betaZ_old.*(gammaZ_old(Zind,:)==1));
        v(:,:,iter) = threshold(v0(:,:,iter),t_old);
    end
end
%ac_eta = ac_eta/(N-1)/p*2;
ac_eta2 = ac_eta2/(N-1)/p/(2*q+r+1);
ac_xi = ac_xi/(N-1)/p;
ac_t = ac_t/(N-1);
%ac_mu = ac_mu/(N-1)/p;

%effect modifier structure
const = gammamu==1;
lin = gammax==1; %linear
nlin = gammaX==1;%nonlinear
ln = gammax==1|gammaX==1;%linear or nonlinear
categ = gammaZ==1;%categorical

constrate = mean(const,2);
linrate = mean(lin,3);
nlinrate = mean(nlin,3);
lnrate = mean(ln,3);
categrate = mean(categ,3);

const_est = constrate>cutoff;
lin_est = linrate>cutoff;
nlin_est = nlinrate>cutoff;
ln_est = lnrate>cutoff;
%ln_est2 = lin_est|nlin_est;
categ_est = categrate>cutoff;


urate = 0;%regression strucutre
for mc = 1:(N-burnin)/thin
    urate = urate+(v(:,:,mc)~=0);
end
urate = urate/((N-burnin)/thin);
%time2=toc;
