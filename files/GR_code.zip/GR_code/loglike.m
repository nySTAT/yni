function ll=loglike(y,regressor,sigma)

ll=-sum((y-sum(regressor,2)).^2)/2/sigma-.5*log(sigma);


