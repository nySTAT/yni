function [etax_old,etaX_old,etaZ_old,etamu_old,xix_old,xiX_old,xiZ_old,ximu_old,betax_old,betaX_old,betaZ_old,betamu_old,gammax_old,gammaX_old,gammaZ_old,gammamu_old,taux_old,tauX_old,tauZ_old,taumu_old,sigma_old,omega_old]=CdregOrth_Gibbs(y,u,x,z,N,seed)
%%
%varying coefficients regression with reduced rank
%orthogonal basis matrix

%u_est: the structure of v_est, logical(v_est)

%proposal parameters

%%
rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end

[n,p]=size(u);
q = size(x,2);
r = size(z,2);

%design matrix
inte = ones(n,1)/sqrt(n);%intercept
%categorical
Z = double.empty(n,0);
Zind = [];
zmean = [];
zscale = [];
for i =1:r
    Ztmp = dummyvar(z(:,i));
    Ztmp = Ztmp(:,2:end);
    zmean = [zmean,mean(Ztmp)];
    Ztmp = Ztmp-repmat(mean(Ztmp),n,1);
    zscale = [zscale,norm(Ztmp,'fro')*ones(1,size(Ztmp,2))];
    Ztmp = Ztmp/norm(Ztmp,'fro');
    Z = [Z,Ztmp];
    Zind = [Zind;i*ones(size(Ztmp,2),1)];
end
%continuous
order = 4; %order of splines
nknots = 16; %number of interior knots
M = order + nknots;
xx=bspline_quantileknots(order,nknots,x,x);
%xx = xx-repmat(mean(xx),[n,1]);
K = makeK(M);
Kinv = pinv(K);
X = double.empty(n,0);
Xind =[];
%x= x-repmat(mean(x),[n,1]);
for i = 1:q
    Xtmp = xx(:,(i-1)*M+1:i*M);
    [U,S,~]=svd(Xtmp*Kinv*Xtmp','econ');
    S = diag(S);
    nullvals = S < 10^-10;
    d = max(3, find( cumsum(S(~nullvals))/sum(S(~nullvals)) > .995 ,1));
    d = min(d, sum(~nullvals));
    Xtmp = U(:,1:d)*diag(sqrt(S(1:d)));
    Xtmp2 = [ones(n,1),x(:,i)];
    Xtmp = Xtmp- Xtmp2*(Xtmp2\Xtmp);
    Xtmp = Xtmp/norm(Xtmp,'fro');
    x(:,i) = x(:,i)-mean(x(:,i));
    x(:,i) = x(:,i)/norm(x(:,i),'fro');
    X = [X,Xtmp];
    Xind = [Xind,i*ones(1,size(Xtmp,2))];
end
W=[x,X,Z,inte];
U=[];
for j=1:p
    U=[U,diag(u(:,j))*W];
end

dX = size(X,2);
dZ = size(Z,2);
%parameter
a = 10^-4; b = 10^-4;%IG prior for sigma
a_tau = 5; b_tau = 100;
s0 = 2.5*10^-4;
a_w = 1/2;b_w=1/2;

xix_old = 2*(randn(q,p)>0)-1;
xiX_old = 2*(randn(dX,p)>0)-1;
xiZ_old = 2*(randn(dZ,p)>0)-1;
ximu_old = 2*(randn(p,1)>0)-1;
% betax = zeros(q,p,(N-burnin)/thin);
% betaX = zeros(dX,p,(N-burnin)/thin);
% betaZ = zeros(dZ,p,(N-burnin)/thin);
% betamu = zeros(p,(N-burnin)/thin);


% gammax= s0*ones(q,p,(N-burnin)/thin);
% gammaX = s0*ones(q,p,(N-burnin)/thin);
% gammaZ = s0*ones(r,p,(N-burnin)/thin);
% gammamu = s0*ones(p,(N-burnin)/thin);
sigma_old = 1;
taux_old = ones(q,p);
tauX_old = ones(q,p);
tauZ_old = ones(r,p);
taumu_old = ones(p,1);
gammax_old = s0*ones(q,p);
gammaX_old = s0*ones(q,p);
gammaZ_old = s0*ones(r,p);
gammamu_old = s0*ones(p,1);
omega_old = .2;
%algorithm begins
for mc = 2:N
    %update eta
    xitmp=zeros(p*(q+dX+dZ+1),p*(2*q+r+1));
    rind=0;
    cind=0;
    for j =1:p
        for i = 1:q
            %xitmp = blkdiag(xitmp,xix_old(i,j));
            rind = rind+1;
            cind = cind+1;
            %xitmp((j-1)*(q+dX+dZ+1)+i,(j-1)*(2*q+r+1)+i) = xix_old(i,j);
            xitmp(rind,cind) = xix_old(i,j);
        end
        for i = 1:q
            rlow = rind+1;
            rind = rind + sum(Xind==i);
            cind = cind+1;
            %xitmp = blkdiag(xitmp,xiX_old(Xind==i,j));            
            xitmp(rlow:rind,cind) = xiX_old(Xind==i,j);
        end
        for i = 1:r
            rlow = rind+1;            
            rind = rind + sum(Zind==i);
            cind = cind + 1;
            xitmp(rlow:rind,cind) = xiZ_old(Zind==i,j);
        end
        rind = rind+1;
        cind = cind+1;
        xitmp(rind,cind) = ximu_old(j);
    end
    Ueta=U*xitmp;
    U_tmp = [Ueta;eye(p*(2*q+r+1))];
    v_tmp = [taux_old;tauX_old;tauZ_old;taumu_old'].*[gammax_old;gammaX_old;gammaZ_old;gammamu_old'];
    Sigma_tmp = blkdiag(sigma_old^-.5*eye(n),diag(v_tmp(:).^-.5));
    [Q,R]=qr(Sigma_tmp*U_tmp,0);
    etatmp = R\(Q'*(Sigma_tmp*[y;zeros(p*(2*q+r+1),1)]))+R\randn(p*(2*q+r+1),1);
    etatmp = reshape(etatmp,2*q+r+1,p);
    etax_old = etatmp(1:q,:);
    etaX_old = etatmp(q+1:2*q,:);
    etaZ_old = etatmp(2*q+1:2*q+r,:);
    etamu_old = etatmp(2*q+r+1,:)';
    
    %update m
    mx_old=2*binornd(1,1./(1+exp(-2*xix_old)))-1;
    mX_old=2*binornd(1,1./(1+exp(-2*xiX_old)))-1;
    mZ_old=2*binornd(1,1./(1+exp(-2*xiZ_old)))-1;    
    mmu_old=2*binornd(1,1./(1+exp(-2*ximu_old)))-1;
    %update xi
    etatmp=zeros(p*(q+dX+dZ+1),1);
    ind=0;
    for j =1:p
        for i = 1:q
            ind = ind+1;
            %etatmp = blkdiag(etatmp,etax_old(i,j));
            etatmp(ind) = etax_old(i,j);
        end
        for i = 1:q
            low = ind+1;
            ind = ind+sum(Xind==i);
            etatmp(low:ind)=etaX_old(i,j);
            %etatmp = blkdiag(etatmp,etaX_old(i,j)*eye(sum(Xind==i)));
        end
        for i = 1:r
            low = ind+1;
            ind = ind+sum(Zind==i);
            etatmp(low:ind)=etaZ_old(i,j);
            %etatmp = blkdiag(etatmp,etaZ_old(i,j)*eye(sum(Zind==i)));
        end
        ind = ind+1;
        etatmp(ind) = etamu_old(j);
    end
    etatmp = diag(etatmp);
    Uxi = U*etatmp;
    U_tmp = [Uxi;eye(p*(dX+dZ+q+1))];
    Sigma_tmp = blkdiag(sigma_old^-.5*eye(n),eye(p*(dX+dZ+q+1)));
    [Q,R]=qr(Sigma_tmp*U_tmp,0);
    m_tmp = [mx_old;mX_old;mZ_old;mmu_old'];
    xitmp = R\(Q'*(Sigma_tmp*[y;m_tmp(:)]))+R\randn(p*(dX+dZ+q+1),1);
    xitmp = reshape(xitmp,dX+dZ+q+1,p);
    xix_old = xitmp(1:q,:);
    xiX_old = xitmp(q+1:q+dX,:);
    xiZ_old = xitmp(q+dX+1:q+dX+dZ,:);
    ximu_old = xitmp(q+dX+dZ+1,:)';
  
    %rescale eta and xi 
    for i = 1:q
        xibar=mean(abs(xix_old(i,:)),1);
        etax_old(i,:) = etax_old(i,:).*xibar;
        xix_old(i,:) = xix_old(i,:)./xibar;
        xibar=mean(abs(xiX_old(Xind==i,:)),1);
        etaX_old(i,:) = etaX_old(i,:).*xibar;
        xiX_old(Xind==i,:) = xiX_old(Xind==i,:)./repmat(xibar,[sum(Xind==i),1]);
    end
    for i = 1:r
        xibar=mean(abs(xiZ_old(Zind==i,:)),1);
        etaZ_old(i,:) = etaZ_old(i,:).*xibar;
        xiZ_old(Zind==i,:) = xiZ_old(Zind==i,:)./repmat(xibar,[sum(Zind==i),1]);
    end
    etamu_old = etamu_old.*abs(ximu_old);
    ximu_old = ximu_old./abs(ximu_old);
    betax_old = etax_old.*xix_old;
    betaX_old = etaX_old(Xind,:).*xiX_old;
    betaZ_old = etaZ_old(Zind,:).*xiZ_old;
    betamu_old = etamu_old.*ximu_old;
    
    %update tau
    taux_old=1./gamrnd(a_tau+.5,1./(b_tau+etax_old.^2./gammax_old/2));
    tauX_old=1./gamrnd(a_tau+.5,1./(b_tau+etaX_old.^2./gammaX_old/2));
    tauZ_old=1./gamrnd(a_tau+.5,1./(b_tau+etaZ_old.^2./gammaZ_old/2));    
    taumu_old=1./gamrnd(a_tau+.5,1./(b_tau+etamu_old.^2./gammamu_old/2));

    %update gammma
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etax_old.^2/2/s0./taux_old);
    gammax_old=binornd(1,ptmp./(1+ptmp));
    gammax_old(ptmp==Inf)=1;
    gammax_old(gammax_old==0)=s0;
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etaX_old.^2/2/s0./tauX_old);
    gammaX_old=binornd(1,ptmp./(1+ptmp));
    gammaX_old(ptmp==Inf)=1;
    gammaX_old(gammaX_old==0)=s0;
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etaZ_old.^2/2/s0./tauZ_old);
    gammaZ_old=binornd(1,ptmp./(1+ptmp));
    gammaZ_old(ptmp==Inf)=1;
    gammaZ_old(gammaZ_old==0)=s0;
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etamu_old.^2/2/s0./taumu_old);
    gammamu_old=binornd(1,ptmp./(1+ptmp));
    gammamu_old(ptmp==Inf)=1;
    gammamu_old(gammamu_old==0)=s0;
    
    %update omega
    ngamma=sum(sum(gammax_old==1))+sum(sum(gammaX_old==1))+sum(sum(gammaZ_old==1))+sum(gammamu_old==1);
    omega_old = betarnd(a_w+ngamma,b_w+(2*q+r+1)*p-ngamma);
       
    %update sigma
    %sse =  sum((y-sum(u.*(kron((betamu_old.*(gammamu_old==1))',inte)+x*betax_old+X*betaX_old+Z*betaZ_old),2)).^2);
    sse =  sum((y-sum(u.*(kron((betamu_old)',inte)+x*betax_old+X*betaX_old+Z*betaZ_old),2)).^2);
    sigma_old = 1/gamrnd(a+n/2,1/(b+sse/2));
    
    
    if mod(mc,200)==0
        fprintf('%d steps finished\n',mc)
        fprintf('%d steps to go\n',N-mc)
    end
    %save samples every "thin" iterations
%     if mod(mc,thin)==0&&mc>burnin
%         iter = iter + 1;
%         betax(:,:,iter)=betax_old;
%         betaX(:,:,iter)=betaX_old;
%         betaZ(:,:,iter)=betaZ_old;
%         betamu(:,iter)=betamu_old;
%         etax(:,:,iter)=etax_old;
%         etaX(:,:,iter)=etaX_old;
%         etaZ(:,:,iter)=etaZ_old;
%         etamu(:,:,iter)=etamu_old;
%         xix(:,:,iter) = xix_old;
%         xiX(:,:,iter) = xiX_old;
%         xiZ(:,:,iter) = xiZ_old;
%         ximu(:,:,iter) = ximu_old;
%         taux(:,:,iter)=taux_old;
%         tauX(:,:,iter)=tauX_old;
%         tauZ(:,:,iter)=tauZ_old;
%         taumu(:,:,iter)=tauZ_old;
%         gammax(:,:,iter)=gammax_old;
%         gammaX(:,:,iter)=gammaX_old;
%         gammaZ(:,:,iter)=gammaZ_old;
%         gammamu(:,iter)=gammamu_old;
%         omega(iter) = omega_old;
%         sigma(iter) = sigma_old;
%         v(:,:,iter) = threshold(kron((betamu_old.*(gammamu_old==1))',inte)+x*(betax_old.*(gammax_old==1))+X*(betaX_old.*(gammaX_old(Xind,:)==1))+Z*(betaZ_old.*(gammaZ_old(Zind,:)==1)),t_old,tm);
%     end
end


