function logl=Mloglike_m(Z,Zm,Ao,To,Go,Gl,Pl,delta_l,j)
%marginal likelihood
%Z data matrix
%Ao coefficient matrix
%To residual variance vector
%Go binary matrix
%Gl binary row vector (jth row)
%Pl hypervariance vector

%p = length(Gl);
if issparse(Gl)
    Gl = full(Gl);
end
[q,~] = size(Ao);
[n,~] = size(Z);
n_l = sum(Gl);
c = zeros(n_l,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
B = zeros(n_l);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
%Iq = eye(q);
%Ip = eye(p);
%Zm = reshape(Z',q,p,n);
for k=1:q
    n_o = sum(Go(k,:));%n_\Omega^{(k)}
    B_tmp = 0;%B_\Lambda^{(j,k)}
    l = (j - 1) * q + k;
    if n_l>0&&n_o>0
        Z_tmp2=reshape(Zm(logical(Go(k,:)),logical(Gl),:),n_l*n_o,n);%Z_l^{(\Lambda\Omega)T}
        %Z_tmp2 = Z(:,logical(kron(Gl,Go(k,:))))';%Z_l^{(\Lambda\Omega)T}
        %tmp = kron(eye(n_l),Ao(k,logical(Go(k,:)))');
        if n_l==1
            tmp = Ao(k,logical(Go(k,:)))';
        else
            tmp = [Ao(k,logical(Go(k,:)))';zeros(n_l*n_o,1)];
            tmp = [repmat(tmp,n_l-1,1);Ao(k,logical(Go(k,:)))'];
            tmp = reshape(tmp,n_l*n_o,n_l);
        end      
        tmp2 = tmp'*Z_tmp2;
        B_tmp = B_tmp + tmp2*tmp2';
    end
    if n_l>0
        Z_tmp3 = reshape(Zm(k,logical(Gl),:),n_l,n)';
        %Z_tmp3 = Z(:,logical(kron(Gl,Iq(k,:))));%Z_l^{(\Lambda)}
        B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
    end
    if  n_l>0&&n_o>0
        tmp = tmp'*Z_tmp2*Z_tmp3;
        B_tmp = B_tmp + tmp + tmp';
    end
    B = B + B_tmp/To(k);

    e = e + Z(:,l)'*Z(:,l)/2/To(k);
    
    %disp([1,k,e])
    if n_o>0
        Z_tmp4 = reshape(Zm(logical(Go(k,:)),j,:),n_o,n)';
        %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:))));%Z_l^{(\Omega)}
        etmp = Ao(k,logical(Go(k,:)))*(Z_tmp4');
        %e = e + (Ao(k,logical(Go(k,:)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:)))'...
        %    + 2*Ao(k,logical(Go(k,:)))*Z_tmp4'*Z(:,l))/2/To(k);
        e = e + (etmp*etmp' + 2*etmp*Z(:,l))/2/To(k);
    end
    %disp([2,k,e])
    if n_l>0
        c = c + (Z(:,l)'*Z_tmp3)'/To(k);
    end
    if n_l>0&&n_o>0
        Z_tmp5 = reshape(Z_tmp2*Z(:,l),n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
        %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:)))',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
        Z_tmp6 = reshape(Z_tmp2*etmp',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
        
        %c = c + (Ao(k,logical(Go(k,:)))*Z_tmp5+ Ao(k,logical(Go(k,:)))*Z_tmp6...
        %    +Ao(k,logical(Go(k,:)))*Z_tmp4'*Z_tmp3)'/To(k);
        c = c + (Ao(k,logical(Go(k,:)))*Z_tmp5+ Ao(k,logical(Go(k,:)))*Z_tmp6...
            +etmp*Z_tmp3)'/To(k);

    end
    
end

if n_l>0
    if n_l>1
        Sigma = B+diag(Pl(logical(Gl)).^-1);%inverse of \Sigma_\Lambda^{(j)}
    else
        Sigma = B+Pl(logical(Gl)).^-1;%inverse of \Sigma_\Lambda^{(j)}
    end
    d = e - .5 * c' * (Sigma\c);
    logl = gammaln((delta_l+n_l+n*q)/2)-.5*log(det(Sigma))-.5*log(prod(Pl(logical(Gl))))-(delta_l+n_l)/2*log(2*Pl(j))...
        -gammaln((delta_l+n_l)/2)-(delta_l+n_l+n*q)/2*log(1/2/Pl(j)+d)-n/2*sum(log(To));
else
    logl = gammaln((delta_l+n_l+n*q)/2)-(delta_l+n_l)/2*log(2*Pl(j))...
        -gammaln((delta_l+n_l)/2)-(delta_l+n_l+n*q)/2*log(1/2/Pl(j)+e)-n/2*sum(log(To));
end
