function mDAG_MGS()
%directed_marginal.m
%%%%%%%%%%%%%%%directed,marginal likelihood%%%%%%%%%%%%%%%%%%%%
%parameters
%clear
tmp = csvread('mparameter.csv');
%tmp = [5,25,100];
q = tmp(1);
p = tmp(2);
mcsize = tmp(3);
Z = csvread('mdata.csv');
%Z = randn(100,125);
[n,qp]=size(Z);
if qp~=q*p
    error('the input q,p mismatch data')
end
mZ= mean(Z);
Z = Z - repmat(mZ,[n 1]);%center data
Zm = reshape(Z',q,p,n);


plfix = 5;
pofix = 5;
asd = 0.5; %proposal sd for A_\Lambda and A_\Omega
To_var=1;%proposal variance of T_\Omega
burnin = mcsize/10;

Gl = ndSparse(sparse(p*p*mcsize,1),[p,p,mcsize]);
Go = zeros(q,q,mcsize);%\Gamma_\Omega
%Al = zeros(p,p,mcsize);%A_\Lambda
Ao = zeros(q,q,mcsize);
%Tl = zeros(p,p,mcsize);%T_\Lambda
To = zeros(q,mcsize);
Pl = zeros(p,mcsize);%\Pi_\Lambda
Po = zeros(q,mcsize);%\Pi_\Omega
eta = zeros(mcsize,1);
rho = zeros(mcsize,1);
logpost = zeros(mcsize,1);


To(:,1) = rand(q,1);
To(q,:) = 1;
Pl(:,1) = plfix;
Po(:,1) = pofix;
eta(1)=.5;
rho(1)=.5;
%%hyperparameters
delta_o = 3; delta_l = 3; %same as Wang 2009
a_rho = .5; b_rho = .5;%beta for rho
a_eta = .5; b_eta = .5;%beta for eta

%%
ac_Gl = 0;
ac_Go = 0;
ac_Ao = 0;
ac_To = 0;
Go_old = Go(:,:,1);
To_old = To(:,1);
Ao_old = Ao(:,:,1);
for mc = 2:mcsize
    
    %UPDATE LAMBDA PARAMETERS
    prior_tmp = 0;
    for j = 1:p-1
        %UPDATE GAMMA_LAMBDA
        Gl_old = Gl(j,:,mc-1); Gl_new = Gl_old;
        
        if sum(Gl_old)>0&&sum(1-Gl_old(j+1:p))>0&&unidrnd(2)==1 %SWAP
            pop1 = find(Gl_old==1);
            pop0 = find(Gl_old(j+1:p)==0)+j;
            h1 = pop1(randsample(length(find(pop1)),1));
            h0 = pop0(randsample(length(find(pop0)),1));
            Gl_new(h1)=0;
            Gl_new(h0)=1;
            prior_new = 0;
            prior_old = 0;
            logl_new = Mloglike_m(Z,Zm,Ao(:,:,mc-1),To(:,mc-1),Go(:,:,mc-1),Gl_new,Pl(:,mc-1),delta_l,j);
            logl_old = Mloglike_m(Z,Zm,Ao(:,:,mc-1),To(:,mc-1),Go(:,:,mc-1),Gl_old,Pl(:,mc-1),delta_l,j);
            log_ratio = logl_new-logl_old;
        else %ADD OR DELETE
            h = unidrnd(p-j) + j; %randomly choosing the element to be updated
            Gl_new(h) = abs(Gl_old(h) - 1); %switch on(off)
            if Gl_new(h)==1
                logl_new = Mloglike_m(Z,Zm,Ao(:,:,mc-1),To(:,mc-1),Go(:,:,mc-1),Gl_new,Pl(:,mc-1),delta_l,j);
                logl_old = Mloglike_m(Z,Zm,Ao(:,:,mc-1),To(:,mc-1),Go(:,:,mc-1),Gl_old,Pl(:,mc-1),delta_l,j);
                prior_new = log(eta(mc-1));
                prior_old = log(1-eta(mc-1));
                log_ratio = logl_new-logl_old+prior_new-prior_old;
            elseif Gl_new(h)==0
                logl_new = Mloglike_m(Z,Zm,Ao(:,:,mc-1),To(:,mc-1),Go(:,:,mc-1),Gl_new,Pl(:,mc-1),delta_l,j);
                logl_old = Mloglike_m(Z,Zm,Ao(:,:,mc-1),To(:,mc-1),Go(:,:,mc-1),Gl_old,Pl(:,mc-1),delta_l,j);
                prior_old = log(eta(mc-1));
                prior_new = log(1-eta(mc-1));
                log_ratio = logl_new-logl_old-prior_old+prior_new;
            end
        end
        if  log_ratio > log(rand(1))
            Gl(j, :, mc) = Gl_new;
            ac_Gl = ac_Gl+1;
            prior_tmp = prior_tmp + prior_new;
        else
            Gl(j, :, mc) = Gl_old;
            prior_tmp = prior_tmp + prior_old;
        end
    end
    %UPDATE PI_LAMBDA
    %for i = 1:p
    Pl(:,mc) = plfix;%1/gamrnd(alpha_l+(sum(Gl(:,i,mc))+delta_l+sum(Gl(i, :, mc)))/2,1/(beta_l+Al(logical(Gl(:,i,mc)),i,mc)'*Tl(logical(Gl(:,i,mc)),logical(Gl(:,i,mc)),mc)^-1*Al(logical(Gl(:,i,mc)),i,mc)/2+1/2/Tl(i,i,mc)));
    %end
    %UPDATE ETA
    eta(mc) = betarnd(a_eta+sum(sum(Gl(:,:,mc))),b_eta+ p*(p-1)/2-sum(sum(Gl(:,:,mc))));
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %UPDATE OMEGA PARAMETERS
    logo_old = Mloglike_mt(Z,Zm,Ao_old,To(:,mc-1),Go_old,Gl(:,:,mc),Pl(:,mc),delta_l);
    for k = 1:q-1
        %UPDATE GAMMA_OMEGA AND A_OMEGA JOINTLY
        Go_new = Go_old;
        Ao_new = Ao_old;
        
        if sum(Go_old(k,:))>0&&sum(1-Go_old(k,k+1:q))>0&&unidrnd(2)==1 %SWAP
            pop1 = find(Go_old(k,:)==1);
            pop0 = find(Go_old(k,k+1:q)==0)+k;
            h1 = pop1(randsample(length(find(pop1)),1));
            h0 = pop0(randsample(length(find(pop0)),1));
            Go_new(k,h1)=0;
            Go_new(k,h0)=1;
            Ao_new(k,h0)=normrnd(0,asd);
            Ao_new(k,h1)=0;
            logo_new = Mloglike_mt(Z,Zm,Ao_new,To(:,mc-1),Go_new,Gl(:,:,mc),Pl(:,mc),delta_l);
            %logo_old = Mloglike_mt(Z,Ao_old,To(:,:,mc-1),Go_old,Gl(:,:,mc),Pl(:,:,mc),delta_l);
            log_ratio = logo_new-logo_old+log(normpdf(Ao_new(k,h0),0,sqrt(To(k,mc-1)*Po(h0,mc-1))))...
                -log(normpdf(Ao_old(k,h1),0,sqrt(To(k,mc-1)*Po(h1,mc-1))))-log(normpdf(Ao_new(k,h0),0,asd))+log(normpdf(Ao_old(k,h1),0,asd));
        else %ADD OR DELETE
            h = unidrnd(q-k) + k; %randomly choosing the element to be updated
            Go_new(k,h) = abs(Go_old(k,h) - 1); %switch on(off)
            if Go_new(k,h)==1
                Ao_new(k,h) = normrnd(0,asd);
                logo_new = Mloglike_mt(Z,Zm,Ao_new,To(:,mc-1),Go_new,Gl(:,:,mc),Pl(:,mc),delta_l);
                %logo_old = Mloglike_mt(Z,Ao_old,To(:,:,mc-1),Go_old,Gl(:,:,mc),Pl(:,:,mc),delta_l);
                prior_new = log(rho(mc-1));
                prior_old = log(1-rho(mc-1));
                log_ratio = logo_new-logo_old+log(normpdf(Ao_new(k,h),0,sqrt(To(k,mc-1)*Po(h,mc-1))))...
                    +prior_new-prior_old-log(normpdf(Ao_new(k,h),0,asd));
            elseif Go_new(k,h)==0
                Ao_new(k,h) = 0;
                logo_new = Mloglike_mt(Z,Zm,Ao_new,To(:,mc-1),Go_new,Gl(:,:,mc),Pl(:,mc),delta_l);
                %logo_old = Mloglike_mt(Z,Ao_old,To(:,:,mc-1),Go_old,Gl(:,:,mc),Pl(:,:,mc),delta_l);
                prior_old = log(rho(mc-1));
                prior_new = log(1-rho(mc-1));
                log_ratio = logo_new-logo_old-log(normpdf(Ao_old(k,h),0,sqrt(To(k,mc-1)*Po(h,mc-1))))...
                    -prior_old+prior_new+log(normpdf(Ao_old(k,h),0,asd));
            end
        end
        if  log_ratio > log(rand(1))
            Go(k, :, mc) = Go_new(k,:);
            Go_old(k,:) = Go_new(k,:);
            Ao_old(k,:) = Ao_new(k,:);
            ac_Go = ac_Go + 1;
            logo_old = logo_new;
            prior_tmp = prior_tmp + prior_new;
            
        else
            Go(k, :, mc) = Go_old(k,:);
            prior_tmp = prior_tmp + prior_old;
        end
        n_o = sum(Go(k, :, mc));
        %UPDATE A_OMEGA
        if n_o>0
            Ao_new(k,:)=0;
            Ao_new(k,logical(Go(k,:,mc))) = mvnrnd(Ao_old(k,logical(Go(k,:,mc))),asd^2*eye(n_o));%RWMH
            logo_new = Mloglike_mt(Z,Zm,Ao_new,To(:,mc-1),Go_old,Gl(:,:,mc),Pl(:,mc),delta_l);
            %logo_old = Mloglike_mt(Z,Ao_old,To(:,:,mc-1),Go_old,Gl(:,:,mc),Pl(:,:,mc),delta_l);
            prior_new = log(mvnpdf(Ao_new(k,logical(Go(k,:,mc))),[],To(k,mc-1)*Po(logical(Go(k,:,mc)),mc-1)'));
            prior_old = log(mvnpdf(Ao_old(k,logical(Go(k,:,mc))),[],To(k,mc-1)*Po(logical(Go(k,:,mc)),mc-1)'));
            log_ratio = logo_new-logo_old+prior_new-prior_old;
            if log_ratio>log(rand(1))
                Ao_old(k,:) = Ao_new(k,:);
                Ao(k,:,mc) = Ao_new(k,:);
                logo_old = logo_new;
                ac_Ao = ac_Ao + 1;
                prior_tmp = prior_tmp + prior_new;
            else
                Ao(k,:,mc) = Ao_old(k,:);
                prior_tmp = prior_tmp + prior_old;
            end
        end
        %UPDATE T_OMEGA
        To_new = To_old;
        %To_new(k) = lognrnd(log(To_old(k)^2/sqrt(To_var+To_old(k)^2)),sqrt(log(To_var/To_old(k)^2+1)));
        To_new(k) = rtnorm(To_old(k),.5);
        logo_new = Mloglike_mt(Z,Zm,Ao_old,To_new,Go_old,Gl(:,:,mc),Pl(:,mc),delta_l);
        prior_new = igampdf(To_new(k),(delta_o+n_o)/2,1/2/Po(k,mc-1));
        prior_old = igampdf(To_old(k),(delta_o+n_o)/2,1/2/Po(k,mc-1));
        %log_ratio = logo_new-logo_old+prior_new-prior_old-log(lognpdf(To_new(k),log(To_old(k)^2/sqrt(To_var+To_old(k)^2)),sqrt(log(To_var/To_old(k)^2+1))))+log(lognpdf(To_old(k),log(To_new(k)^2/sqrt(To_var + To_new(k)^2)),sqrt(log(To_var/To_new(k)^2+1))));
        log_ratio = logo_new-logo_old+prior_new-prior_old-log(dtnorm(To_new(k),To_old(k),.5))+log(dtnorm(To_old(k),To_new(k),.5));
        
        if log_ratio>log(rand(1))
            To_old(k) = To_new(k);
            To(k,mc) = To_new(k);
            logo_old = logo_new;
            prior_tmp = prior_tmp + prior_new;
            ac_To = ac_To + 1;
        else
            To(k,mc) = To_old(k);
            prior_tmp = prior_tmp + prior_old;
        end
    end
    %     %UPDATE T_OMEGA^{(q,q)}
    %     To_new = To_old;
    %     To_new(q) = lognrnd(log(To_old(q)^2/sqrt(To_var+To_old(q)^2)),sqrt(log(To_var/To_old(q)^2+1)));
    %     logo_new = Mloglike_mt(Z,Zm,Ao_old,To_new,Go_old,Gl(:,:,mc),Pl(:,mc),delta_l);
    %     log_ratio = logo_new-logo_old+igampdf(To_new(q),(delta_o+n_o)/2,1/2/Po(q,mc-1))-igampdf(To_old(q),(delta_o+n_o)/2,1/2/Po(q,mc-1))-log(lognpdf(To_new(q),log(To_old(q)^2/sqrt(To_var+To_old(q)^2)),sqrt(log(To_var/To_old(q)^2+1))))+log(lognpdf(To_old(q),log(To_new(q)^2/sqrt(To_var + To_new(q)^2)),sqrt(log(To_var/To_new(q)^2+1))));
    %     if log_ratio>log(rand(1))
    %         To_old(q) = To_new(q);
    %         To(q,mc) = To_new(q);
    %         logo_old = logo_new;
    %     else
    %         To(q,mc) = To_old(q);
    %     end
    %UPDATE PI_OMEGA
    %for i = 1:q
    Po(:,mc) = pofix;%1/gamrnd(alpha_o+(sum(Go(:,i,mc))+delta_o+sum(Go(i, :, mc)))/2,1/(beta_o+Ao(logical(Go(:,i,mc)),i,mc)'*To(logical(Go(:,i,mc)),logical(Go(:,i,mc)),mc)^-1*Ao(logical(Go(:,i,mc)),i,mc)/2+1/2/To(i,i,mc)));
    
    %end
    %UPDATE RHO
    rho(mc) = betarnd(a_rho+sum(sum(Go(:,:,mc))),b_rho+ q*(q-1)/2-sum(sum(Go(:,:,mc))));
    
    %log posterior
    logpost(mc) = logo_old + prior_tmp;
    
end


Gl_rate = mean(Gl(:,:,burnin:mcsize),3);
Gl_est = Gl_rate > 0.5;
Go_rate = mean(Go(:,:,burnin:mcsize),3);
Go_est = Go_rate > 0.5;

%estimate Omega (A_\Omega and T_\Omega)
To_est = zeros(q,1);
Ao_est = zeros(q);
count_o = zeros(q,1);

for k = 1: q
    for mc=burnin:mcsize
        Go_tmp = Go(k,k+1:end,mc);
        if all(Go_tmp==Go_est(k,k+1:end))
            Ao_est(k,:) = Ao_est(k,:)+Ao(k,:,mc);
            To_est(k) = To_est(k) + To(k,mc);
            count_o(k) = count_o(k) + 1;
        end
    end
end

Ao_est = Ao_est./repmat(count_o,1,q);
To_est = To_est./count_o;

Tl_est = zeros(p,1);
Al_est = zeros(p);
count_l = zeros(p,1);
for j = 1:p
    for mc = burnin:mcsize
        
        Gl_tmp = Gl(j,:,mc);
        if all(Gl_tmp==Gl_est(j,:))
            count_l(j) = count_l(j)+1;
            if issparse(Gl_tmp)
                Gl_tmp = full(Gl_tmp);
            end
            n_l = sum(Gl_tmp);
            c = zeros(n_l,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
            B = zeros(n_l);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
            e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
            %Iq = eye(q);
            %Ip = eye(p);
            %Zm = reshape(Z',q,p,n);
            for k=1:q
                n_o = sum(Go(k,:,mc));%n_\Omega^{(k)}
                B_tmp = 0;%B_\Lambda^{(j,k)}
                l = (j - 1) * q + k;
                if n_l>0&&n_o>0
                    Z_tmp2=reshape(Zm(logical(Go(k,:,mc)),logical(Gl_tmp),:),n_l*n_o,n);%Z_l^{(\Lambda\Omega)T}
                    %Z_tmp2 = Z(:,logical(kron(Gl_tmp,Go(k,:,mc))))';%Z_l^{(\Lambda\Omega)T}
                    %tmp = kron(eye(n_l),Ao(k,logical(Go(k,:,mc)))');
                    if n_l==1
                        tmp = Ao(k,logical(Go(k,:,mc)),mc)';
                    else
                        tmp = [Ao(k,logical(Go(k,:,mc)),mc)';zeros(n_l*n_o,1)];
                        tmp = [repmat(tmp,n_l-1,1);Ao(k,logical(Go(k,:,mc)),mc)'];
                        tmp = reshape(tmp,n_l*n_o,n_l);
                    end
                    tmp2 = tmp'*Z_tmp2;
                    B_tmp = B_tmp + tmp2*tmp2';
                end
                if n_l>0
                    Z_tmp3 = reshape(Zm(k,logical(Gl_tmp),:),n_l,n)';
                    %Z_tmp3 = Z(:,logical(kron(Gl_tmp,Iq(k,:))));%Z_l^{(\Lambda)}
                    B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
                end
                if  n_l>0&&n_o>0
                    tmp = tmp'*Z_tmp2*Z_tmp3;
                    B_tmp = B_tmp + tmp + tmp';
                end
                B = B + B_tmp/To(k,mc);
                
                e = e + Z(:,l)'*Z(:,l)/2/To(k,mc);
                
                %disp([1,k,e])
                if n_o>0
                    Z_tmp4 = reshape(Zm(logical(Go(k,:,mc)),j,:),n_o,n)';
                    %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
                    etmp = Ao(k,logical(Go(k,:,mc)),mc)*(Z_tmp4');
                    %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
                    %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
                    e = e + (etmp*etmp' + 2*etmp*Z(:,l))/2/To(k,mc);
                end
                %disp([2,k,e])
                if n_l>0
                    c = c + (Z(:,l)'*Z_tmp3)'/To(k,mc);
                end
                if n_l>0&&n_o>0
                    Z_tmp5 = reshape(Z_tmp2*Z(:,l),n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
                    %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:,mc)))',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                    Z_tmp6 = reshape(Z_tmp2*etmp',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                    
                    %c = c + (Ao(k,logical(Go(k,:,mc)))*Z_tmp5+ Ao(k,logical(Go(k,:,mc)))*Z_tmp6...
                    %    +Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z_tmp3)'/To(k);
                    c = c + (Ao(k,logical(Go(k,:,mc)),mc)*Z_tmp5+ Ao(k,logical(Go(k,:,mc)),mc)*Z_tmp6...
                        +etmp*Z_tmp3)'/To(k,mc);
                    
                end
                
            end
            
            if n_l>0
                if n_l>1
                    Sigma = B+diag(Pl(logical(Gl_tmp)).^-1);%inverse of \Sigma_\Lambda^{(j)}
                else
                    Sigma = B+Pl(logical(Gl_tmp)).^-1;%inverse of \Sigma_\Lambda^{(j)}
                end
                d = e - .5 * c' * (Sigma\c);
                Al_est(j,logical(Gl_tmp)) = Al_est(j,logical(Gl_tmp)) - (Sigma\c)';
                Tl_est(j) = Tl_est(j) + (1/2/Pl(j)+d)/((delta_l+n_l+n*q)/2-1);
            else
                Tl_est(j) = Tl_est(j) + (1/2/Pl(j)+e)/((delta_l+n_l+n*q)/2-1);
            end
        end
    end
end
if sum(count_l==0)>0
for j = find(count_l==0)'
    for mc = burnin:mcsize
        Gl_tmp = Gl_est(j,:);
        count_l(j) = count_l(j)+1;
        if issparse(Gl_tmp)
            Gl_tmp = full(Gl_tmp);
        end
        n_l = sum(Gl_tmp);
        c = zeros(n_l,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        B = zeros(n_l);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
        %Iq = eye(q);
        %Ip = eye(p);
        %Zm = reshape(Z',q,p,n);
        for k=1:q
            n_o = sum(Go(k,:,mc));%n_\Omega^{(k)}
            B_tmp = 0;%B_\Lambda^{(j,k)}
            l = (j - 1) * q + k;
            if n_l>0&&n_o>0
                Z_tmp2=reshape(Zm(logical(Go(k,:,mc)),logical(Gl_tmp),:),n_l*n_o,n);%Z_l^{(\Lambda\Omega)T}
                %Z_tmp2 = Z(:,logical(kron(Gl_tmp,Go(k,:,mc))))';%Z_l^{(\Lambda\Omega)T}
                %tmp = kron(eye(n_l),Ao(k,logical(Go(k,:,mc)))');
                if n_l==1
                    tmp = Ao(k,logical(Go(k,:,mc)),mc)';
                else
                    tmp = [Ao(k,logical(Go(k,:,mc)),mc)';zeros(n_l*n_o,1)];
                    tmp = [repmat(tmp,n_l-1,1);Ao(k,logical(Go(k,:,mc)),mc)'];
                    tmp = reshape(tmp,n_l*n_o,n_l);
                end
                tmp2 = tmp'*Z_tmp2;
                B_tmp = B_tmp + tmp2*tmp2';
            end
            if n_l>0
                Z_tmp3 = reshape(Zm(k,logical(Gl_tmp),:),n_l,n)';
                %Z_tmp3 = Z(:,logical(kron(Gl_tmp,Iq(k,:))));%Z_l^{(\Lambda)}
                B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
            end
            if  n_l>0&&n_o>0
                tmp = tmp'*Z_tmp2*Z_tmp3;
                B_tmp = B_tmp + tmp + tmp';
            end
            B = B + B_tmp/To(k,mc);
            
            e = e + Z(:,l)'*Z(:,l)/2/To(k,mc);
            
            %disp([1,k,e])
            if n_o>0
                Z_tmp4 = reshape(Zm(logical(Go(k,:,mc)),j,:),n_o,n)';
                %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
                etmp = Ao(k,logical(Go(k,:,mc)),mc)*(Z_tmp4');
                %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
                %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
                e = e + (etmp*etmp' + 2*etmp*Z(:,l))/2/To(k,mc);
            end
            %disp([2,k,e])
            if n_l>0
                c = c + (Z(:,l)'*Z_tmp3)'/To(k,mc);
            end
            if n_l>0&&n_o>0
                Z_tmp5 = reshape(Z_tmp2*Z(:,l),n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
                %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:,mc)))',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                Z_tmp6 = reshape(Z_tmp2*etmp',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                
                %c = c + (Ao(k,logical(Go(k,:,mc)))*Z_tmp5+ Ao(k,logical(Go(k,:,mc)))*Z_tmp6...
                %    +Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z_tmp3)'/To(k);
                c = c + (Ao(k,logical(Go(k,:,mc)),mc)*Z_tmp5+ Ao(k,logical(Go(k,:,mc)),mc)*Z_tmp6...
                    +etmp*Z_tmp3)'/To(k,mc);
                
            end
            
        end
        
        if n_l>0
            if n_l>1
                Sigma = B+diag(Pl(logical(Gl_tmp)).^-1);%inverse of \Sigma_\Lambda^{(j)}
            else
                Sigma = B+Pl(logical(Gl_tmp)).^-1;%inverse of \Sigma_\Lambda^{(j)}
            end
            d = e - .5 * c' * (Sigma\c);
            Al_est(j,logical(Gl_tmp)) = Al_est(j,logical(Gl_tmp)) - (Sigma\c)';
            Tl_est(j) = Tl_est(j) + (1/2/Pl(j)+d)/((delta_l+n_l+n*q)/2-1);
        else
            Tl_est(j) = Tl_est(j) + (1/2/Pl(j)+e)/((delta_l+n_l+n*q)/2-1);
        end
        
    end
end
end
Al_est = Al_est./repmat(count_l,1,p);
Tl_est = Tl_est./count_l;





save('mDAG_MGS.mat','Go_rate','Gl_rate','Ao_est','To_est','Al_est','Tl_est')