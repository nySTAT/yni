function logl=Mloglike_m_fix(Z,Zm,Ao,To,Go,p)
%marginal likelihood
%Z data matrix
%Ao coefficient matrix
%To residual variance vector
%Go binary matrix


[q,~] = size(Ao);
[n,~] = size(Z);

e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}

for k=1:q
    n_o = sum(Go(k,:));%n_\Omega^{(k)}
    l = (p - 1) * q + k;
    

    e = e + Z(:,l)'*Z(:,l)/2/To(k);
    
    %disp([1,k,e])
    if n_o>0
        Z_tmp4 = reshape(Zm(logical(Go(k,:)),p,:),n_o,n)';
        %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:))));%Z_l^{(\Omega)}
        etmp = Ao(k,logical(Go(k,:)))*(Z_tmp4');
        %e = e + (Ao(k,logical(Go(k,:)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:)))'...
        %    + 2*Ao(k,logical(Go(k,:)))*Z_tmp4'*Z(:,l))/2/To(k);
        e = e + (etmp*etmp' + 2*etmp*Z(:,l))/2/To(k);
    end

    
end

 logl=-n/2*sum(log(To))-e;
