function aGGM_PCGS()
%undirected_marginal_array_collapsed.m
%%%%%%%%%%%%%%%undirected version, marginal likelihood%%%%%%%%%%%%%%%%%%%%
%parameters
%clear
tmp = csvread('aparameter.csv');
%tmp = [5,6,7,100];
q = tmp(1);
p = tmp(2);
r = tmp(3);
mcsize = tmp(4);
Z = csvread('adata.csv');
%Z = randn(100,210);
[n,qpr]=size(Z);
if qpr~=q*p*r
    error('the inputs q,p,r mismatch data')
end

plfix = 5;
pofix = 5;
ppfix = 5;
%asd = .5; %proposal sd for A_\Lambda and A_\Omega
qp = q*p;
qr = q*r;
pr = p*r;
burnin = mcsize/10;



mZ= mean(Z);
Z = Z - repmat(mZ,[n 1]);%center data
Zm = reshape(Z',qp,r,n);
Za = reshape(Z',q,p,r,n);


Gl = zeros(p,p,mcsize);%\Gamma_\Lambda
Go = zeros(q,q,mcsize);%\Gamma_\Omega
Gp = zeros(r,r,mcsize);
Glo = zeros(qp,qp,mcsize);
Gpl = zeros(pr,pr,mcsize);
Gpo = zeros(qr,qr,mcsize);
Ap = zeros(r,r,mcsize);
Al = zeros(p,p,mcsize);%A_\Lambda
Ao = zeros(q,q,mcsize);
Alo = zeros(qp,qp,mcsize);
Apl = zeros(pr,pr,mcsize);
Apo = zeros(qr,qr,mcsize);
Tp = zeros(r,mcsize);%T_\Lambda
Tl = zeros(p,mcsize);%T_\Lambda
To = zeros(q,mcsize);
Tlo = zeros(qp,mcsize);
Tpl = zeros(pr,mcsize);
Tpo = zeros(qr,mcsize);
Pl = zeros(p,mcsize);%\Pi_\Lambda
Po = zeros(q,mcsize);%\Pi_\Omega
Pp = zeros(r,mcsize);
eta = zeros(mcsize,1);
rho = zeros(mcsize,1);
ksi = zeros(mcsize,1);
I = zeros(r,mcsize,1);
J = zeros(p,mcsize);
K = zeros(q,mcsize);
Adjp = zeros(r,r,mcsize);
Adjl = zeros(p,p,mcsize);
Adjo = zeros(q,q,mcsize);

To(:,1) = rand(q,1);
To(q,:) = 1;
Tl(:,1) = rand(p,1);
Tl(p,:) = 1;
Tp(:,1) = rand(r,1);
Tlo(:,1) = kron(Tl(:,1),To(:,1));
Tpo(:,1) = kron(Tp(:,1),To(:,1));
Tpl(:,1) = kron(Tp(:,1),Tl(:,1));
Pl(:,1) = plfix;
Po(:,1) = pofix;
Pp(:,1) = ppfix;
eta(1)=.5;
rho(1)=.5;
ksi(1)=.5;
I(:,1) = 1:r;
J(:,1) = 1:p;
K(:,1) = 1:q;
Zm_old = Zm;
Za_old = Za;
Z_old = reshape(Zm_old,qpr,n)';

%%hyperparameters
delta_o = 3; delta_l = 3; delta_p = 3; %same as Wang 2009
a_rho = .5; b_rho = .5;%beta for rho
a_eta = .5; b_eta = .5;%beta for eta
a_ksi = .5;b_ksi = .5;



ac_Gl = 0;
ac_Go = 0;
ac_Gp = 0;
Go_old = Go(:,:,1);
To_old = To(:,1);
Ao_old = Ao(:,:,1);
Gl_old = Gl(:,:,1);
Tl_old = Tl(:,1);
Al_old = Al(:,:,1);
Gp_old = Gp(:,:,1);
Tp_old = Tp(:,1);
Ap_old = Ap(:,:,1);
Glo_old = Glo(:,:,1);
Tlo_old = Tlo(:,1);
Alo_old = Alo(:,:,1);
Gpo_old = Gpo(:,:,1);
Tpo_old = Tpo(:,1);
Apo_old = Apo(:,:,1);
Gpl_old = Gpl(:,:,1);
Tpl_old = Tpl(:,1);
Apl_old = Apl(:,:,1);
I_old = I(:,1);
J_old = J(:,1);
K_old = K(:,1);
Adjp_old = Adjp(:,:,1);
Adjl_old = Adjl(:,:,1);
Adjo_old = Adjo(:,:,1);

for mc = 2:mcsize  
    %UPDATE PHI PARAMETERS
    log_old = Mloglike_mt(Z_old,Zm_old,Alo_old,Tlo_old,Glo_old,Gp_old,Pp(:,mc-1),delta_p,0);
    for ii = 1:r-1
        for hh = ii+1:r
            Adjp_new = Adjp_old;
            Gp_new = Gp_old;
            i = find(I_old==ii);
            h = find(I_old==hh);
            if i>h
                itmp = i;
                i = h;
                h = itmp;
            end
            Gp_new(i,h) = abs(Gp_old(i,h) - 1); %switch on(off)
            add = (Gp_new(i,h)==1);
            Adjp_new(ii,hh) = add; Adjp_new(hh,ii) = add;
            [ro,cho,~,~] = mymaxCardinalitySearch(Gp_new+Gp_new',r);
            if cho
                o = fliplr(ro);
                Zm_new = Zm_old(:,o,:);
                Za_new = Za_old(:,:,o,:);
                Z_new = reshape(Zm_new,qpr,n)';
                %add = (Gp_new(i,h)==1);
                Gp_new=Gp_new(o,o);
                Gp_new = triu(logical(Gp_new+Gp_new'));
                I_new = I_old(o);
                log_new = Mloglike_mt(Z_new, Zm_new,Alo_old,Tlo_old,Glo_old,Gp_new,Pp(:,mc-1),delta_p,0);
                if add
                    prior_new = log(ksi(mc-1));
                    prior_old = log(1-ksi(mc-1));
                else
                    prior_new = log(1-ksi(mc-1));
                    prior_old = log(ksi(mc-1));
                end
                log_ratio = log_new-log_old+prior_new-prior_old;
                if  log_ratio > log(rand(1))
                    Gp_old = Gp_new;
                    Gpl_old = logical(triu(kron(Gp_old+eye(r),Gl_old+eye(p)),1));
                    Gpo_old = logical(triu(kron(Gp_old+eye(r),Go_old+eye(q)),1));
%                     Tp_old = Tp_old(o);
%                     Ap_old = Ap_old(o,o);
%                     Ap_tmp = Ap_old + 0./Ap_old; %convert 0 to nan
%                     Ap_tmp2 = zeros(r,r,2);
%                     Ap_tmp2(:,:,1) = triu(Ap_tmp,1);
%                     Ap_tmp2(:,:,2) = tril(Ap_tmp,-1)';
%                     Ap_old = (nanmean(Ap_tmp2,3));
%                     Ap_old(isnan(Ap_old)) = 0;
%                     Ap_old(Gp_old==0)=0;
                    I_old = I_new;
                    Zm_old = Zm_new;
                    Za_old = Za_new;
                    Z_old = Z_new;
                    log_old = log_new;
                    Adjp_old = Adjp_new;
                    ac_Gp = ac_Gp+1;
                end
            end
        end
    end
    
    Gp(:,:,mc) = Gp_old;
    Gpl(:,:,mc) = Gpl_old;
    Gpo(:,:,mc) = Gpo_old;
    I(:,mc) = I_old;
    Adjp(:,:,mc) = Adjp_old;
    
    %UPDATE PI_PHI
    
    Pp(:,mc) = ppfix;%1/gamrnd(alpha_l+(sum(Gl(:,i,mc))+delta_l+sum(Gl(i, :, mc)))/2,1/(beta_l+Al(logical(Gl(:,i,mc)),i,mc)'*Tl(logical(Gl(:,i,mc)),logical(Gl(:,i,mc)),mc)^-1*Al(logical(Gl(:,i,mc)),i,mc)/2+1/2/Tl(i,i,mc)));
    %UPDATE KSI
    ksi(mc) = betarnd(a_ksi+sum(sum(Gp(:,:,mc))),b_ksi+ r*(r-1)/2-sum(sum(Gp(:,:,mc))));
    
    
    %UPDATE A_PHI AND T_PHI
    
    
    Ap_old = zeros(r);
    Tp_old = zeros(r,1);
    for i = 1:r-1
        Gp_tmp = Gp_old(i,:);
        n_p = sum(Gp_tmp);
        c = zeros(n_p,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        B = zeros(n_p);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
        %Iq = eye(q);
        %Ip = eye(p);
        %Zm = reshape(Z',q,p,n);
        for k=1:qp
            n_o = sum(Glo_old(k,:));%n_\Omega^{(k)}
            B_tmp = 0;%B_\Lambda^{(j,k)}
            l = (i - 1) * qp + k;
            if n_p>0&&n_o>0
                Z_tmp2=reshape(Zm_old(logical(Glo_old(k,:)),logical(Gp_tmp),:),n_p*n_o,n);%Z_l^{(\Lambda\Omega)T}
                %Z_tmp2 = Z(:,logical(kron(Gl_tmp,Go(k,:,mc))))';%Z_l^{(\Lambda\Omega)T}
                %tmp = kron(eye(n_l),Ao(k,logical(Go(k,:,mc)))');
                if n_p==1
                    tmp = Alo_old(k,logical(Glo_old(k,:)))';
                else
                    tmp = [Alo_old(k,logical(Glo_old(k,:)))';zeros(n_p*n_o,1)];
                    tmp = [repmat(tmp,n_p-1,1);Alo_old(k,logical(Glo_old(k,:)))'];
                    tmp = reshape(tmp,n_p*n_o,n_p);
                end
                tmp2 = tmp'*Z_tmp2;
                B_tmp = B_tmp + tmp2*tmp2';
            end
            if n_p>0
                Z_tmp3 = reshape(Zm_old(k,logical(Gp_tmp),:),n_p,n)';
                %Z_tmp3 = Z(:,logical(kron(Gl_tmp,Iq(k,:))));%Z_l^{(\Lambda)}
                B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
            end
            if  n_p>0&&n_o>0
                tmp = tmp'*Z_tmp2*Z_tmp3;
                B_tmp = B_tmp + tmp + tmp';
            end
            B = B + B_tmp/Tlo_old(k);
            
            e = e + Z_old(:,l)'*Z_old(:,l)/2/Tlo_old(k);
            
            if n_o>0
                Z_tmp4 = reshape(Zm_old(logical(Glo_old(k,:)),i,:),n_o,n)';
                %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
                etmp = Alo_old(k,logical(Glo_old(k,:)))*(Z_tmp4');
                %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
                %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
                e = e + (etmp*etmp' + 2*etmp*Z_old(:,l))/2/Tlo_old(k);
            end
            if n_p>0
                c = c + (Z_old(:,l)'*Z_tmp3)'/Tlo_old(k);
            end
            if n_p>0&&n_o>0
                Z_tmp5 = reshape(Z_tmp2*Z_old(:,l),n_o,n_p);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
                %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:,mc)))',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                Z_tmp6 = reshape(Z_tmp2*etmp',n_o,n_p);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                
                %c = c + (Ao(k,logical(Go(k,:,mc)))*Z_tmp5+ Ao(k,logical(Go(k,:,mc)))*Z_tmp6...
                %    +Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z_tmp3)'/To(k);
                c = c + (Alo_old(k,logical(Glo_old(k,:)))*Z_tmp5+ Alo_old(k,logical(Glo_old(k,:)))*Z_tmp6...
                    +etmp*Z_tmp3)'/Tlo_old(k);
            end
        end
        
        if n_p>0
            if n_p>1
                Sigma = B+diag(Pp(logical(Gp_tmp),mc).^-1);%inverse of \Sigma_\Lambda^{(j)}
            else
                Sigma = B+Pp(logical(Gp_tmp),mc).^-1;%inverse of \Sigma_\Lambda^{(j)}
            end
            R = chol(Sigma);
            Sigma_c = R\(R'\c);
            d = e - .5 * c' * (Sigma_c);
            z = randn(n_p,1);
            Tp_old(i) = 1/gamrnd((delta_p+n_p+n*qp)/2, 1/(1/2/Pp(i,mc)+d));
            Ap_old(i,logical(Gp_tmp)) = - (Sigma_c)' + sqrt(Tp_old(i))*(R\z)';
        else
            Tp_old(i) = 1/gamrnd((delta_p+n_p+n*qp)/2, 1/(1/2/Pp(i,mc)+e));
        end
    end
    
    
    e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
    for k=1:qp
        n_o = sum(Glo_old(k,:));%n_\Omega^{(k)}
        l = (r - 1) * qp + k;
        e = e + Z_old(:,l)'*Z_old(:,l)/2/Tlo_old(k);
        if n_o>0
            Z_tmp4 = reshape(Zm_old(logical(Glo_old(k,:)),r,:),n_o,n)';
            %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
            etmp = Alo_old(k,logical(Glo_old(k,:)))*(Z_tmp4');
            %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
            %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
            e = e + (etmp*etmp' + 2*etmp*Z_old(:,l))/2/Tlo_old(k);
        end
    end
    Tp_old(r) = 1/gamrnd((delta_p+n*qp)/2, 1/(1/2/Pp(r,mc)+e));
    Tpl_old = kron(Tp_old,Tl_old);
    Tpo_old = kron(Tp_old,To_old);
    Apl_old = triu(kron(Ap_old+eye(r),Al_old+eye(p)),1);
    Apo_old = triu(kron(Ap_old+eye(r),Ao_old+eye(q)),1);
    Ap(:,:,mc) = Ap_old;
    Apl(:,:,mc) = Apl_old;
    Apo(:,:,mc) = Apo_old;
    Tp(:,mc) = Tp_old;
    Tpl(:,mc) = Tpl_old;
    Tpo(:,mc) = Tpo_old;

    %UPDATE LAMBDA PARAMETERS
    %UPDATE GAMMA_LAMBDA
    Za_old=permute(Za_old,[1,3,2,4]);
    Zm_old = reshape(Za_old,qr,p,n);
    Z_old = reshape(Zm_old,qpr,n)';


    log_old = Mloglike_mt(Z_old,Zm_old,Apo_old,Tpo_old,Gpo_old,Gl_old,Pl(:,mc-1),delta_l,1);
    for ii = 1:p-1
        for hh = ii+1:p
            Adjl_new = Adjl_old;
            Gl_new = Gl_old;
            i = find(J_old==ii);
            h = find(J_old==hh);
            if i>h
                itmp = i;
                i = h;
                h = itmp;
            end
            Gl_new(i,h) = abs(Gl_old(i,h) - 1); %switch on(off)
            add = (Gl_new(i,h)==1);
            Adjl_new(ii,hh) = add; Adjl_new(hh,ii) = add;
            [ro,cho,~,~] = mymaxCardinalitySearch(Gl_new+Gl_new',p);
            if cho
                o = fliplr(ro);
                Zm_new = Zm_old(:,o,:);
                Za_new = Za_old(:,:,o,:);
                Z_new = reshape(Zm_new,qpr,n)';
                add = (Gl_new(i,h)==1);
                Gl_new=Gl_new(o,o);
                Gl_new = triu(logical(Gl_new+Gl_new'));
                J_new = J_old(o);
                log_new = Mloglike_mt(Z_new, Zm_new,Apo_old,Tpo_old,Gpo_old,Gl_new,Pl(:,mc-1),delta_l,1);
                if add
                    prior_new = log(eta(mc-1));
                    prior_old = log(1-eta(mc-1));
                else
                    prior_new = log(1-eta(mc-1));
                    prior_old = log(eta(mc-1));
                end
                log_ratio = log_new-log_old+prior_new-prior_old;
                if  log_ratio > log(rand(1))
                    Gl_old = Gl_new;
                    Gpl_old = logical(triu(kron(Gp_old+eye(r),Gl_old+eye(p)),1));
                    Glo_old = logical(triu(kron(Gl_old+eye(p),Go_old+eye(q)),1));
%                     Tp_old = Tp_old(o);
%                     Ap_old = Ap_old(o,o);
%                     Ap_tmp = Ap_old + 0./Ap_old; %convert 0 to nan
%                     Ap_tmp2 = zeros(r,r,2);
%                     Ap_tmp2(:,:,1) = triu(Ap_tmp,1);
%                     Ap_tmp2(:,:,2) = tril(Ap_tmp,-1)';
%                     Ap_old = (nanmean(Ap_tmp2,3));
%                     Ap_old(isnan(Ap_old)) = 0;
%                     Ap_old(Gp_old==0)=0;
                    J_old = J_new;
                    Zm_old = Zm_new;
                    Za_old = Za_new;
                    Z_old = Z_new;
                    log_old = log_new;
                    Adjl_old = Adjl_new;
                    ac_Gl = ac_Gl+1;
                end
            end
        end
    end
    
    Gl(:,:,mc) = Gl_old;
    Gpl(:,:,mc) = Gpl_old;
    Glo(:,:,mc) = Glo_old;
    J(:,mc) = J_old;
    Adjl(:,:,mc) = Adjl_old;
    
    %UPDATE PI_LAMBDA
    
    Pl(:,mc) = plfix;%1/gamrnd(alpha_l+(sum(Gl(:,i,mc))+delta_l+sum(Gl(i, :, mc)))/2,1/(beta_l+Al(logical(Gl(:,i,mc)),i,mc)'*Tl(logical(Gl(:,i,mc)),logical(Gl(:,i,mc)),mc)^-1*Al(logical(Gl(:,i,mc)),i,mc)/2+1/2/Tl(i,i,mc)));
    %UPDATE ETA
    eta(mc) = betarnd(a_eta+sum(sum(Gl(:,:,mc))),b_eta+ p*(p-1)/2-sum(sum(Gl(:,:,mc))));
    
    
    %UPDATE A_LAMBDA AND T_LAMBDA
    
    Al_old = zeros(p);
    Tl_old = zeros(p,1);
    Tl_old(p) = 1;
    for i = 1:p-1
        Gl_tmp = Gl_old(i,:);
        n_l = sum(Gl_tmp);
        c = zeros(n_l,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        B = zeros(n_l);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
        %Iq = eye(q);
        %Ip = eye(p);
        %Zm = reshape(Z',q,p,n);
        for k=1:qr
            n_o = sum(Gpo_old(k,:));%n_\Omega^{(k)}
            B_tmp = 0;%B_\Lambda^{(j,k)}
            l = (i - 1) * qr + k;
            if n_l>0&&n_o>0
                Z_tmp2=reshape(Zm_old(logical(Gpo_old(k,:)),logical(Gl_tmp),:),n_l*n_o,n);%Z_l^{(\Lambda\Omega)T}
                %Z_tmp2 = Z(:,logical(kron(Gl_tmp,Go(k,:,mc))))';%Z_l^{(\Lambda\Omega)T}
                %tmp = kron(eye(n_l),Ao(k,logical(Go(k,:,mc)))');
                if n_l==1
                    tmp = Apo_old(k,logical(Gpo_old(k,:)))';
                else
                    tmp = [Apo_old(k,logical(Gpo_old(k,:)))';zeros(n_l*n_o,1)];
                    tmp = [repmat(tmp,n_l-1,1);Apo_old(k,logical(Gpo_old(k,:)))'];
                    tmp = reshape(tmp,n_l*n_o,n_l);
                end
                tmp2 = tmp'*Z_tmp2;
                B_tmp = B_tmp + tmp2*tmp2';
            end
            if n_l>0
                Z_tmp3 = reshape(Zm_old(k,logical(Gl_tmp),:),n_l,n)';
                %Z_tmp3 = Z(:,logical(kron(Gl_tmp,Iq(k,:))));%Z_l^{(\Lambda)}
                B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
            end
            if  n_l>0&&n_o>0
                tmp = tmp'*Z_tmp2*Z_tmp3;
                B_tmp = B_tmp + tmp + tmp';
            end
            B = B + B_tmp/Tpo_old(k);
            
            e = e + Z_old(:,l)'*Z_old(:,l)/2/Tpo_old(k);
            
            if n_o>0
                Z_tmp4 = reshape(Zm_old(logical(Gpo_old(k,:)),i,:),n_o,n)';
                %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
                etmp = Apo_old(k,logical(Gpo_old(k,:)))*(Z_tmp4');
                %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
                %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
                e = e + (etmp*etmp' + 2*etmp*Z_old(:,l))/2/Tpo_old(k);
            end
            if n_l>0
                c = c + (Z_old(:,l)'*Z_tmp3)'/Tpo_old(k);
            end
            if n_l>0&&n_o>0
                Z_tmp5 = reshape(Z_tmp2*Z_old(:,l),n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
                %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:,mc)))',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                Z_tmp6 = reshape(Z_tmp2*etmp',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                
                %c = c + (Ao(k,logical(Go(k,:,mc)))*Z_tmp5+ Ao(k,logical(Go(k,:,mc)))*Z_tmp6...
                %    +Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z_tmp3)'/To(k);
                c = c + (Apo_old(k,logical(Gpo_old(k,:)))*Z_tmp5+ Apo_old(k,logical(Gpo_old(k,:)))*Z_tmp6...
                    +etmp*Z_tmp3)'/Tpo_old(k);
            end
        end
        
        if n_l>0
            if n_l>1
                Sigma = B+diag(Pl(logical(Gl_tmp),mc).^-1);%inverse of \Sigma_\Lambda^{(j)}
            else
                Sigma = B+Pl(logical(Gl_tmp),mc).^-1;%inverse of \Sigma_\Lambda^{(j)}
            end
            R = chol(Sigma);
            Sigma_c = R\(R'\c);
            d = e - .5 * c' * (Sigma_c);
            z = randn(n_l,1);
            Tl_old(i) = 1/gamrnd((delta_l+n_l+n*qr)/2, 1/(1/2/Pl(i,mc)+d));            
            Al_old(i,logical(Gl_tmp)) = - (Sigma_c)' + sqrt(Tl_old(i))*(R\z)';
        else
            Tl_old(i) = 1/gamrnd((delta_l+n_l+n*qr)/2, 1/(1/2/Pl(i,mc)+e));
        end
    end
    Tpl_old = kron(Tp_old,Tl_old);
    Tlo_old = kron(Tl_old,To_old);
    Apl_old = triu(kron(Ap_old+eye(r),Al_old+eye(p)),1);
    Alo_old = triu(kron(Al_old+eye(p),Ao_old+eye(q)),1);
    Al(:,:,mc) = Al_old;
    Apl(:,:,mc) = Apl_old;
    Alo(:,:,mc) = Alo_old;
    Tl(:,mc) = Tl_old;
    Tpl(:,mc) = Tpl_old;
    Tlo(:,mc) = Tlo_old;
    



    %UPDATE OMEGA PARAMETERS
    %UPDATE GAMMA_OMEGA
    Za_old=permute(Za_old,[3,2,1,4]);
    Zm_old = reshape(Za_old,pr,q,n);
    Z_old = reshape(Zm_old,qpr,n)';


    log_old = Mloglike_mt(Z_old,Zm_old,Apl_old,Tpl_old,Gpl_old,Go_old,Po(:,mc-1),delta_o,1);
    for ii = 1:q-1
        for hh = ii+1:q
            Adjo_new = Adjo_old;
            Go_new = Go_old;
            i = find(K_old==ii);
            h = find(K_old==hh);
            if i>h
                itmp = i;
                i = h;
                h = itmp;
            end
            Go_new(i,h) = abs(Go_old(i,h) - 1); %switch on(off)
            add = (Go_new(i,h)==1);
            Adjo_new(ii,hh) = add; Adjo_new(hh,ii) = add;
            [ro,cho,~,~] = mymaxCardinalitySearch(Go_new+Go_new',q);
            if cho
                o = fliplr(ro);
                Zm_new = Zm_old(:,o,:);
                Za_new = Za_old(:,:,o,:);
                Z_new = reshape(Zm_new,qpr,n)';
                add = (Go_new(i,h)==1);
                Go_new=Go_new(o,o);
                Go_new = triu(logical(Go_new+Go_new'));
                K_new = K_old(o);
                log_new = Mloglike_mt(Z_new, Zm_new,Apl_old,Tpl_old,Gpl_old,Go_new,Po(:,mc-1),delta_o,1);
                if add
                    prior_new = log(rho(mc-1));
                    prior_old = log(1-rho(mc-1));
                else
                    prior_new = log(1-rho(mc-1));
                    prior_old = log(rho(mc-1));
                end
                log_ratio = log_new-log_old+prior_new-prior_old;
                if  log_ratio > log(rand(1))
                    Go_old = Go_new;
                    Gpo_old = logical(triu(kron(Gp_old+eye(r),Go_old+eye(q)),1));
                    Glo_old = logical(triu(kron(Gl_old+eye(p),Go_old+eye(q)),1));
%                     Tp_old = Tp_old(o);
%                     Ap_old = Ap_old(o,o);
%                     Ap_tmp = Ap_old + 0./Ap_old; %convert 0 to nan
%                     Ap_tmp2 = zeros(r,r,2);
%                     Ap_tmp2(:,:,1) = triu(Ap_tmp,1);
%                     Ap_tmp2(:,:,2) = tril(Ap_tmp,-1)';
%                     Ap_old = (nanmean(Ap_tmp2,3));
%                     Ap_old(isnan(Ap_old)) = 0;
%                     Ap_old(Gp_old==0)=0;
                    K_old = K_new;
                    Zm_old = Zm_new;
                    Za_old = Za_new;
                    Z_old = Z_new;
                    log_old = log_new;
                    Adjo_old = Adjo_new;
                    ac_Go = ac_Go+1;
                end
            end
        end
    end
    
    Go(:,:,mc) = Go_old;
    Gpo(:,:,mc) = Gpo_old;
    Glo(:,:,mc) = Glo_old;
    K(:,mc) = K_old;
    Adjo(:,:,mc) = Adjo_old;
    
    %UPDATE PI_OMEGA
    
    Po(:,mc) = pofix;%1/gamrnd(alpha_l+(sum(Gl(:,i,mc))+delta_l+sum(Gl(i, :, mc)))/2,1/(beta_l+Al(logical(Gl(:,i,mc)),i,mc)'*Tl(logical(Gl(:,i,mc)),logical(Gl(:,i,mc)),mc)^-1*Al(logical(Gl(:,i,mc)),i,mc)/2+1/2/Tl(i,i,mc)));
    %UPDATE RHO
    rho(mc) = betarnd(a_rho+sum(sum(Go(:,:,mc))),b_rho+ q*(q-1)/2-sum(sum(Go(:,:,mc))));
    
    
    %UPDATE A_OMEGA AND T_OMEGA
    
    Ao_old = zeros(q);
    To_old = zeros(q,1);
    To_old(q) = 1;
    for i = 1:q-1
        Go_tmp = Go_old(i,:);
        n_o = sum(Go_tmp);
        c = zeros(n_o,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        B = zeros(n_o);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
        %Iq = eye(q);
        %Ip = eye(p);
        %Zm = reshape(Z',q,p,n);
        for k=1:pr
            n_p = sum(Gpl_old(k,:));%n_\Omega^{(k)}
            B_tmp = 0;%B_\Lambda^{(j,k)}
            l = (i - 1) * pr + k;
            if n_o>0&&n_p>0
                Z_tmp2=reshape(Zm_old(logical(Gpl_old(k,:)),logical(Go_tmp),:),n_o*n_p,n);%Z_l^{(\Lambda\Omega)T}
                %Z_tmp2 = Z(:,logical(kron(Gl_tmp,Go(k,:,mc))))';%Z_l^{(\Lambda\Omega)T}
                %tmp = kron(eye(n_o),Ao(k,logical(Go(k,:,mc)))');
                if n_o==1
                    tmp = Apl_old(k,logical(Gpl_old(k,:)))';
                else
                    tmp = [Apl_old(k,logical(Gpl_old(k,:)))';zeros(n_o*n_p,1)];
                    tmp = [repmat(tmp,n_o-1,1);Apl_old(k,logical(Gpl_old(k,:)))'];
                    tmp = reshape(tmp,n_o*n_p,n_o);
                end
                tmp2 = tmp'*Z_tmp2;
                B_tmp = B_tmp + tmp2*tmp2';
            end
            if n_o>0
                Z_tmp3 = reshape(Zm_old(k,logical(Go_tmp),:),n_o,n)';
                %Z_tmp3 = Z(:,logical(kron(Gl_tmp,Iq(k,:))));%Z_l^{(\Lambda)}
                B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
            end
            if  n_o>0&&n_p>0
                tmp = tmp'*Z_tmp2*Z_tmp3;
                B_tmp = B_tmp + tmp + tmp';
            end
            B = B + B_tmp/Tpl_old(k);
            
            e = e + Z_old(:,l)'*Z_old(:,l)/2/Tpl_old(k);
            
            if n_p>0
                Z_tmp4 = reshape(Zm_old(logical(Gpl_old(k,:)),i,:),n_p,n)';
                %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
                etmp = Apl_old(k,logical(Gpl_old(k,:)))*(Z_tmp4');
                %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
                %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
                e = e + (etmp*etmp' + 2*etmp*Z_old(:,l))/2/Tpl_old(k);
            end
            if n_o>0
                c = c + (Z_old(:,l)'*Z_tmp3)'/Tpl_old(k);
            end
            if n_o>0&&n_p>0
                Z_tmp5 = reshape(Z_tmp2*Z_old(:,l),n_p,n_o);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
                %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:,mc)))',n_p,n_o);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                Z_tmp6 = reshape(Z_tmp2*etmp',n_p,n_o);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                
                %c = c + (Ao(k,logical(Go(k,:,mc)))*Z_tmp5+ Ao(k,logical(Go(k,:,mc)))*Z_tmp6...
                %    +Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z_tmp3)'/To(k);
                c = c + (Apl_old(k,logical(Gpl_old(k,:)))*Z_tmp5+ Apl_old(k,logical(Gpl_old(k,:)))*Z_tmp6...
                    +etmp*Z_tmp3)'/Tpl_old(k);
            end
        end
        
        if n_o>0
            if n_o>1
                Sigma = B+diag(Po(logical(Go_tmp),mc).^-1);%inverse of \Sigma_\Lambda^{(j)}
            else
                Sigma = B+Po(logical(Go_tmp),mc).^-1;%inverse of \Sigma_\Lambda^{(j)}
            end
            R = chol(Sigma);
            Sigma_c = R\(R'\c);
            d = e - .5 * c' * (Sigma_c);
            z = randn(n_o,1);
            To_old(i) = 1/gamrnd((delta_o+n_o+n*pr)/2, 1/(1/2/Po(i,mc)+d));
            Ao_old(i,logical(Go_tmp)) = - (Sigma_c)' + sqrt(To_old(i))*(R\z)';
        else
            To_old(i) = 1/gamrnd((delta_o+n_o+n*pr)/2, 1/(1/2/Po(i,mc)+e));
        end
    end
    Tpo_old = kron(Tp_old,To_old);
    Tlo_old = kron(Tl_old,To_old);
    Apo_old = triu(kron(Ap_old+eye(r),Ao_old+eye(q)),1);
    Alo_old = triu(kron(Al_old+eye(p),Ao_old+eye(q)),1);
    Ao(:,:,mc) = Ao_old;
    Apo(:,:,mc) = Apo_old;
    Alo(:,:,mc) = Alo_old;
    To(:,mc) = To_old;
    Tpo(:,mc) = Tpo_old;
    Tlo(:,mc) = Tlo_old;

    Za_old=permute(Za_old,[3,1,2,4]);
    Zm_old = reshape(Za_old,qp,r,n);
    Z_old = reshape(Zm_old,qpr,n)';
    %Gp(:,:,mc)
end


G_visited=hiprob2(reshape(Adjl(:,:,burnin:mcsize),p^2,[])');
Gl_est2 = triu(reshape(G_visited(1,:),p,p));
G_visited=hiprob2(reshape(Adjp(:,:,burnin:mcsize),r^2,[])');
Gp_est2 = triu(reshape(G_visited(1,:),r,r));
G_visited=hiprob2(reshape(Adjo(:,:,burnin:mcsize),q^2,[])');
Go_est2 = triu(reshape(G_visited(1,:),q,q));




%highest posterior model
Ao_est2 = zeros(q);
Al_est2 = zeros(p);
Ap_est2 = zeros(r);
Omega_est = zeros(q);
Lambda_est = zeros(p);
Phi_est = zeros(r);
count_l = 0;
count_o = 0;
count_p = 0;
for mc = burnin:mcsize
    rK(K(:,mc))=1:q;
    rJ(J(:,mc))=1:p;
    rI(I(:,mc))=1:r;
    if all(all(Go_est2==triu(logical(Go(rK,rK,mc)+Go(rK,rK,mc)'))))
        Ao_tmp = Ao(rK,rK,mc);
        Ao_tmp = Ao_tmp + 0./Ao_tmp; %convert 0 to nan
        Ao_tmp2 = zeros(q,q,2);
        Ao_tmp2(:,:,1) = triu(Ao_tmp,1);
        Ao_tmp2(:,:,2) = tril(Ao_tmp,-1)';
        Ao_tmp = (nanmean(Ao_tmp2,3));
        Ao_tmp(isnan(Ao_tmp)) = 0;
        Ao_est2 = Ao_est2 + Ao_tmp;
        Omega_tmp = (Ao(:,:,mc)+eye(q))'*diag(To(:,mc).^-1)*(Ao(:,:,mc)+eye(q));
        Omega_tmp = Omega_tmp(rK,rK);
        Omega_est = Omega_est + Omega_tmp;
        %         if ~all(all((Ao_tmp(Go_est2==0)==0)))
        %             mc
        %         end
        count_o = count_o+1;
    end
    if all(all(Gl_est2==triu(logical(Gl(rJ,rJ,mc)+Gl(rJ,rJ,mc)'))))
        Al_tmp = Al(rJ,rJ,mc);
        Al_tmp = Al_tmp + 0./Al_tmp; %convert 0 to nan
        Al_tmp2 = zeros(p,p,2);
        Al_tmp2(:,:,1) = triu(Al_tmp,1);
        Al_tmp2(:,:,2) = tril(Al_tmp,-1)';
        Al_tmp = (nanmean(Al_tmp2,3));
        Al_tmp(isnan(Al_tmp)) = 0;
        Al_est2 = Al_est2 + Al_tmp;
        Lambda_tmp = (Al(:,:,mc)+eye(p))'*diag(Tl(:,mc).^-1)*(Al(:,:,mc)+eye(p));
        Lambda_tmp = Lambda_tmp(rJ,rJ);
        Lambda_est = Lambda_est + Lambda_tmp;
        %         if ~all(all((Al_tmp(Gl_est2==0)==0)))
        %             mc
        %         end
        count_l = count_l+1;
    end
    if all(all(Gp_est2==triu(logical(Gp(rI,rI,mc)+Gp(rI,rI,mc)'))))
        Ap_tmp = Ap(rI,rI,mc);
        Ap_tmp = Ap_tmp + 0./Ap_tmp; %convert 0 to nan
        Ap_tmp2 = zeros(r,r,2);
        Ap_tmp2(:,:,1) = triu(Ap_tmp,1);
        Ap_tmp2(:,:,2) = tril(Ap_tmp,-1)';
        Ap_tmp = (nanmean(Ap_tmp2,3));
        Ap_tmp(isnan(Ap_tmp)) = 0;
        Ap_est2 = Ap_est2 + Ap_tmp;
        Phi_tmp = (Ap(:,:,mc)+eye(r))'*diag(Tp(:,mc).^-1)*(Ap(:,:,mc)+eye(r));
        Phi_tmp = Phi_tmp(rI,rI);
        Phi_est = Phi_est + Phi_tmp;
        %         if ~all(all((Al_tmp(Gl_est==0)==0)))
        %             mc
        %         end
        count_p = count_p+1;
    end
end
Ao_est2 = Ao_est2/count_o;
Al_est2 = Al_est2/count_l;
Ap_est2 = Ap_est2/count_p;
Omega_est = Omega_est/count_o;
Lambda_est = Lambda_est/count_l;
Phi_est = Phi_est/count_p;





save('aGGM_PCGS.mat','Omega_est','Lambda_est','Phi_est')

