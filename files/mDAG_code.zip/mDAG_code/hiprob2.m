function [gamma_unique, freq, prob2] = hiprob2(gamma,prob)
%Select model with highest probability (frequency)
%-Input
%gamma: the visited model matrix (one model in each row) with repilcates.
%prob: probability associated with each row of gamma
%-Output:(descending order wrt freq)
%gamma_unique: the unique visited model matrix (no replicates)
%freq: the number of times of each model being visited
%prob2: the probability of each unique model (the empirical relative frequency)
if nargin==2
    [gamma_unique,~,J] = unique(gamma,'rows');
    u = size(gamma_unique,1);
    prob2 = zeros(u,1);
    for i = 1:u
        prob2(i) = mean(prob(J==i));
    end
    tabl = tabulate(J);
    freq = tabl(:,2);
    prob2 = (prob2.*freq)/sum(prob2.*freq);
    p = size(gamma,2);
    mat = sortrows([gamma_unique, freq, prob2],-(p+2));
    gamma_unique = mat(:,1:p);
    freq = mat(:,p+1);
    prob2 = mat(:,p+2);    
else   
    [gamma_unique,~,J] = unique(gamma,'rows');
    tabl = tabulate(J);
    freq = tabl(:,2);
    p = size(gamma,2);
    mat = sortrows([gamma_unique, freq],-(p+1));
    gamma_unique = mat(:,1:p);
    freq = mat(:,p+1);
    prob2 = freq;
end