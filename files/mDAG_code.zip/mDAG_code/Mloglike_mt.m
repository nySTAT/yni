function logl=Mloglike_mt(Z,Zm,Ao,To,Go,Gl,Pl,delta_l,fix)
%total marginal likelihood for
%A_\Omega,T_\Omega,\Gamma_\Omega,\Gamma_\Lambda,\Pi_\Lambda
%fix: logical, fix=1 if Tl(p) fixed to 1.
if nargin<9
    fix=0;
end
[p, ~] = size(Gl);
logl = 0;

for j = 1:p-1
    logl = logl + Mloglike_m(Z,Zm,Ao,To,Go,Gl(j,:),Pl,delta_l,j);
end
if logical(fix)
    logl = logl + Mloglike_m_fix(Z,Zm,Ao,To,Go,p);
else
    logl = logl + Mloglike_m(Z,Zm,Ao,To,Go,Gl(p,:),Pl,delta_l,p);
end