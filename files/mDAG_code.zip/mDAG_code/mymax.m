function [idx, val] = mymax(varargin)
%% Return the largest linear index of the maximum value
%varargin has to be vector!!!

% This file is from matlabtools.googlecode.com


val = max(varargin{:});
idx = find(varargin{:}==val,1,'last');
end