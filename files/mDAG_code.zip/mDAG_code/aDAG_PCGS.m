function aDAG_PCGS()
%directed_marginal_array_collapsed.m
%%%%%%%%%%%%%%%directed,marginal likelihood%%%%%%%%%%%%%%%%%%%%
%parameters
%clear
tmp = csvread('aparameter.csv');
%tmp = [5,6,7,100];
q = tmp(1);
p = tmp(2);
r = tmp(3);
mcsize = tmp(4);
Z = csvread('adata.csv');
%Z = randn(100,210);
[n,qpr]=size(Z);
if qpr~=q*p*r
    error('the inputs q,p,r mismatch data')
end
plfix = 5;
pofix = 5;
ppfix = 5;
asd = 0.5; %proposal sd for A_\Lambda and A_\Omega
qp = q*p;
qr = q*r;
pr = p*r;
burnin = mcsize/10;

mZ= mean(Z);
Z = Z - repmat(mZ,[n 1]);%center data
Zm = reshape(Z',qp,r,n);
Za = reshape(Z',q,p,r,n);
Zlm = reshape(permute(Za,[1,3,2,4]),qr,p,n);
Zl = reshape(Zlm,qpr,n)';
Zom = reshape(permute(Za,[2,3,1,4]),pr,q,n);
Zo = reshape(Zom,qpr,n)';

Gl = zeros(p,p,mcsize);%\Gamma_\Lambda
Go = zeros(q,q,mcsize);%\Gamma_\Omega
Gp = zeros(r,r,mcsize);
Glo = zeros(qp,qp,mcsize);
Gpl = zeros(pr,pr,mcsize);
Gpo = zeros(qr,qr,mcsize);
Ap = zeros(r,r,mcsize);
Al = zeros(p,p,mcsize);%A_\Lambda
Ao = zeros(q,q,mcsize);
Alo = zeros(qp,qp,mcsize);
Apl = zeros(pr,pr,mcsize);
Apo = zeros(qr,qr,mcsize);
Tp = zeros(r,mcsize);%T_\Lambda
Tl = zeros(p,mcsize);%T_\Lambda
To = zeros(q,mcsize);
Tlo = zeros(qp,mcsize);
Tpl = zeros(pr,mcsize);
Tpo = zeros(qr,mcsize);
Pl = zeros(p,mcsize);%\Pi_\Lambda
Po = zeros(q,mcsize);%\Pi_\Omega
Pp = zeros(r,mcsize);
eta = zeros(mcsize,1);
rho = zeros(mcsize,1);
ksi = zeros(mcsize,1);


To(:,1) = rand(q,1);
To(q,:) = 1;
Tl(:,1) = rand(p,1);
Tl(p,:) = 1;
Tp(:,1) = rand(r,1);
Tlo(:,1) = kron(Tl(:,1),To(:,1));
Tpo(:,1) = kron(Tp(:,1),To(:,1));
Tpl(:,1) = kron(Tp(:,1),Tl(:,1));
Pl(:,1) = plfix;
Po(:,1) = pofix;
Pp(:,1) = ppfix;
eta(1)=.5;
rho(1)=.5;
ksi(1)=.5;
%%hyperparameters
delta_o = 3; delta_l = 3; delta_p = 3; %same as Wang 2009
a_rho = .5; b_rho = .5;%beta for rho
a_eta = .5; b_eta = .5;%beta for eta
a_ksi = .5;b_ksi = .5;




ac_Gl = 0;
ac_Go = 0;
ac_Gp = 0;
Go_old = Go(:,:,1);
To_old = To(:,1);
Ao_old = Ao(:,:,1);
Gl_old = Gl(:,:,1);
Tl_old = Tl(:,1);
Al_old = Al(:,:,1);
Gp_old = Gp(:,:,1);
Tp_old = Tp(:,1);
Ap_old = Ap(:,:,1);
Glo_old = Glo(:,:,1);
Tlo_old = Tlo(:,1);
Alo_old = Alo(:,:,1);
Gpo_old = Gpo(:,:,1);
Tpo_old = Tpo(:,1);
Apo_old = Apo(:,:,1);
Gpl_old = Gpl(:,:,1);
Tpl_old = Tpl(:,1);
Apl_old = Apl(:,:,1);
for mc = 2:mcsize
    %UPDATE PHI PARAMETERS
    for i = 1:r-1
        %UPDATE GAMMA_PHI
        Gp_old = Gp(i,:,mc-1); Gp_new = Gp_old;
        
        if sum(Gp_old)>0&&sum(1-Gp_old(i+1:r))>0&&unidrnd(2)==1 %SWAP
            pop1 = find(Gp_old==1);
            pop0 = find(Gp_old(i+1:r)==0)+i;
            h1 = pop1(randsample(length(find(pop1)),1));
            h0 = pop0(randsample(length(find(pop0)),1));
            Gp_new(h1)=0;
            Gp_new(h0)=1;
            logp_new = Mloglike_m(Z,Zm,Alo_old,Tlo_old,Glo_old,Gp_new,Pp(:,mc-1),delta_p,i);
            logp_old = Mloglike_m(Z,Zm,Alo_old,Tlo_old,Glo_old,Gp_old,Pp(:,mc-1),delta_p,i);
            log_ratio = logp_new-logp_old;
        else %ADD OR DELETE
            h = unidrnd(r-i) + i; %randomly choosing the element to be updated
            Gp_new(h) = abs(Gp_old(h) - 1); %switch on(off)
            if Gp_new(h)==1
                logp_new = Mloglike_m(Z,Zm,Alo_old,Tlo_old,Glo_old,Gp_new,Pp(:,mc-1),delta_p,i);
                logp_old = Mloglike_m(Z,Zm,Alo_old,Tlo_old,Glo_old,Gp_old,Pp(:,mc-1),delta_p,i);
                prior_new = log(ksi(mc-1));
                prior_old = log(1-ksi(mc-1));
                log_ratio = logp_new-logp_old+prior_new-prior_old;
            elseif Gp_new(h)==0
                logp_new = Mloglike_m(Z,Zm,Alo_old,Tlo_old,Glo_old,Gp_new,Pp(:,mc-1),delta_p,i);
                logp_old = Mloglike_m(Z,Zm,Alo_old,Tlo_old,Glo_old,Gp_old,Pp(:,mc-1),delta_p,i);              
                prior_old = log(ksi(mc-1));
                prior_new = log(1-ksi(mc-1));
                log_ratio = logp_new-logp_old-prior_old+prior_new;
            end
        end
        if  log_ratio > log(rand(1))
            Gp(i, :, mc) = Gp_new;
            ac_Gp = ac_Gp+1;
        else
            Gp(i, :, mc) = Gp_old;
        end
    end
    Gp_old = Gp(:,:,mc);
    Gpl_old = logical(triu(kron(Gp(:,:,mc)+eye(r),Gl(:,:,mc-1)+eye(p)),1));
    Gpl(:,:,mc) = Gpl_old;
    Gpo_old = logical(triu(kron(Gp(:,:,mc)+eye(r),Go(:,:,mc-1)+eye(q)),1));
    Gpo(:,:,mc) = Gpo_old;
    %UPDATE PI_PHI
    %for i = 1:p
    Pp(:,mc) = ppfix;%1/gamrnd(alpha_l+(sum(Gl(:,i,mc))+delta_l+sum(Gl(i, :, mc)))/2,1/(beta_l+Al(logical(Gl(:,i,mc)),i,mc)'*Tl(logical(Gl(:,i,mc)),logical(Gl(:,i,mc)),mc)^-1*Al(logical(Gl(:,i,mc)),i,mc)/2+1/2/Tl(i,i,mc)));
    %end
    %UPDATE KSI
    ksi(mc) = betarnd(a_ksi+sum(sum(Gp(:,:,mc))),b_ksi+ r*(r-1)/2-sum(sum(Gp(:,:,mc))));
    
    %UPDATE A_PHI AND T_PHI
    
    
    Ap_old = zeros(r);
    Tp_old = zeros(r,1);
    for i = 1:r-1
        Gp_tmp = Gp_old(i,:);
        n_p = sum(Gp_tmp);
        c = zeros(n_p,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        B = zeros(n_p);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
        %Iq = eye(q);
        %Ip = eye(p);
        %Zm = reshape(Z',q,p,n);
        for k=1:qp
            n_o = sum(Glo_old(k,:));%n_\Omega^{(k)}
            B_tmp = 0;%B_\Lambda^{(j,k)}
            l = (i - 1) * qp + k;
            if n_p>0&&n_o>0
                Z_tmp2=reshape(Zm(logical(Glo_old(k,:)),logical(Gp_tmp),:),n_p*n_o,n);%Z_l^{(\Lambda\Omega)T}
                %Z_tmp2 = Z(:,logical(kron(Gl_tmp,Go(k,:,mc))))';%Z_l^{(\Lambda\Omega)T}
                %tmp = kron(eye(n_l),Ao(k,logical(Go(k,:,mc)))');
                if n_p==1
                    tmp = Alo_old(k,logical(Glo_old(k,:)))';
                else
                    tmp = [Alo_old(k,logical(Glo_old(k,:)))';zeros(n_p*n_o,1)];
                    tmp = [repmat(tmp,n_p-1,1);Alo_old(k,logical(Glo_old(k,:)))'];
                    tmp = reshape(tmp,n_p*n_o,n_p);
                end
                tmp2 = tmp'*Z_tmp2;
                B_tmp = B_tmp + tmp2*tmp2';
            end
            if n_p>0
                Z_tmp3 = reshape(Zm(k,logical(Gp_tmp),:),n_p,n)';
                %Z_tmp3 = Z(:,logical(kron(Gl_tmp,Iq(k,:))));%Z_l^{(\Lambda)}
                B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
            end
            if  n_p>0&&n_o>0
                tmp = tmp'*Z_tmp2*Z_tmp3;
                B_tmp = B_tmp + tmp + tmp';
            end
            B = B + B_tmp/Tlo_old(k);
            
            e = e + Z(:,l)'*Z(:,l)/2/Tlo_old(k);
            
            if n_o>0
                Z_tmp4 = reshape(Zm(logical(Glo_old(k,:)),i,:),n_o,n)';
                %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
                etmp = Alo_old(k,logical(Glo_old(k,:)))*(Z_tmp4');
                %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
                %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
                e = e + (etmp*etmp' + 2*etmp*Z(:,l))/2/Tlo_old(k);
            end
            if n_p>0
                c = c + (Z(:,l)'*Z_tmp3)'/Tlo_old(k);
            end
            if n_p>0&&n_o>0
                Z_tmp5 = reshape(Z_tmp2*Z(:,l),n_o,n_p);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
                %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:,mc)))',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                Z_tmp6 = reshape(Z_tmp2*etmp',n_o,n_p);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                
                %c = c + (Ao(k,logical(Go(k,:,mc)))*Z_tmp5+ Ao(k,logical(Go(k,:,mc)))*Z_tmp6...
                %    +Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z_tmp3)'/To(k);
                c = c + (Alo_old(k,logical(Glo_old(k,:)))*Z_tmp5+ Alo_old(k,logical(Glo_old(k,:)))*Z_tmp6...
                    +etmp*Z_tmp3)'/Tlo_old(k);
            end
        end
        
        if n_p>0
            if n_p>1
                Sigma = B+diag(Pp(logical(Gp_tmp),mc).^-1);%inverse of \Sigma_\Lambda^{(j)}
            else
                Sigma = B+Pp(logical(Gp_tmp),mc).^-1;%inverse of \Sigma_\Lambda^{(j)}
            end
            R = chol(Sigma);
            Sigma_c = R\(R'\c);
            d = e - .5 * c' * (Sigma_c);
            z = randn(n_p,1);
            Tp_old(i) = 1/gamrnd((delta_p+n_p+n*qp)/2, 1/(1/2/Pp(i,mc)+d));
            Ap_old(i,logical(Gp_tmp)) = - (Sigma_c)' + sqrt(Tp_old(i))*(R\z)';
        else
            Tp_old(i) = 1/gamrnd((delta_p+n_p+n*qp)/2, 1/(1/2/Pp(i,mc)+e));
        end
    end
    
    
    e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
    for k=1:qp
        n_o = sum(Glo_old(k,:));%n_\Omega^{(k)}
        l = (r - 1) * qp + k;
        e = e + Z(:,l)'*Z(:,l)/2/Tlo_old(k);
        if n_o>0
            Z_tmp4 = reshape(Zm(logical(Glo_old(k,:)),r,:),n_o,n)';
            %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
            etmp = Alo_old(k,logical(Glo_old(k,:)))*(Z_tmp4');
            %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
            %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
            e = e + (etmp*etmp' + 2*etmp*Z(:,l))/2/Tlo_old(k);
        end
    end
    Tp_old(r) = 1/gamrnd((delta_p+n*qp)/2, 1/(1/2/Pp(r,mc)+e));
    Tpl_old = kron(Tp_old,Tl_old);
    Tpo_old = kron(Tp_old,To_old);
    Apl_old = triu(kron(Ap_old+eye(r),Al_old+eye(p)),1);
    Apo_old = triu(kron(Ap_old+eye(r),Ao_old+eye(q)),1);
    Ap(:,:,mc) = Ap_old;
    Apl(:,:,mc) = Apl_old;
    Apo(:,:,mc) = Apo_old;
    Tp(:,mc) = Tp_old;
    Tpl(:,mc) = Tpl_old;
    Tpo(:,mc) = Tpo_old;
    
    
        
    %UPDATE LAMBDA PARAMETERS

    
    
    %UPDATE GAMMA_LAMBDA
    prior_tmp = 0;
    for j = 1:p-1
        
        Gl_old = Gl(j,:,mc-1); Gl_new = Gl_old;
        
        if sum(Gl_old)>0&&sum(1-Gl_old(j+1:p))>0&&unidrnd(2)==1 %SWAP
            pop1 = find(Gl_old==1);
            pop0 = find(Gl_old(j+1:p)==0)+j;
            h1 = pop1(randsample(length(find(pop1)),1));
            h0 = pop0(randsample(length(find(pop0)),1));
            Gl_new(h1)=0;
            Gl_new(h0)=1;
            prior_new = 0;
            prior_old = 0;
            logl_new = Mloglike_m(Zl,Zlm,Apo_old,Tpo_old,Gpo_old,Gl_new,Pl(:,mc-1),delta_l,j);
            logl_old = Mloglike_m(Zl,Zlm,Apo_old,Tpo_old,Gpo_old,Gl_old,Pl(:,mc-1),delta_l,j);
            log_ratio = logl_new-logl_old;
        else %ADD OR DELETE
            h = unidrnd(p-j) + j; %randomly choosing the element to be updated
            Gl_new(h) = abs(Gl_old(h) - 1); %switch on(off)
            if Gl_new(h)==1
                logl_new = Mloglike_m(Zl,Zlm,Apo_old,Tpo_old,Gpo_old,Gl_new,Pl(:,mc-1),delta_l,j);
                logl_old = Mloglike_m(Zl,Zlm,Apo_old,Tpo_old,Gpo_old,Gl_old,Pl(:,mc-1),delta_l,j);
                prior_new = log(eta(mc-1));
                prior_old = log(1-eta(mc-1));
                log_ratio = logl_new-logl_old+prior_new-prior_old;
            elseif Gl_new(h)==0
                logl_new = Mloglike_m(Zl,Zlm,Apo_old,Tpo_old,Gpo_old,Gl_new,Pl(:,mc-1),delta_l,j);
                logl_old = Mloglike_m(Zl,Zlm,Apo_old,Tpo_old,Gpo_old,Gl_old,Pl(:,mc-1),delta_l,j);
                prior_old = log(eta(mc-1));
                prior_new = log(1-eta(mc-1));
                log_ratio = logl_new-logl_old+prior_new-prior_old;
            end
        end
        if  log_ratio > log(rand(1))
            Gl(j, :, mc) = Gl_new;
            ac_Gl = ac_Gl + 1;
            prior_tmp = prior_tmp + prior_new;
        else
            Gl(j, :, mc) = Gl_old;
            prior_tmp = prior_tmp + prior_old;
        end
    end
    Gl_old = Gl(:,:,mc);
    Gpl_old = logical(triu(kron(Gp(:,:,mc)+eye(r),Gl(:,:,mc)+eye(p)),1));
    Gpl(:,:,mc) = Gpl_old;
    Glo_old = logical(triu(kron(Gl(:,:,mc)+eye(p),Go(:,:,mc-1)+eye(q)),1));
    Glo(:,:,mc) = Glo_old;
    
    %UPDATE PI_LAMBDA
    %for i = 1:p
    Pl(:,mc) = plfix;%1/gamrnd(alpha_l+(sum(Gl(:,i,mc))+delta_l+sum(Gl(i, :, mc)))/2,1/(beta_l+Al(logical(Gl(:,i,mc)),i,mc)'*Tl(logical(Gl(:,i,mc)),logical(Gl(:,i,mc)),mc)^-1*Al(logical(Gl(:,i,mc)),i,mc)/2+1/2/Tl(i,i,mc)));
    %end
    %UPDATE ETA
    eta(mc) = betarnd(a_eta+sum(sum(Gl(:,:,mc))),b_eta+ p*(p-1)/2-sum(sum(Gl(:,:,mc))));
    
    
    
    %UPDATE A_LAMBDA AND T_LAMBDA
    
    Al_old = zeros(p);
    Tl_old = zeros(p,1);
    Tl_old(p) = 1;
    for i = 1:p-1
        Gl_tmp = Gl_old(i,:);
        n_l = sum(Gl_tmp);
        c = zeros(n_l,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        B = zeros(n_l);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
        %Iq = eye(q);
        %Ip = eye(p);
        %Zm = reshape(Z',q,p,n);
        for k=1:qr
            n_o = sum(Gpo_old(k,:));%n_\Omega^{(k)}
            B_tmp = 0;%B_\Lambda^{(j,k)}
            l = (i - 1) * qr + k;
            if n_l>0&&n_o>0
                Z_tmp2=reshape(Zlm(logical(Gpo_old(k,:)),logical(Gl_tmp),:),n_l*n_o,n);%Z_l^{(\Lambda\Omega)T}
                %Z_tmp2 = Z(:,logical(kron(Gl_tmp,Go(k,:,mc))))';%Z_l^{(\Lambda\Omega)T}
                %tmp = kron(eye(n_l),Ao(k,logical(Go(k,:,mc)))');
                if n_l==1
                    tmp = Apo_old(k,logical(Gpo_old(k,:)))';
                else
                    tmp = [Apo_old(k,logical(Gpo_old(k,:)))';zeros(n_l*n_o,1)];
                    tmp = [repmat(tmp,n_l-1,1);Apo_old(k,logical(Gpo_old(k,:)))'];
                    tmp = reshape(tmp,n_l*n_o,n_l);
                end
                tmp2 = tmp'*Z_tmp2;
                B_tmp = B_tmp + tmp2*tmp2';
            end
            if n_l>0
                Z_tmp3 = reshape(Zlm(k,logical(Gl_tmp),:),n_l,n)';
                %Z_tmp3 = Z(:,logical(kron(Gl_tmp,Iq(k,:))));%Z_l^{(\Lambda)}
                B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
            end
            if  n_l>0&&n_o>0
                tmp = tmp'*Z_tmp2*Z_tmp3;
                B_tmp = B_tmp + tmp + tmp';
            end
            B = B + B_tmp/Tpo_old(k);
            
            e = e + Zl(:,l)'*Zl(:,l)/2/Tpo_old(k);
            
            if n_o>0
                Z_tmp4 = reshape(Zlm(logical(Gpo_old(k,:)),i,:),n_o,n)';
                %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
                etmp = Apo_old(k,logical(Gpo_old(k,:)))*(Z_tmp4');
                %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
                %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
                e = e + (etmp*etmp' + 2*etmp*Zl(:,l))/2/Tpo_old(k);
            end
            if n_l>0
                c = c + (Zl(:,l)'*Z_tmp3)'/Tpo_old(k);
            end
            if n_l>0&&n_o>0
                Z_tmp5 = reshape(Z_tmp2*Zl(:,l),n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
                %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:,mc)))',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                Z_tmp6 = reshape(Z_tmp2*etmp',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                
                %c = c + (Ao(k,logical(Go(k,:,mc)))*Z_tmp5+ Ao(k,logical(Go(k,:,mc)))*Z_tmp6...
                %    +Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z_tmp3)'/To(k);
                c = c + (Apo_old(k,logical(Gpo_old(k,:)))*Z_tmp5+ Apo_old(k,logical(Gpo_old(k,:)))*Z_tmp6...
                    +etmp*Z_tmp3)'/Tpo_old(k);
            end
        end
        
        if n_l>0
            if n_l>1
                Sigma = B+diag(Pl(logical(Gl_tmp),mc).^-1);%inverse of \Sigma_\Lambda^{(j)}
            else
                Sigma = B+Pl(logical(Gl_tmp),mc).^-1;%inverse of \Sigma_\Lambda^{(j)}
            end
            R = chol(Sigma);
            Sigma_c = R\(R'\c);
            d = e - .5 * c' * (Sigma_c);
            z = randn(n_l,1);
            Tl_old(i) = 1/gamrnd((delta_l+n_l+n*qr)/2, 1/(1/2/Pl(i,mc)+d));            
            Al_old(i,logical(Gl_tmp)) = - (Sigma_c)' + sqrt(Tl_old(i))*(R\z)';
        else
            Tl_old(i) = 1/gamrnd((delta_l+n_l+n*qr)/2, 1/(1/2/Pl(i,mc)+e));
        end
    end
    Tpl_old = kron(Tp_old,Tl_old);
    Tlo_old = kron(Tl_old,To_old);
    Apl_old = triu(kron(Ap_old+eye(r),Al_old+eye(p)),1);
    Alo_old = triu(kron(Al_old+eye(p),Ao_old+eye(q)),1);
    Al(:,:,mc) = Al_old;
    Apl(:,:,mc) = Apl_old;
    Alo(:,:,mc) = Alo_old;
    Tl(:,mc) = Tl_old;
    Tpl(:,mc) = Tpl_old;
    Tlo(:,mc) = Tlo_old;
    
    
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %UPDATE OMEGA PARAMETERS
    
    %UPDATE GAMMA_OMEGA
    for k = 1:q-1
        
        Go_old = Go(k,:,mc-1); Go_new = Go_old;
        
        if sum(Go_old)>0&&sum(1-Go_old(k+1:q))>0&&unidrnd(2)==1 %SWAP
            pop1 = find(Go_old==1);
            pop0 = find(Go_old(k+1:q)==0)+k;
            h1 = pop1(randsample(length(find(pop1)),1));
            h0 = pop0(randsample(length(find(pop0)),1));
            Go_new(h1)=0;
            Go_new(h0)=1;
            
            logo_new = Mloglike_m(Zo,Zom,Apl_old,Tpl_old,Gpl_old,Go_new,Po(:,mc-1),delta_o,k);
            logo_old = Mloglike_m(Zo,Zom,Apl_old,Tpl_old,Gpl_old,Go_old,Po(:,mc-1),delta_o,k);
            log_ratio = logo_new-logo_old;
        else %ADD OR DELETE
            h = unidrnd(q-k) + k; %randomly choosing the element to be updated
            Go_new(h) = abs(Go_old(h) - 1); %switch on(off)
            if Go_new(h)==1
                logo_new = Mloglike_m(Zo,Zom,Apl_old,Tpl_old,Gpl_old,Go_new,Po(:,mc-1),delta_o,k);
                logo_old = Mloglike_m(Zo,Zom,Apl_old,Tpl_old,Gpl_old,Go_old,Po(:,mc-1),delta_o,k);                prior_new = log(rho(mc-1));
                prior_old = log(1-rho(mc-1));
                log_ratio = logo_new-logo_old+prior_new-prior_old;
            elseif Go_new(h)==0
                logo_new = Mloglike_m(Zo,Zom,Apl_old,Tpl_old,Gpl_old,Go_new,Po(:,mc-1),delta_o,k);
                logo_old = Mloglike_m(Zo,Zom,Apl_old,Tpl_old,Gpl_old,Go_old,Po(:,mc-1),delta_o,k);                prior_old = log(rho(mc-1));
                prior_new = log(1-rho(mc-1));
                log_ratio = logo_new-logo_old+prior_new-prior_old;
            end
        end
        if  log_ratio > log(rand(1))
            Go(k, :, mc) = Go_new;
            ac_Go = ac_Go + 1;
            prior_tmp = prior_tmp + prior_new;
        else
            Go(k, :, mc) = Go_old;
            prior_tmp = prior_tmp + prior_old;
        end
    end
    Go_old = Go(:,:,mc);
    Gpo_old = logical(triu(kron(Gp(:,:,mc)+eye(r),Go(:,:,mc)+eye(q)),1));
    Gpo(:,:,mc) = Gpo_old;
    Glo_old = logical(triu(kron(Gl(:,:,mc)+eye(p),Go(:,:,mc)+eye(q)),1));
    Glo(:,:,mc) = Glo_old;
    %UPDATE PI_LAMBDA
    %for i = 1:p
    Po(:,mc) = pofix;%1/gamrnd(alpha_l+(sum(Gl(:,i,mc))+delta_l+sum(Gl(i, :, mc)))/2,1/(beta_l+Al(logical(Gl(:,i,mc)),i,mc)'*Tl(logical(Gl(:,i,mc)),logical(Gl(:,i,mc)),mc)^-1*Al(logical(Gl(:,i,mc)),i,mc)/2+1/2/Tl(i,i,mc)));
    %end
    %UPDATE ETA
    rho(mc) = betarnd(a_rho+sum(sum(Go(:,:,mc))),b_rho+ q*(q-1)/2-sum(sum(Go(:,:,mc))));
    
    
    
    
    
    %UPDATE A_OMEGA AND T_OMEGA
    
    Ao_old = zeros(q);
    To_old = zeros(q,1);
    To_old(q) = 1;
    for i = 1:q-1
        Go_tmp = Go_old(i,:);
        n_o = sum(Go_tmp);
        c = zeros(n_o,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        B = zeros(n_o);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
        %Iq = eye(q);
        %Ip = eye(p);
        %Zm = reshape(Z',q,p,n);
        for k=1:pr
            n_p = sum(Gpl_old(k,:));%n_\Omega^{(k)}
            B_tmp = 0;%B_\Lambda^{(j,k)}
            l = (i - 1) * pr + k;
            if n_o>0&&n_p>0
                Z_tmp2=reshape(Zom(logical(Gpl_old(k,:)),logical(Go_tmp),:),n_o*n_p,n);%Z_l^{(\Lambda\Omega)T}
                %Z_tmp2 = Z(:,logical(kron(Gl_tmp,Go(k,:,mc))))';%Z_l^{(\Lambda\Omega)T}
                %tmp = kron(eye(n_o),Ao(k,logical(Go(k,:,mc)))');
                if n_o==1
                    tmp = Apl_old(k,logical(Gpl_old(k,:)))';
                else
                    tmp = [Apl_old(k,logical(Gpl_old(k,:)))';zeros(n_o*n_p,1)];
                    tmp = [repmat(tmp,n_o-1,1);Apl_old(k,logical(Gpl_old(k,:)))'];
                    tmp = reshape(tmp,n_o*n_p,n_o);
                end
                tmp2 = tmp'*Z_tmp2;
                B_tmp = B_tmp + tmp2*tmp2';
            end
            if n_o>0
                Z_tmp3 = reshape(Zom(k,logical(Go_tmp),:),n_o,n)';
                %Z_tmp3 = Z(:,logical(kron(Gl_tmp,Iq(k,:))));%Z_l^{(\Lambda)}
                B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
            end
            if  n_o>0&&n_p>0
                tmp = tmp'*Z_tmp2*Z_tmp3;
                B_tmp = B_tmp + tmp + tmp';
            end
            B = B + B_tmp/Tpl_old(k);
            
            e = e + Zo(:,l)'*Zo(:,l)/2/Tpl_old(k);
            
            if n_p>0
                Z_tmp4 = reshape(Zom(logical(Gpl_old(k,:)),i,:),n_p,n)';
                %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
                etmp = Apl_old(k,logical(Gpl_old(k,:)))*(Z_tmp4');
                %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
                %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
                e = e + (etmp*etmp' + 2*etmp*Zo(:,l))/2/Tpl_old(k);
            end
            if n_o>0
                c = c + (Zo(:,l)'*Z_tmp3)'/Tpl_old(k);
            end
            if n_o>0&&n_p>0
                Z_tmp5 = reshape(Z_tmp2*Zo(:,l),n_p,n_o);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
                %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:,mc)))',n_p,n_o);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                Z_tmp6 = reshape(Z_tmp2*etmp',n_p,n_o);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                
                %c = c + (Ao(k,logical(Go(k,:,mc)))*Z_tmp5+ Ao(k,logical(Go(k,:,mc)))*Z_tmp6...
                %    +Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z_tmp3)'/To(k);
                c = c + (Apl_old(k,logical(Gpl_old(k,:)))*Z_tmp5+ Apl_old(k,logical(Gpl_old(k,:)))*Z_tmp6...
                    +etmp*Z_tmp3)'/Tpl_old(k);
            end
        end
        
        if n_o>0
            if n_o>1
                Sigma = B+diag(Po(logical(Go_tmp),mc).^-1);%inverse of \Sigma_\Lambda^{(j)}
            else
                Sigma = B+Po(logical(Go_tmp),mc).^-1;%inverse of \Sigma_\Lambda^{(j)}
            end
            R = chol(Sigma);
            Sigma_c = R\(R'\c);
            d = e - .5 * c' * (Sigma_c);
            z = randn(n_o,1);
            To_old(i) = 1/gamrnd((delta_o+n_o+n*pr)/2, 1/(1/2/Po(i,mc)+d));
            Ao_old(i,logical(Go_tmp)) = - (Sigma_c)' + sqrt(To_old(i))*(R\z)';
        else
            To_old(i) = 1/gamrnd((delta_o+n_o+n*pr)/2, 1/(1/2/Po(i,mc)+e));
        end
    end
    Tpo_old = kron(Tp_old,To_old);
    Tlo_old = kron(Tl_old,To_old);
    Apo_old = triu(kron(Ap_old+eye(r),Ao_old+eye(q)),1);
    Alo_old = triu(kron(Al_old+eye(p),Ao_old+eye(q)),1);
    Ao(:,:,mc) = Ao_old;
    Apo(:,:,mc) = Apo_old;
    Alo(:,:,mc) = Alo_old;
    To(:,mc) = To_old;
    Tpo(:,mc) = Tpo_old;
    Tlo(:,mc) = Tlo_old;

end



Gp_rate = mean(Gp(:,:,burnin:mcsize),3);
Gp_est = Gp_rate > 0.5;
Gl_rate = mean(Gl(:,:,burnin:mcsize),3);
Gl_est = Gl_rate > 0.5;
Go_rate = mean(Go(:,:,burnin:mcsize),3);
Go_est = Go_rate > 0.5;


To_est = zeros(q,1);
Ao_est = zeros(q);
count_o = zeros(q,1);

for k = 1: q
    for mc=burnin:mcsize
        Go_tmp = Go(k,k+1:end,mc);
        if all(Go_tmp==Go_est(k,k+1:end))
            Ao_est(k,:) = Ao_est(k,:)+Ao(k,:,mc);
            To_est(k) = To_est(k) + To(k,mc);
            count_o(k) = count_o(k) + 1;
        end
    end
end

Ao_est = Ao_est./repmat(count_o,1,q);
To_est = To_est./count_o;




Tl_est = zeros(p,1);
Al_est = zeros(p);
count_l = zeros(p,1);
for j = 1: p
    for mc=burnin:mcsize
        Gl_tmp = Gl(j,j+1:end,mc);
        if all(Gl_tmp==Gl_est(j,j+1:end))
            Al_est(j,:) = Al_est(j,:)+Al(j,:,mc);
            count_l(j) = count_l(j) + 1;
            Tl_est(j) = Tl_est(j) + Tl(j,mc);
        end
    end
    
end
Al_est = Al_est./repmat(count_l,1,p);
Tl_est = Tl_est./count_l;

Tp_est = zeros(r,1);
Ap_est = zeros(r);
count_p = zeros(r,1);
for j = 1: r
    for mc=burnin:mcsize
        Gp_tmp = Gp(j,j+1:end,mc);
        if all(Gp_tmp==Gp_est(j,j+1:end))
            Ap_est(j,:) = Ap_est(j,:)+Ap(j,:,mc);
            count_p(j) = count_p(j) + 1;
            Tp_est(j) = Tp_est(j) + Tp(j,mc);
        end
    end
    
end
Ap_est = Ap_est./repmat(count_p,1,r);
Tp_est = Tp_est./count_p;


save('aDAG_PCGS.mat','Go_rate','Gl_rate','Gp_rate','Ao_est','To_est','Al_est','Tl_est','Ap_est','Tp_est')