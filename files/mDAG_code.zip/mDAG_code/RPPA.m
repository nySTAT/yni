function RPPA()
%RPPA_mixed2.m
seed=1;
rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end


plfix = 5;
pofix = 5;
asd = .5; %proposal sd for A_\Lambda and A_\Omega
To_var=1;%proposal variance of T_\Omega
Tl_var=1;
mcsize = 50000;%23 iterations are enough.......!!!!?????
burnin = mcsize/10;



%read data
data = csvread('RPPA_ABC_ordered.csv',1);
names = importdata('gene_names_ordered.txt');
n=31;
q=3;%condtions: A, B and C
p=50;%proteins
qp = q*p;
Z=reshape(data,n,qp);
mZ= mean(Z);
Z = Z - repmat(mZ,[n 1]);%center data
Zm = reshape(Z',q,p,n);

Zm = multi_dimension_transpose(Zm);
q = size(Zm,1);
p = size(Zm,2);





%%

Gl = zeros(p,p,mcsize);%\Gamma_\Lambda
Go = zeros(q,q,mcsize);%\Gamma_\Omega
Al = zeros(p,p,mcsize);%A_\Lambda
Ao = zeros(q,q,mcsize);
Tl = zeros(p,mcsize);%T_\Lambda
To = zeros(q,mcsize);
Pl = zeros(p,mcsize);%\Pi_\Lambda
Po = zeros(q,mcsize);%\Pi_\Omega
eta = zeros(mcsize,1);
rho = zeros(mcsize,1);
J = zeros(p,mcsize);
logpost = zeros(mcsize,1);
Adjl = zeros(p,p,mcsize);

% %initializing
% for i = 1:p-1
%     Gl(i,i+1:p,1) = binornd(1, .2,1,p-i);
% end
% for i = 1:q-1
%     Go(i,i+1:q,1) = binornd(1, .2,1,q-i);
% end
% Al(:,:,1) = (triu(randn(p),1)).*Gl(:,:,1);
% Ao(:,:,1) = (triu(randn(q),1)).*Go(:,:,1);

Tl(:,1) = rand(p,1);
Tl(p,:) = 1; %fix Tl(p,p,:)=1
To(:,1) = rand(q,1);

Pl(:,1) = plfix;
Po(:,1) = pofix;
eta(1)=.5;
rho(1)=.5;
J(:,1) = 1:p;
%Gl(:,:,1) = rchordal(p,0);
% o = fos(Gl(:,:,1));
% Gl(:,:,1)=triu(Gl(o,o,1));
Zm_old = Zm;
Z_old = reshape(Zm_old,qp,n)';
%J(:,1) = J(o,1);
%%hyperparameters
delta_o = 3; delta_l = 3; %same as Wang 2009
a_rho = .5; b_rho = .5;%beta for rho
a_eta = .5; b_eta = .5;%beta for eta
% alpha_o = 1/2; beta_o = n/2;
% alpha_l = 1/2; beta_l = n/2;







%%
tic;

ac_Gl = 0;
ac_Go = 0;


Gl_old = Gl(:,:,1);
Go_old = Go(:,:,1);
To_old = To(:,1);
Ao_old = Ao(:,:,1);
Tl_old = Tl(:,1);
Al_old = Al(:,:,1);
J_old = J(:,1);
Adjl_old = Adjl(:,:,1);
for mc = 2:mcsize
    
    
    
    %UPDATE LAMBDA PARAMETERS
    %UPDATE GAMMA_LAMBDA
    %if mc==2
    log_old = Mloglike_mt(Z_old,Zm_old,Ao(:,:,mc-1),To(:,mc-1),Go(:,:,mc-1),Gl_old,Pl(:,mc-1),delta_l,1);
    %end
    prior_tmp = 0;
    ac_tmp = 0;
    
    for jj = 1:p-1
        for hh = jj+1:p
            Adjl_new = Adjl_old;
            Gl_new = Gl_old;
            j = find(J_old==jj);
            h = find(J_old==hh);
            if j>h
                jtmp = j;
                j = h;
                h = jtmp;
            end
            Gl_new(j,h) = abs(Gl_old(j,h) - 1); %switch on(off)
            add = (Gl_new(j,h)==1);
            Adjl_new(jj,hh) = add; Adjl_new(hh,jj) = add;
            [ro,cho,~,~] = mymaxCardinalitySearch(Gl_new+Gl_new',p);
            if cho
                %disp([jj,hh])
                o = fliplr(ro);
                Zm_new = Zm_old(:,o,:);
                Z_new = reshape(Zm_new,qp,n)';
                add = (Gl_new(j,h)==1);
                Gl_new=Gl_new(o,o);
                Gl_new = triu(logical(Gl_new+Gl_new'));
                %                 if ~isequal(Gl_new,triu(Gl_new))
                %                     Gl_new = Gl_new';
                %                 end
                J_new = J_old(o);
                log_new = Mloglike_mt(Z_new, Zm_new,Ao(:,:,mc-1),To(:,mc-1),Go(:,:,mc-1),Gl_new,Pl(:,mc-1),delta_l,1);
                if add
                    prior_new = log(eta(mc-1));
                    prior_old = log(1-eta(mc-1));
                else
                    prior_new = log(1-eta(mc-1));
                    prior_old = log(eta(mc-1));
                end
                log_ratio = log_new-log_old+prior_new-prior_old;
                %disp(log_new-log_old)
                if  log_ratio > log(rand(1))
                    Gl_old = Gl_new;
                    Tl_old = Tl_old(o);
                    Al_old = Al_old(o,o);
                    Al_tmp = Al_old + 0./Al_old; %convert 0 to nan
                    Al_tmp2 = zeros(p,p,2);
                    Al_tmp2(:,:,1) = triu(Al_tmp,1);
                    Al_tmp2(:,:,2) = tril(Al_tmp,-1)';
                    Al_old = (nanmean(Al_tmp2,3));
                    Al_old(isnan(Al_old)) = 0;
                    Al_old(Gl_old==0)=0;
                    J_old = J_new;
                    Zm_old = Zm_new;
                    Z_old = Z_new;
                    log_old = log_new;
                    Adjl_old = Adjl_new;
                    ac_tmp = 1;
                    prior_old=prior_new;
                end
                prior_tmp = prior_tmp + prior_old;
            end
        end
    end
    
    
    ac_Gl = ac_Gl + ac_tmp;
    Gl(:,:,mc) = Gl_old;
    %Al(:,:,mc) = Al_old;
    %Tl(:,mc) = Tl_old;
    J(:,mc) = J_old;
    Adjl(:,:,mc) = Adjl_old;
    
    %UPDATE PI_LAMBDA
    %for i = 1:p
    %%%%%%if updating Pl or Po, need to consider adjusting ordering!!%%%%%
    Pl(:,mc) = plfix;%1/gamrnd(alpha_l+(sum(Gl(:,i,mc))+delta_l+sum(Gl(i, :, mc)))/2,1/(beta_l+Al(logical(Gl(:,i,mc)),i,mc)'*Tl(logical(Gl(:,i,mc)),logical(Gl(:,i,mc)),mc)^-1*Al(logical(Gl(:,i,mc)),i,mc)/2+1/2/Tl(i,i,mc)));
    %end
    %UPDATE ETA
    eta(mc) = betarnd(a_eta+sum(sum(Gl(:,:,mc))),b_eta+ p*(p-1)/2-sum(sum(Gl(:,:,mc))));
    
    
    %UPDATE A_LAMBDA AND T_LAMBDA    
    Al_old = zeros(p);
    Tl_old = zeros(p,1);
    for j = 1:p-1
        Gl_tmp = Gl_old(j,:);
        n_l = sum(Gl_tmp);
        c = zeros(n_l,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        B = zeros(n_l);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
        %Iq = eye(q);
        %Ip = eye(p);
        %Zm = reshape(Z',q,p,n);
        for k=1:q
            n_o = sum(Go_old(k,:));%n_\Omega^{(k)}
            B_tmp = 0;%B_\Lambda^{(j,k)}
            l = (j - 1) * q + k;
            if n_l>0&&n_o>0
                Z_tmp2=reshape(Zm_old(logical(Go_old(k,:)),logical(Gl_tmp),:),n_l*n_o,n);%Z_l^{(\Lambda\Omega)T}
                %Z_tmp2 = Z(:,logical(kron(Gl_tmp,Go(k,:,mc))))';%Z_l^{(\Lambda\Omega)T}
                %tmp = kron(eye(n_l),Ao(k,logical(Go(k,:,mc)))');
                if n_l==1
                    tmp = Ao_old(k,logical(Go_old(k,:)))';
                else
                    tmp = [Ao_old(k,logical(Go_old(k,:)))';zeros(n_l*n_o,1)];
                    tmp = [repmat(tmp,n_l-1,1);Ao_old(k,logical(Go_old(k,:)))'];
                    tmp = reshape(tmp,n_l*n_o,n_l);
                end
                tmp2 = tmp'*Z_tmp2;
                B_tmp = B_tmp + tmp2*tmp2';
            end
            if n_l>0
                Z_tmp3 = reshape(Zm_old(k,logical(Gl_tmp),:),n_l,n)';
                %Z_tmp3 = Z(:,logical(kron(Gl_tmp,Iq(k,:))));%Z_l^{(\Lambda)}
                B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
            end
            if  n_l>0&&n_o>0
                tmp = tmp'*Z_tmp2*Z_tmp3;
                B_tmp = B_tmp + tmp + tmp';
            end
            B = B + B_tmp/To_old(k);
            
            e = e + Z_old(:,l)'*Z_old(:,l)/2/To_old(k);
            
            %disp([1,k,e])
            if n_o>0
                Z_tmp4 = reshape(Zm_old(logical(Go_old(k,:)),j,:),n_o,n)';
                %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
                etmp = Ao_old(k,logical(Go_old(k,:)))*(Z_tmp4');
                %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
                %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
                e = e + (etmp*etmp' + 2*etmp*Z_old(:,l))/2/To_old(k);
            end
            %disp([2,k,e])
            if n_l>0
                c = c + (Z_old(:,l)'*Z_tmp3)'/To_old(k);
            end
            if n_l>0&&n_o>0
                Z_tmp5 = reshape(Z_tmp2*Z_old(:,l),n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
                %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:,mc)))',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                Z_tmp6 = reshape(Z_tmp2*etmp',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                
                %c = c + (Ao(k,logical(Go(k,:,mc)))*Z_tmp5+ Ao(k,logical(Go(k,:,mc)))*Z_tmp6...
                %    +Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z_tmp3)'/To(k);
                c = c + (Ao_old(k,logical(Go_old(k,:)))*Z_tmp5+ Ao_old(k,logical(Go_old(k,:)))*Z_tmp6...
                    +etmp*Z_tmp3)'/To_old(k);
            end
        end
        
        if n_l>0
            if n_l>1
                Sigma = B+diag(Pl(logical(Gl_tmp),mc).^-1);%inverse of \Sigma_\Lambda^{(j)}
            else
                Sigma = B+Pl(logical(Gl_tmp),mc).^-1;%inverse of \Sigma_\Lambda^{(j)}
            end
            R = chol(Sigma);
            Sigma_c = R\(R'\c);
            d = e - .5 * c' * (Sigma_c);
            z = randn(n_l,1);   
            Tl_old(j) = 1/gamrnd((delta_l+n_l+n*q)/2, 1/(1/2/Pl(j,mc)+d));
            Al_old(j,logical(Gl_tmp)) = - (Sigma_c)' + sqrt(Tl_old(j))*(R\z)';
        else
            Tl_old(j) = 1/gamrnd((delta_l+n_l+n*q)/2, 1/(1/2/Pl(j,mc)+e));
        end
    end
    
    
    e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
    for k=1:q
        n_o = sum(Go_old(k,:));%n_\Omega^{(k)}
        l = (p - 1) * q + k;
        e = e + Z_old(:,l)'*Z_old(:,l)/2/To_old(k);
        if n_o>0
            Z_tmp4 = reshape(Zm_old(logical(Go_old(k,:)),p,:),n_o,n)';
            %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
            etmp = Ao_old(k,logical(Go_old(k,:)))*(Z_tmp4');
            %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
            %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
            e = e + (etmp*etmp' + 2*etmp*Z_old(:,l))/2/To_old(k);
        end
    end
    Tl_old(p) = 1/gamrnd((delta_l+n*q)/2, 1/(1/2/Pl(p,mc)+e));
    Al(:,:,mc) = Al_old;
    Tl(:,mc) = Tl_old;
    
    
    
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %UPDATE OMEGA PARAMETERS
    
    %UPDATE GAMMA_OMEGA
    Zm2_old = multi_dimension_transpose(Zm_old);
    Z2_old = reshape(Zm2_old,qp,n)';
    ac_tmp = 0;
    for k = 1:q-1
        
        Go_old = Go(k,:,mc-1); Go_new = Go_old;
        
        if sum(Go_old)>0&&sum(1-Go_old(k+1:q))>0&&unidrnd(2)==1 %SWAP
            pop1 = find(Go_old==1);
            pop0 = find(Go_old(k+1:q)==0)+k;
            h1 = pop1(randsample(length(find(pop1)),1));
            h0 = pop0(randsample(length(find(pop0)),1));
            Go_new(h1)=0;
            Go_new(h0)=1;
            
            logo_new = Mloglike_m(Z2_old,Zm2_old,Al(:,:,mc),Tl(:,mc),Gl(:,:,mc),Go_new,Po(:,mc-1),delta_o,k);
            logo_old = Mloglike_m(Z2_old,Zm2_old,Al(:,:,mc),Tl(:,mc),Gl(:,:,mc),Go_old,Po(:,mc-1),delta_o,k);
            log_ratio = logo_new-logo_old;
        else %ADD OR DELETE
            h = unidrnd(q-k) + k; %randomly choosing the element to be updated
            Go_new(h) = abs(Go_old(h) - 1); %switch on(off)
            if Go_new(h)==1
                logo_new = Mloglike_m(Z2_old,Zm2_old,Al(:,:,mc),Tl(:,mc),Gl(:,:,mc),Go_new,Po(:,mc-1),delta_o,k);
                logo_old = Mloglike_m(Z2_old,Zm2_old,Al(:,:,mc),Tl(:,mc),Gl(:,:,mc),Go_old,Po(:,mc-1),delta_o,k);
                prior_new = log(rho(mc-1));
                prior_old = log(1-rho(mc-1));
                log_ratio = logo_new-logo_old+prior_new-prior_old;
            elseif Go_new(h)==0
                logo_new = Mloglike_m(Z2_old,Zm2_old,Al(:,:,mc),Tl(:,mc),Gl(:,:,mc),Go_new,Po(:,mc-1),delta_o,k);
                logo_old = Mloglike_m(Z2_old,Zm2_old,Al(:,:,mc),Tl(:,mc),Gl(:,:,mc),Go_old,Po(:,mc-1),delta_o,k);
                prior_old = log(rho(mc-1));
                prior_new = log(1-rho(mc-1));
                log_ratio = logo_new-logo_old+prior_new-prior_old;
            end
        end
        if  log_ratio > log(rand(1))
            Go(k, :, mc) = Go_new;
            ac_tmp = 1;
            prior_tmp = prior_tmp + prior_new;
        else
            Go(k, :, mc) = Go_old;
            prior_tmp = prior_tmp + prior_old;
        end
    end
    ac_Go = ac_Go + ac_tmp;
    %UPDATE PI_LAMBDA
    %for i = 1:p
    Po(:,mc) = pofix;%1/gamrnd(alpha_l+(sum(Gl(:,i,mc))+delta_l+sum(Gl(i, :, mc)))/2,1/(beta_l+Al(logical(Gl(:,i,mc)),i,mc)'*Tl(logical(Gl(:,i,mc)),logical(Gl(:,i,mc)),mc)^-1*Al(logical(Gl(:,i,mc)),i,mc)/2+1/2/Tl(i,i,mc)));
    %end
    %UPDATE ETA
    rho(mc) = betarnd(a_rho+sum(sum(Go(:,:,mc))),b_rho+ q*(q-1)/2-sum(sum(Go(:,:,mc))));
    
    
    
    %UPDATE A_OMEGA AND T_OMEGA
    Go_old = Go(:,:,mc);
    Ao_old = zeros(q);
    To_old = zeros(q,1);
    for k = 1:q-1
        Go_tmp = Go_old(k,:);
        n_o = sum(Go_tmp);
        c = zeros(n_o,1);%\sum_{k=1}^q\frac{c_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        B = zeros(n_o);%\sum_{k=1}^q\frac{B_\Lambda^{(j,k)}}{T_\Omega^{(k)}}
        e = 0;%\sum_{k=1}^q\frac{e_\Lambda^{(j,k)}}{2T_\Omega^{(k)}}
        %Iq = eye(q);
        %Ip = eye(p);
        %Zm = reshape(Z',q,p,n);
        for j=1:p
            n_l = sum(Gl_old(j,:));%n_\Omega^{(k)}
            B_tmp = 0;%B_\Lambda^{(j,k)}
            l = (k - 1) * p + j;
            if n_l>0&&n_o>0
                Z_tmp2=reshape(Zm2_old(logical(Gl_old(j,:)),logical(Go_tmp),:),n_l*n_o,n);%Z_l^{(\Lambda\Omega)T}
                %Z_tmp2 = Z(:,logical(kron(Gl_tmp,Go(k,:,mc))))';%Z_l^{(\Lambda\Omega)T}
                %tmp = kron(eye(n_l),Ao(k,logical(Go(k,:,mc)))');
                if n_o==1
                    tmp = Al_old(j,logical(Gl_old(j,:)))';
                else
                    tmp = [Al_old(j,logical(Gl_old(j,:)))';zeros(n_l*n_o,1)];
                    tmp = [repmat(tmp,n_o-1,1);Al_old(j,logical(Gl_old(j,:)))'];
                    tmp = reshape(tmp,n_l*n_o,n_o);
                end
                tmp2 = tmp'*Z_tmp2;
                B_tmp = B_tmp + tmp2*tmp2';
            end
            if n_o>0
                Z_tmp3 = reshape(Zm2_old(j,logical(Go_tmp),:),n_o,n)';
                %Z_tmp3 = Z(:,logical(kron(Gl_tmp,Iq(k,:))));%Z_l^{(\Lambda)}
                B_tmp = B_tmp + Z_tmp3'*Z_tmp3;
            end
            if  n_l>0&&n_o>0
                tmp = tmp'*Z_tmp2*Z_tmp3;
                B_tmp = B_tmp + tmp + tmp';
            end
            B = B + B_tmp/Tl_old(j);
            
            e = e + Z2_old(:,l)'*Z2_old(:,l)/2/Tl_old(j);
            
            %disp([1,k,e])
            if n_l>0
                Z_tmp4 = reshape(Zm2_old(logical(Gl_old(j,:)),k,:),n_l,n)';
                %Z_tmp4 = Z(:,logical(kron(Ip(j,:),Go(k,:,mc))));%Z_l^{(\Omega)}
                etmp = Al_old(j,logical(Gl_old(j,:)))*(Z_tmp4');
                %e = e + (Ao(k,logical(Go(k,:,mc)))*(Z_tmp4')*Z_tmp4*Ao(k,logical(Go(k,:,mc)))'...
                %    + 2*Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z(:,l))/2/To(k);
                e = e + (etmp*etmp' + 2*etmp*Z2_old(:,l))/2/Tl_old(j);
            end
            %disp([2,k,e])
            if n_o>0
                c = c + (Z2_old(:,l)'*Z_tmp3)'/Tl_old(j);
            end
            if n_l>0&&n_o>0
                Z_tmp5 = reshape(Z_tmp2*Z2_old(:,l),n_l,n_o);%(Z_l^{(\Lambda\Omega)T}Z_l)^m
                %Z_tmp6 = reshape(Z_tmp2*Z_tmp4*Ao(k,logical(Go(k,:,mc)))',n_o,n_l);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                Z_tmp6 = reshape(Z_tmp2*etmp',n_l,n_o);%(Z_l^{(\Lambda\Omega)T}Z_l^{(\Omega)}A_\Omega^{(k,k+1:q)T})^m
                
                %c = c + (Ao(k,logical(Go(k,:,mc)))*Z_tmp5+ Ao(k,logical(Go(k,:,mc)))*Z_tmp6...
                %    +Ao(k,logical(Go(k,:,mc)))*Z_tmp4'*Z_tmp3)'/To(k);
                c = c + (Al_old(j,logical(Gl_old(j,:)))*Z_tmp5+ Al_old(j,logical(Gl_old(j,:)))*Z_tmp6...
                    +etmp*Z_tmp3)'/Tl_old(j);
            end
        end
        
        if n_o>0
            if n_o>1
                Sigma = B+diag(Po(logical(Go_tmp),mc).^-1);%inverse of \Sigma_\Lambda^{(j)}
            else
                Sigma = B+Po(logical(Go_tmp),mc).^-1;%inverse of \Sigma_\Lambda^{(j)}
            end
            R = chol(Sigma);
            Sigma_c = R\(R'\c);
            d = e - .5 * c' * (Sigma_c);
            z = randn(n_o,1);
            To_old(k) = 1/gamrnd((delta_o+n_o+n*p)/2, 1/(1/2/Po(k,mc)+d));
            Ao_old(k,logical(Go_tmp)) = - (Sigma_c)' + sqrt(To_old(k))*(R\z)';
        else
            To_old(k) = 1/gamrnd((delta_o+n_o+n*p)/2, 1/(1/2/Po(k,mc)+e));
        end
    end
    To_old(q) = 1;
    Ao(:,:,mc) = Ao_old;
    To(:,mc) = To_old;
    
    
    
    %log posterior
    logpost(mc) = log_old + prior_tmp; %kinda problematic: logo or logl?
    

end
time=toc;


ac_Gl = ac_Gl/(mcsize-1);
ac_Go = ac_Go/(mcsize-1);


%%Model estimation
%highest probability model
[G_visited,freq,~]=hiprob2([reshape(Adjl(:,:,burnin:mcsize),p^2,[])',reshape(Go(:,:,burnin:mcsize),q^2,[])']);
G_vec = G_visited(1,:);
Gl_est2 = triu(reshape(G_vec(1:p^2),p,p));
Go_est2 = triu(reshape(G_vec(p^2+1:p^2+q^2),q,q));
%G_est2 = kron(Gl_est2+eye(p),Go_est2+eye(q));
%G_est2 = logical(triu(kron(Gl_est2+Gl_est2'+eye(p),Go_est2+Go_est2'+eye(q))));






%median model
rJ=[];
Gl_reorder = zeros(p,p);
Tl_reorder= zeros(p,1);
for mc=burnin:mcsize
    rJ(J(:,mc))=1:p;
    Gl_reorder = Gl_reorder + triu(logical(Gl(rJ,rJ,mc)+Gl(rJ,rJ,mc)'));
    Tl_reorder = Tl_reorder + Tl(rJ,mc);
end
Gl_rate = Gl_reorder/(mcsize-burnin+1);
Gl_est = Gl_rate>0.5;
Tl_est = Tl_reorder/(mcsize-burnin+1);

Go_rate = mean(Go(:,:,burnin:mcsize),3);
Go_est = Go_rate > 0.5;

%G_est = logical(triu(kron(Gl_est+Gl_est'+eye(p),Go_est+Go_est'+eye(q))));





%precision estimation
%median model
Al_est = zeros(p);
Lambda_est = zeros(p);
count_l = 0;
for mc = burnin:mcsize
    rJ(J(:,mc))=1:p;
    if all(all(Gl_est==triu(logical(Gl(rJ,rJ,mc)+Gl(rJ,rJ,mc)'))))
        Al_tmp = Al(rJ,rJ,mc);
        Al_tmp = Al_tmp + 0./Al_tmp; %convert 0 to nan
        Al_tmp2 = zeros(p,p,2);
        Al_tmp2(:,:,1) = triu(Al_tmp,1);
        Al_tmp2(:,:,2) = tril(Al_tmp,-1)';
        Al_tmp = (nanmean(Al_tmp2,3));
        Al_tmp(isnan(Al_tmp)) = 0;
        Al_est = Al_est + Al_tmp;
        Lambda_tmp = (Al(:,:,mc)+eye(p))'*diag(Tl(:,mc).^-1)*(Al(:,:,mc)+eye(p));
        Lambda_tmp = Lambda_tmp(rJ,rJ);
        Lambda_est = Lambda_est + Lambda_tmp;
        %         if ~all(all((Al_tmp(Gl_est==0)==0)))
        %             mc
        %         end
        count_l = count_l+1;
    end
end
Al_est = Al_est/count_l;
Lambda_est = Lambda_est/count_l;

To_est = zeros(q,1);
Ao_est = zeros(q);
count_o = zeros(q,1);

for k = 1: q
    for mc=burnin:mcsize
        Go_tmp = Go(k,k+1:end,mc);
        if all(Go_tmp==Go_est(k,k+1:end))
            Ao_est(k,:) = Ao_est(k,:)+Ao(k,:,mc);
            To_est(k) = To_est(k) + To(k,mc);
            count_o(k) = count_o(k) + 1;
        end
    end
end

Ao_est = Ao_est./repmat(count_o,1,q);
To_est = To_est./count_o;
Omega_est = (Ao_est+eye(q))'*diag(To_est.^-1)*(Ao_est+eye(q));


%highest posterior model
Al_est2 = zeros(p);
Lambda_est2 = zeros(p);
count_l = 0;
for mc = burnin:mcsize
    rJ(J(:,mc))=1:p;
    if all(all(Gl_est2==triu(logical(Gl(rJ,rJ,mc)+Gl(rJ,rJ,mc)'))))
        Al_tmp = Al(rJ,rJ,mc);
        Al_tmp = Al_tmp + 0./Al_tmp; %convert 0 to nan
        Al_tmp2 = zeros(p,p,2);
        Al_tmp2(:,:,1) = triu(Al_tmp,1);
        Al_tmp2(:,:,2) = tril(Al_tmp,-1)';
        Al_tmp = (nanmean(Al_tmp2,3));
        Al_tmp(isnan(Al_tmp)) = 0;
        Al_est2 = Al_est2 + Al_tmp;
        Lambda_tmp = (Al(:,:,mc)+eye(p))'*diag(Tl(:,mc).^-1)*(Al(:,:,mc)+eye(p));
        Lambda_tmp = Lambda_tmp(rJ,rJ);
        Lambda_est2 = Lambda_est2 + Lambda_tmp;
        %         if ~all(all((Al_tmp(Gl_est2==0)==0)))
        %             mc
        %         end
        count_l = count_l+1;
    end
end
Al_est2 = Al_est2/count_l;
Lambda_est2 = Lambda_est2/count_l;


To_est2 = zeros(q,1);
Ao_est2 = zeros(q);
count_o = zeros(q,1);
for k = 1: q
    for mc=burnin:mcsize
        Go_tmp = Go(k,k+1:end,mc);
        if all(Go_tmp==Go_est2(k,k+1:end))
            Ao_est2(k,:) = Ao_est2(k,:)+Ao(k,:,mc);
            count_o(k) = count_o(k) + 1;
            To_est2(k) = To_est2(k) + To(k,mc);
        end
    end
end
Ao_est2 = Ao_est2./repmat(count_o,1,q);
To_est2 = To_est2./count_o;
Omega_est2 = (Ao_est2+eye(q))'*diag(To_est2.^-1)*(Ao_est2+eye(q));





save('RPPA.mat','Go_rate','Gl_rate')
