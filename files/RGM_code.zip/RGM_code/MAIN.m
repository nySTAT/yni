clear
seed=1;

%fake data
x=rand(100,20);
y=rand(100,10);

%provided x and y are loaded
n=size(y,1);
p=size(y,2);
pp = p^2-p;
q=2*ones(1,p); %q[j]: number of x-variables that correspond to y[j]; Ge Tian--that will correspond to how many SNPs you would like to use for each trait
q_cum=cumsum(q);
q_cum=[0,q_cum];
Q=q_cum(p+1);

%%
tic;
rng(seed);
%MCMC parameters
M = 50000;%number of total iterations
burnin=M/2;%burn-in
thin=5;%thinning
%hyper-parameters
A0_var = .5;
B0_var = .5;
T_sd= .5;
a_sig=.01; b_sig=.01;
a_tau=.01; b_tau=.01;
b_t = 1;

%initialization
ac_A0 = 0;
ac_B0 = 0;
ac_T = 0;
I = eye(p);
A = zeros(p,p,1,(M-burnin)/thin);
A0 = zeros(p,p,1,(M-burnin)/thin); %a tilde
B = zeros(p,Q,1,(M-burnin)/thin);
B0 = zeros(p,Q,1,(M-burnin)/thin);
T = zeros(p,(M-burnin)/thin); %threshold
Sigma = ones(p,(M-burnin)/thin);
tau_A = zeros(p,p,(M-burnin)/thin);
tau_B = zeros(p,Q,(M-burnin)/thin);
A0_old = zeros(p,p,1);%A tilde
B0_old = zeros(p,Q,1);
T_old = zeros(p,1);
A_old = repmat(I,[1,1,1])-A0_old.*(abs(A0_old)>repmat(T_old,[1,p,1])); %(I-A)
B_old = B0_old.*(abs(B0_old)>repmat(T_old,[1,Q,1])); %(I-A)
Sigma_old = Sigma(:,1);
tau_A_old = .5*ones(p,p);
tau_B_old = .5*ones(p,Q);
SSE_old = zeros(p,1);
A_tmp = zeros(p,p,1);
ind_mat_A = zeros(pp,1);
for i = 1:p
    for j=1:p
        if i~=j
            for k = 1:1
                A_tmp(i,j,k)=sub2ind([p,p,1],i,j,k);
            end
        end
    end
end
kk=0;
for i =1:p
    for j =1:p
        if i~=j
            kk=kk+1;
            ind_mat_A(kk,:)=A_tmp(i,j,:);
        end
    end
end
B_tmp = zeros(p,Q,1);
ind_mat_B = zeros(Q,1);
for i = 1:p
    for j = (q_cum(i)+1):q_cum(i+1)
        for k = 1:1
            B_tmp(i,j,k)=sub2ind([p,Q,1],i,j,k);
        end
    end
end
kk=0;
for i =1:p
    for j =(q_cum(i)+1):q_cum(i+1)
        kk=kk+1;
        ind_mat_B(kk,:)=B_tmp(i,j,:);
    end
end
for i = 1:p
    for k =1:1
        SSE_old(i,k) = sum((y((k-1)*n/1+1:k*n/1,:)*A_old(i,:,k)'-x((k-1)*n/1+1:k*n/1,:)*B_old(i,:,k)').^2);
    end
end

iter=0;

%MCMC starts here....
for mc = 2:M
   
    %update tau
    for i = 1:p
        for j = 1:p
            if i~=j
                tau_A_old(i,j)=1/gamrnd(a_tau+1/2,1/(b_tau+squeeze(A0_old(i,j,:))'*squeeze(A0_old(i,j,:))/2));
            end
        end
    end
    for i = 1:p
        for j = (q_cum(i)+1):q_cum(i+1)
            tau_B_old(i,j)=1/gamrnd(a_tau+1/2,1/(b_tau+squeeze(B0_old(i,j,:))'*squeeze(B0_old(i,j,:))/2));
        end
    end
    
    
    %update Sigma
    for i =1:p
        Sigma_old(i)= 1/gamrnd(a_sig+n/2,1/(b_sig+sum(SSE_old(i,:))/2));
    end
    %Sigma_old = Sigma_true;%!!!!
    %update A0
    A0_new = A0_old;
    %SSE_new=SSE_old;
    A_new = A_old;
    ll_old = sum(logmvnpdf(y*(A_old(:,:,k)')-x*B_old(:,:,k)',0,diag(Sigma_old)))+n*log(abs(det(A_old(:,:,k))));
    for i=1:p
        for j =1:p
            if i~=j
                for k = 1:1
                    A0_new(i,j,k) = A0_old(i,j,k)+A0_var*randn(1);
                    %A0_new(i,j,k) = mvnrnd(squeeze(A0_old(i,j,k)),A0_var);
                    %A0_new(i,j,:) = A0_true(i,j,:);%!!!!
                    %A_new(i,j,:) = -A0_new(i,j,:).*(abs(A0_new(i,j,:))>repmat(T_old(i),[1,1,1]));
                    A_new(i,j,k) = -A0_new(i,j,k).*(abs(A0_new(i,j,k))>T_old(i));
                    
                    ll_new = sum(logmvnpdf(y*(A_new(:,:,k)')-x*B_old(:,:,k)',0,diag(Sigma_old)))+n*log(abs(det(A_new(:,:,k))));
                    lr = ll_new-ll_old-squeeze(A0_new(i,j,:))'*squeeze(A0_new(i,j,:))/2/tau_A_old(i,j)+squeeze(A0_old(i,j,:))'*squeeze(A0_old(i,j,:))/2/tau_A_old(i,j);
                    if lr > log(rand(1))
                        ac_A0 = ac_A0 + 1;
                        ll_old=ll_new;
                        %SSE_old(i,:)=SSE_new(i,:);
                        A_old(i,j,:)=A_new(i,j,:);
                        A0_old(i,j,:)=A0_new(i,j,:);
                    else
                        %SSE_new(i,k)=SSE_old(i,k);
                        A_new(i,j,k)=A_old(i,j,k);
                        A0_new(i,j,k)=A0_old(i,j,k);
                    end
                end
            end
        end
    end
    B0_new = B0_old;
    %SSE_new=SSE_old;
    B_new = B_old;
    for i=1:p
        for j = (q_cum(i)+1):q_cum(i+1)
            for k = 1:1
                B0_new(i,j,k) = B0_old(i,j,k)+B0_var*randn(1);
                B_new(i,j,k) = B0_new(i,j,k).*(abs(B0_new(i,j,k))>T_old(i));
                ll_new = sum(logmvnpdf(y*(A_old(:,:,k)')-x*B_new(:,:,k)',0,diag(Sigma_old)))+n*log(abs(det(A_old(:,:,k))));
                lr = ll_new-ll_old-squeeze(B0_new(i,j,:))'*squeeze(B0_new(i,j,:))/2/tau_B_old(i,j)+squeeze(B0_old(i,j,:))'*squeeze(B0_old(i,j,:))/2/tau_B_old(i,j);
                if lr > log(rand(1))
                    ac_B0 = ac_B0 + 1;
                    ll_old=ll_new;
                    %SSE_old(i,:)=SSE_new(i,:);
                    B_old(i,j,:)=B_new(i,j,:);
                    B0_old(i,j,:)=B0_new(i,j,:);
                else
                    %SSE_new(i,k)=SSE_old(i,k);
                    B_new(i,j,k)=B_old(i,j,k);
                    B0_new(i,j,k)=B0_old(i,j,k);
                end
            end
        end
    end
    %update T
    for i = 1:p
        for k =1:1
            SSE_old(i,k) = sum((y((k-1)*n/1+1:k*n/1,:)*A_old(i,:,k)'-x((k-1)*n/1+1:k*n/1,:)*B_old(i,:,k)').^2);
        end
    end
    SSE_new=SSE_old;
    for i=1:p
        T_new = rtnorm(T_old(i),T_sd,0,b_t);
        %T_new = T_old(i);%!!!!
        A_new = squeeze(-A0_old(i,:,:).*(abs(A0_old(i,:,:))>T_new));
        B_new = squeeze(B0_old(i,:,:).*(abs(B0_old(i,:,:))>T_new));
        if 1 ~=1
            A_new(i,:)=1;
            for k =1:1
                SSE_new(i,k) = sum((y((k-1)*n/1+1:k*n/1,:)*A_new(:,k)-x((k-1)*n/1+1:k*n/1,:)*B_new(:,k)).^2);
            end
        else
            A_new(i)=1;
            SSE_new(i) = sum((y*A_new'-x*B_new').^2);
        end
        ll_old = -sum(SSE_old(i,:))/2/Sigma_old(i);
        ll_new = -sum(SSE_new(i,:))/2/Sigma_old(i);
        lr = ll_new-ll_old+log(dtnorm(T_old(i),T_new,T_sd,0,b_t)) - log(dtnorm(T_new,T_old(i),T_sd,0,b_t));
        if lr>log(rand(1))
            ac_T = ac_T + 1;
            T_old(i) = T_new;
            SSE_old(i,:)=SSE_new(i,:);
            A_old(i,:,:)=A_new;
            B_old(i,:,:)=B_new;
        else
            SSE_new(i,:)=SSE_old(i,:);
        end
    end
    
    if mod(mc,thin)==0&&mc>burnin
        iter = iter+1;
        A(:,:,:,iter) = A_old;
        A0(:,:,:,iter) = A0_old; %a tilde
        B(:,:,:,iter) = B_old;
        B0(:,:,:,iter) = B0_old; %a tilde
        T(:,iter) = T_old; %threshold
        Sigma(:,iter) = Sigma_old;
        tau_A(:,:,iter) = tau_A_old;
        tau_B(:,:,iter) = tau_B_old;
    end
end
%end of MCMC

%acceptance rate
ac_A0 = ac_A0/pp/(M-1)/1;
ac_B0 = ac_B0/Q/(M-1)/1;
ac_T = ac_T/p/(M-1);

%point estimator
Ga_A_rate = 0;%regression strucutre
for mc = 1:(M-burnin)/thin
    A(:,:,:,mc)=-A(:,:,:,mc)+repmat(I,[1,1,1]);%transform back to A from (I-A)
    Ga_A_rate = Ga_A_rate+(A(:,:,:,mc)~=0);
end
Ga_A_rate = Ga_A_rate/((M-burnin)/thin);
Ga_A_est = Ga_A_rate>.5;
A_est = zeros(p,p,1);
count_A=zeros(1,1);
for k=1:1
    for mc = 1:(M-burnin)/thin
        if (A(:,:,k,mc)~=0)==Ga_A_est(:,:,k)
            count_A(k) = count_A(k)+1;
            A_est(:,:,k)=A_est(:,:,k)+A(:,:,k,mc);
        end
    end
    A_est(:,:,k)=A_est(:,:,k)/count_A(k);
end
A_est = mean(A,4);
A_est= A_est.*Ga_A_est;

Ga_B_rate = 0;%regression strucutre
for mc = 1:(M-burnin)/thin
    Ga_B_rate = Ga_B_rate+(B(:,:,:,mc)~=0);
end
Ga_B_rate = Ga_B_rate/((M-burnin)/thin);
Ga_B_est = Ga_B_rate>.5;
B_est = zeros(p,Q,1);
count_B=zeros(1,1);
for k=1:1
    for mc = 1:(M-burnin)/thin
        if (B(:,:,k,mc)~=0)==Ga_B_est(:,:,k)
            count_B(k) = count_B(k)+1;
            B_est(:,:,k)=B_est(:,:,k)+B(:,:,k,mc);
        end
    end
    B_est(:,:,k)=B_est(:,:,k)/count_B(k);
end
B_est = mean(B,4);
B_est= B_est.*Ga_B_est;

T_est = mean(T,2);
tau_A_est = mean(tau_A,3);
tau_B_est = mean(tau_B,3);
Sigma_est = mean(Sigma,2);
time=toc;

cutoff=.65; %probability cutoff for edge selection Ge Tian--- default choice can be 0.5 but you can vary it to achieve posterior expected FDR (computed below)
Ga_A_est=Ga_A_rate>cutoff;
Ga_B_est=Ga_B_rate>cutoff;
(sum(sum(Ga_A_est.*(1-Ga_A_rate)))+sum(sum(Ga_B_est.*(1-Ga_B_rate))))/(sum(sum(Ga_A_est))+sum(sum(Ga_B_est))) %posterior expected FDR
%Ga_A_est: non-zero patterns in A
%Ga_B_est: non-zero patterns in A
%A_est: estimated A
%B_est: estimated B

