
t_true = 0.1;    
cpara=-.39;%censoring parameter: 62.5% on average across 50 seeds
seed=1;
q=1;
r=0;
p=10;
n=200;
noise=1;
nt = n;
seed_g=1;
rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed_g);
end

x = cell(p,1);
xt = cell(p,1);

for j = 1:p
    x{j} = stdize(randn(n,q));%continuous
    xt{j} = stdize(randn(nt,q));%testing
end

v0_true = zeros(n+nt,p);
v0_true(:,1)=-1;
v0_true(:,2)=-2*[x{2}(:,1);xt{2}(:,1)];
%v0_true(:,3)=2*(sin(2*pi*[x{3}(:,1);xt{3}(:,1)])./(2-sin(2*pi*[x{3}(:,1);xt{3}(:,1)])));
v0_true(:,3)=1*[x{3}(:,1);xt{3}(:,1)].^2-1;
v0_true(:,4)=2*sin(1/2*pi*[x{4}(:,1);xt{4}(:,1)]);

v_true = threshold(v0_true,t_true);
v_test = v_true(n+1:n+nt,:);
v_true = v_true(1:n,:);
utrue = v_true~=0;
u_test = v_test~=0;
v0_test= v0_true(n+1:n+nt,:);
v0_true = v0_true(1:n,:);
dens = sum(sum(utrue))/n/p;
fprintf('density (1-sparsity) is %f\n',dens)
%boxplot(reshape(v0_true,n*p,1))
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end
%u = 2*rand(n,p)-1;%regressors
u = stdize(randn(n,p));
u(:,1)=1;%intercept
%ut = 2*rand(nt,p)-1;%testing regressors
ut = stdize(randn(nt,p));
ut(:,1)=1;%testing intercept


lp = sum(u.*v_true,2); %linear predictor
lpt = sum(ut.*v_test,2);%linear predictor

link = exp(lp);
y = zeros(n,2);
ytmp=wblrnd(1./link,1/noise);%true survival times
c=exp(randn(n,1)+cpara);%censoring times
y(:,2) = (ytmp<c);%censoring indicator
fprintf('percentage of censoring is %f\n',mean(1-y(:,2)))
y(:,1)=min(ytmp,c);%censored survival times
%testing
linkt = exp(lpt);
yt=wblrnd(1./linkt,1/noise);%true survival times
c=exp(randn(nt,1)+cpara);%censoring times
fprintf('percentage of testing censoring is %f\n',mean(yt>c))
%yt=min(yt,c);%censored survival times

max(y)
%hist(link)
%hist(lp)
%for uploaded examples
csvwrite('y.csv',y)
csvwrite('P.csv',u)
csvwrite('Pt.csv',ut)
xx=zeros(n,p);
xxt=zeros(nt,p);
for i=1:p
    xx(:,i)=x{i};
    xxt(:,i)=xt{i};
end
csvwrite('G.csv',xx)
csvwrite('GT.csv',xxt)


