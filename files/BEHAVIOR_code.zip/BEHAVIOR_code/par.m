function par(s,b)
if isdeployed
    b = str2num(b);
end
if b==1
    parpool(17);
    parfor seed=1:17
        GVSM(s,seed)
    end
elseif b==2
    parpool(17);
    parfor seed=18:34
        GVSM(s,seed)
    end
else
    parpool(17);
    parfor seed=35:50
        GVSM(s,seed)
    end
end

% if b==1
%     parpool(24);
%     parfor seed=1:5
%         GVSM(s,seed)
%     end
% elseif b==2
%     parpool(24);
%     parfor seed=6:10
%         GVSM(s,seed)
%     end
% elseif b==3
%     parpool(24);
%     parfor seed=11:15
%         GVSM(s,seed)
%     end
% elseif b==4
%     parpool(24);
%     parfor seed=16:20
%         GVSM(s,seed)
%     end
% elseif b==5
%     parpool(24);
%     parfor seed=21:25
%         GVSM(s,seed)
%     end
% elseif b==6
%     parpool(24);
%     parfor seed=26:30
%         GVSM(s,seed)
%     end
% elseif b==7
%     parpool(24);
%     parfor seed=31:35
%         GVSM(s,seed)
%     end
% elseif b==8
%     parpool(24);
%     parfor seed=36:40
%         GVSM(s,seed)
%     end
% elseif b==9
%     parpool(24);
%     parfor seed=41:45
%         GVSM(s,seed)
%     end
% else
%     parpool(24);
%     parfor seed=46:50
%         GVSM(s,seed)
%     end
% end
