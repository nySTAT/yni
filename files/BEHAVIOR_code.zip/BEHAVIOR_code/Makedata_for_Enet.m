%save for Enet to read
for c = [12,19,24,10]
    for pa = 1:12
        cancertype=importdata('../data/Pancancer/data/cancertype.txt');
        pathway=importdata('../data/Pancancer/data/pathway.txt');
        nc = length(cancertype);
        np = length(pathway);
        %c=3;pa=9;seed=1;
        ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
        utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
        xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
        y=[ytmp(:,2),ytmp(:,1)];
        matchsubject=(y(:,1)>30&all(xtmp>0,2));
        y=y(matchsubject,:);
        %y(:,1)=y(:,1)+.1;
        utmp=utmp(matchsubject,:);
        utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
        xtmp=log(xtmp(matchsubject,:));
        family='w';
        [n,p]=size(utmp);
        u=ones(n,1);
        u(:,2)=stdize(utmp(:,1));
        x=cell(1);
        x{1}=double.empty(n,0);
        x{2}=stdize(xtmp(:,1));
        z=cell(1,p);
        z{1}=double.empty(n,0);
        z{2}=double.empty(n,0);
        j=2;
        jj=2;
        while j<=p
            if ~all(utmp(:,j)==utmp(:,j-1))
                u=[u,stdize(utmp(:,j))];
                jj=jj+1;
                x{jj}=stdize(xtmp(:,j));
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
                z{jj}=double.empty(n,0);
            else
                x{jj}=[x{jj},stdize(xtmp(:,j))];
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
            end
            j=j+1;
        end
        u=u(:,2:end);
        csvwrite(sprintf('../data/Pancancer/data/%s_%s_protein_matched.csv',cancertype{c},pathway{pa}),u)
        csvwrite(sprintf('../data/Pancancer/data/%s_%s_surv_matched.csv',cancertype{c},pathway{pa}),y)
        if c==12
            stmp = csvread(sprintf('../data/Pancancer/data/%s_stage.csv',cancertype{c}),1,0);
            stmp=stmp(matchsubject);
            csvwrite(sprintf('../data/Pancancer/data/%s_%s_stage_matched.csv',cancertype{c},pathway{pa}),stmp)
        end
    end
end
