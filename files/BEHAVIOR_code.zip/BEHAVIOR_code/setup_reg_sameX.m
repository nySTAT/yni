function [q,r,p,n,noise,nt,atrue,ptrue,y,yt,link,linkt,lp,lpt,u,ut,x,xt,z,zt,v0_true,v0_test,v_true,v_test,utrue,u_test,t_true,dens,Zind]=setup_reg_sameX(s,seed,family)
%%
if family~='b'
    if s == 1
        q=3;
        r=0;
        p=30;
        n=80;
        cpara=100;%censoring parameter: 0%
    elseif s==2
        q=3;
        r=0;
        p=30;
        n=150;
        cpara=100;%0%
    elseif s==3
        q=3;
        r=0;
        p=30;
        n=150;
        cpara=3;%~20%
    elseif s==4
        q=3;
        r=0;
        p=30;
        n=150;
        cpara=2;%~30%
    elseif s==5
        q=3;
        r=0;
        p=50;
        n=200;
        cpara=3;%~20%
    elseif s==6
        q=3;
        r=0;
        p=100;
        n=200;
        cpara=3;%~20%
    elseif s==7
        q=3;
        r=0;
        p=200;
        n=200;
        cpara=3;%~20%
    elseif s==8
        q=20;
        r=0;
        p=30;
        n=100;
        cpara=100;%0%
    elseif s==9
        q=50;
        r=0;
        p=30;
        n=100;
        cpara=100;%0%
    elseif s==10
        q=50;
        r=0;
        p=50;
        n=100;
        cpara=4.8;%~10%
    elseif s==11
        q=50;
        r=0;
        p=20;
        n=80;
        cpara=4.8;%10%
    elseif s==12
        q=50;
        r=0;
        p=40;
        n=80;
        cpara=5.8;%10%
    elseif s==13
        q=50;
        r=0;
        p=20;
        n=150;
        cpara=4.8;%10%
    elseif s==14
        q=20;
        r=0;
        p=20;
        n=150;
        cpara=5.2;%10%   
    elseif s==15
        q=20;
        r=7;
        p=12;
        n=45;
        cpara=3.6;%10%   
    elseif s==16
        q=0;
        r=5;
        p=7;
        n=45;
        cpara=2.8;%10%  %2.4 for r=3 q=0
    end
    %tmp=zeros(50,1);
    %for seed=1:50
    noise=1;
    nt = n;
    seed_g=1;
    rel = version('-release');
    if (all(rel>='2011a'))
        rng('default');
        rng(seed_g);
    end
    
    x = randn(n,q);%continuous
    xt = randn(nt,q);%testing
    z = randi(2,n,r);%categorical
    zt = randi(2,nt,r);%testing
    
    atrue = zeros(q,p);
    ptrue = zeros(r,p);
    %atrue(1,1)=1;
    %atrue(2,2)=1;
    %atrue(3,3)=1;
    ptrue(1,3)=1;
    ptrue(2,4)=1;
    
    %atrue = binornd(1,.05,q,p);
    %ptrue = binornd(1,.05,r,p);
    %x = x(1:n,:);
    
     v0_true = zeros(n+nt,p);
%     v0_true(:,1)=-3*[x(:,1);xt(:,1)];%v0_true(:,1)=2*[x(:,1);xt(:,1)];
%     v0_true(:,2)=3*[x(:,2);xt(:,2)].^2-4;%v0_true(:,2)=-3*[x(:,2);xt(:,2)];
%     v0_true(:,3)=3*sin(1/2*pi*[x(:,3);xt(:,3)]);%v0_true(:,3)=exp(.5*[x(:,1);xt(:,1)])-2;
    
    
    Z=double.empty(n,0);
    Zt=double.empty(nt,0);
    Zind=[];
    for i =1:r
        Ztmp = dummyvar(z(:,i));
        Z = [Z,Ztmp];
        Zt = [Zt,dummyvar(zt(:,i))];
        Zind = [Zind;i*ones(size(Ztmp,2),1)];
    end
    %v0_true = v0_true + [Z;Zt]*(1.5*ptrue(Zind,:).*randn(length(Zind),p));
    v0_true = v0_true + [z-1;zt-1]*(2*ptrue);
    v0_true(:,5)=3;
    t_true = 0.5;%!
    v_true = threshold(v0_true,t_true);
    v_test = v_true(n+1:n+nt,:);
    v_true = v_true(1:n,:);
    utrue = v_true~=0;
    u_test = v_test~=0;
    v0_test= v0_true(n+1:n+nt,:);
    v0_true = v0_true(1:n,:);
    dens = sum(sum(utrue))/n/p;
    fprintf('density (1-sparsity) is %f\n',dens)
    %boxplot(reshape(v0_true,n*p,1))
    %%
    if (all(rel>='2011a'))
        rng('default');
        rng(seed);
    end
    u = 2*rand(n,p)-1;%regressors
    %u = stdize(u);
    u(:,1)=1;%intercept
    ut = 2*rand(nt,p)-1;%testing regressors
    %ut = stdize(ut);
    ut(:,1)=1;%testing intercept
    
    
    lp = sum(u.*v_true,2); %linear predictor
    lpt = sum(ut.*v_test,2);%linear predictor
    if family=='n'
        y = lp+noise*randn(n,1);%response
        link = lp;
        yt = lpt+noise*randn(nt,1);
        linkt = lpt;
        ym=mean(y);
        y = y-ym;
        yt = yt-ym;
    elseif family=='b'
        link=1./(1+exp(-lp));
        y = binornd(1,link);
        linkt=1./(1+exp(-lpt));
        yt = binornd(1,linkt);
    elseif family=='p'
        link = exp(lp);
        y = poissrnd(link);
        linkt = exp(lpt);
        yt = poissrnd(linkt);
    elseif family=='w'
        link = exp(lp);
        y = zeros(n,2);
        ytmp=wblrnd(1./link,1/noise);%true survival times
        c=exp(randn(n,1)+cpara);%censoring times
        y(:,2) = (ytmp<c);%censoring indicator
        fprintf('percentage of censoring is %f\n',mean(1-y(:,2)))
        y(:,1)=min(ytmp,c);%censored survival times
        %testing
        linkt = exp(lpt);
        yt=wblrnd(1./linkt,1/noise);%true survival times
        c=exp(randn(nt,1)+cpara);%censoring times
        fprintf('percentage of testing censoring is %f\n',mean(yt>c))
        %tmp(seed)=mean(1-y(:,2));
        %tmp(seed)=mean(yt>c);
        yt=min(yt,c);%censored survival times
    end
    
    %end
else
    if s == 1
        q=2;
        r=2;
        p=30;
        n=300;
        if family=='w'
            noise=1;
        else
            noise=1;
        end
        nt = n;
    end
    seed_g=1;
    rel = version('-release');
    if (all(rel>='2011a'))
        rng('default');
        rng(seed_g);
    end
    
    x = randn(n,q);%continuous
    xt = randn(nt,q);%testing
    z = randi(3,n,r);%categorical
    zt = randi(3,nt,r);%testing
    
    atrue = zeros(q,p);
    ptrue = zeros(r,p);
    atrue(1,1)=1;
    atrue(2,2)=1;
    atrue(1,3)=1;
    %ptrue(1,3)=1;
    ptrue(2,4)=1;
    
    %atrue = binornd(1,.05,q,p);
    %ptrue = binornd(1,.05,r,p);
    %x = x(1:n,:);
    v0_true = zeros(n+nt,p);
    v0_true(:,1)=-[x(:,1);xt(:,1)];
    v0_true(:,2)=[x(:,2);xt(:,2)].^2-1;
    %v0_true(:,3)=exp(.5*[x(:,1);xt(:,1)])-2;
    v0_true(:,3)=1.5*sin(1/2*pi*[x(:,1);xt(:,1)]);
    %v0_true(:,1)=2*[x(:,1);xt(:,1)];
    %v0_true(:,2)=-3*[x(:,2);xt(:,2)];
    Z=double.empty(n,0);
    Zt=double.empty(nt,0);
    Zind=[];
    for i =1:r
        Ztmp = dummyvar(z(:,i));
        Z = [Z,Ztmp];
        Zt = [Zt,dummyvar(zt(:,i))];
        Zind = [Zind;i*ones(size(Ztmp,2),1)];
    end
    v0_true = v0_true + [Z;Zt]*(ptrue(Zind,:).*repmat([0,1.5,1,1,1.5,0]',[1,p]));
    v0_true(:,5)=-1;
    t_true = 0.5;%!
    v_true = threshold(v0_true,t_true);
    v_test = v_true(n+1:n+nt,:);
    v_true = v_true(1:n,:);
    utrue = v_true~=0;
    u_test = v_test~=0;
    v0_test= v0_true(n+1:n+nt,:);
    v0_true = v0_true(1:n,:);
    dens = sum(sum(utrue))/n/p;
    fprintf('density (1-sparsity) is %f\n',dens)
    %boxplot(reshape(v0_true,n*p,1))
    %%
    if (all(rel>='2011a'))
        rng('default');
        rng(seed);
    end
    u = 3*rand(n,p)-1.6;%regressors
    %u = stdize(u);
    u(:,1)=1;%intercept
    ut = 3*rand(nt,p)-1.6;%testing regressors
    %ut = stdize(ut);
    ut(:,1)=1;%testing intercept
    
    
    lp = sum(u.*v_true,2); %linear predictor
    lpt = sum(ut.*v_test,2);%linear predictor
    if family=='n'
        y = lp+noise*randn(n,1);%response
        link = lp;
        yt = lpt+noise*randn(nt,1);
        linkt = lpt;
        ym=mean(y);
        y = y-ym;
        yt = yt-ym;
    elseif family=='b'
        link=1./(1+exp(-lp));
        y = binornd(1,link);
        linkt=1./(1+exp(-lpt));
        yt = binornd(1,linkt);
    elseif family=='p'
        link = exp(lp);
        y = poissrnd(link);
        linkt = exp(lpt);
        yt = poissrnd(linkt);
    elseif family=='w'
        link = exp(lp);
        y = zeros(n,2);
        ytmp=wblrnd(1./link,1/noise);%true survival times
        c=exp(randn(n,1)+2.2);%censoring times
        y(:,2) = (ytmp<c);%censoring indicator
        fprintf('percentage of censoring is %f\n',mean(1-y(:,2)))
        y(:,1)=min(ytmp,c);%censored survival times
        %testing
        linkt = exp(lpt);
        yt=wblrnd(1./linkt,1/noise);%true survival times
        c=exp(randn(nt,1)+2.6);%censoring times
        fprintf('percentage of testing censoring is %f\n',mean(yt>c))
        yt=min(yt,c);%censored survival times
    end
end
hist(link)
hist(lp)



