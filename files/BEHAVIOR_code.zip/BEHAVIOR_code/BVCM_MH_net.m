%%
function BVCM_MH_net(q,r,p,n,seed)
%%
%%%%%%%%%%%%%%%undirected version, marginal likelihood%%%%%%%%%%%%%%%%%%%%
%parameters
%clear
if isdeployed
     seed=str2num(seed);
     q = str2num(q);
     r = str2num(r);
     p = str2num(p);
     n = str2num(n);
end
%varying coefficients regression with thresholding and reduced rank
%orthogonal basis matrix
%clear

%data generation
seed_g=1;
per=1;
% n=200;
% p=50;
%q=2;%continuous
%r=2;%categorical
N = 100000; %number of iterations
Np = 2; %pilot Gibbs run without thresholding
Npo = 10000;
thin = 5;
burnin = floor(N/2);
nt = n;

rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed_g);
end
atrue = zeros(q,p,p);
for i =1:p-1
    flag=0;
    while flag==0
        tmp=binornd(1,.05,q,p);
        atrue(:,i,i+1:end) = tmp(:,i+1:end);
        if 1% sum(sum(atrue(:,i,i+1:end)))<6
            flag=1;
        end
    end
end
ptrue = zeros(r,p,p);
for i =1:p-1
    flag=0;
    while flag==0
        tmp=binornd(1,.05,r,p);
        ptrue(:,i,i+1:end) = tmp(:,i+1:end);
        if 1%sum(sum(ptrue(:,i,i+1:end)))<6
            flag=1;
        end
    end
end
%seed=1;
x = randn(n,q);%continuous
xt = randn(nt,q);%testing

v0_true = zeros(n+nt,p,p);
GF = zeros(q,p,p);
for i = 1:p-1
    mu_true = 0.2*randn(p,1);
    [v0_tmp, GF_tmp] = genBeta([x;xt],per,p,mu_true,0,atrue(:,i,:));
    v0_true(:,i,i+1:end)=v0_tmp(:,i+1:end);
    GF(:,i,:)=GF_tmp;
end


if r==1&&q==0
    z = ones(n,1);
    z(floor(n/3)+1:2*floor(n/3)) = 2;
    z(2*floor(n/3)+1:n) = 3;
    zt = ones(nt,1);
    zt(floor(nt/3)+1:2*floor(nt/3)) = 2;
    zt(2*floor(nt/3)+1:nt) = 3;
else
    z = randi(3,n,r);%categorical
    zt = randi(3,nt,r);%testing
end


Z=double.empty(n,0);
Zt=double.empty(n,0);
Zind=[];
for i =1:r
    Ztmp = dummyvar(z(:,i));
    Z = [Z,Ztmp];
    Zt = [Zt,dummyvar(zt(:,i))];
    Zind = [Zind;i*ones(size(Ztmp,2),1)];
end

for i = 1:p-1
    v0_true(:,i,:) = squeeze(v0_true(:,i,:)) + [Z;Zt]*(squeeze(ptrue(Zind,i,:)).*randn(length(Zind),p));
end

t_true = 0.5;%!
tm = 'hard';
cutoff=0.5;%probability cutoff for variable selection
v_true = threshold(v0_true,t_true,tm);
v_test = v_true(n+1:n+nt,:,:);
v_true = v_true(1:n,:,:);
utrue = v_true~=0;
u_test = v_test~=0;
dens = sum(sum(sum(utrue)))/n/p/(p-1)*2;
dens
%  for i=1:p
%      sum(sum(ptrue(:,i,:)~=0))
%  end
%boxplot(reshape(v0_true,n*p,1))
%%
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end
noise = 1;%!
y = randn(n,p);
y = stdize(y);
ystd=ones(p,1);
yt = randn(nt,p);
yt = stdize(yt);

for i = p-1:-1:1
    [ytmp,ym,ysd] = stdize(sum(y(:,i+1:end).*squeeze(v_true(:,i,i+1:end)),2)+noise*randn(n,1));
    y(:,i) = ytmp;
    ystd(i) = ysd;
    %y(:,i) = (sum(y(:,i+1:end).*squeeze(v_true(:,i,i+1:end)),2)+noise*randn(n,1));
    %y(:,i) = y(:,i)-mean(y(:,i));
    yt(:,i) = ((sum(yt(:,i+1:end).*squeeze(v_test(:,i,i+1:end)),2)+noise*randn(nt,1))-ym)/ysd;   
    %yt(:,i) = yt(:,i)-mean(yt(:,i));
    %yt(:,i) = yt(:,i)-ym;
end
tic;
v_est = zeros(n,p,p);
u_est = zeros(n,p,p);
betax_est = zeros(q,p,p);
betaX_est = cell(p);
betaZ_est = cell(p);
betamu_est = cell(p);
lin_est = zeros(q,p,p);
nlin_est = zeros(q,p,p);
ln_est = zeros(q,p,p);
categ_est = zeros(r,p,p);
const_est = zeros(p,p);
ypred = zeros(nt,p);
urate = u_est;
linrate = lin_est;
nlinrate = nlin_est;
lnrate = ln_est;
categrate = categ_est;
constrate = const_est;
sigma_est = zeros(p,1);
countv = zeros(n,p);
countx = zeros(p,1);
countX = zeros(p,1);
countZ = zeros(p,1);
countmu = zeros(p,1);
ac_eta = zeros(p,1);
ac_eta2 = zeros(p,1);
ac_xi = zeros(p,1);

for i =1:p-1
    fprintf('==================================\n')
    fprintf('computing on %d th regression\n',i)
    fprintf('==================================\n')
    [v_est0,u_est0,betax_est0,betaX_est0,betaZ_est0,betamu_est0,lin_est0,nlin_est0,ln_est0,categ_est0,const_est0,ypred0,urate0,linrate0,nlinrate0,lnrate0,categrate0,constrate0,sigma_est0,countv0,countx0,countX0,countZ0,countmu0,ac_eta0,ac_eta20,ac_xi0]=BVCM_MH_pilot(y(:,i)*ystd(i),y(:,i+1:end),x,z,cutoff,yt(:,i+1:end),xt,zt,N,thin,burnin,Np,seed);
    v_est(:,i,i+1:end) = v_est0;
    u_est(:,i,i+1:end) = u_est0;    
    betax_est(:,i,i+1:end) = betax_est0;
    betaX_est{i} = betaX_est0;
    betaZ_est{i} = betaZ_est0;
    betamu_est{i} = betamu_est0;
    lin_est(:,i,i+1:end) = lin_est0;
    nlin_est(:,i,i+1:end) = nlin_est0;
    ln_est(:,i,i+1:end) = ln_est0;
    categ_est(:,i,i+1:end) = categ_est0;
    const_est(i,i+1:end) = const_est0;
    ypred(:,i) = ypred0;
    urate(:,i,i+1:end) = urate0;
    linrate(:,i,i+1:end) = linrate0;
    nlinrate(:,i,i+1:end) = nlinrate0;
    lnrate(:,i,i+1:end) = lnrate0;
    categrate(:,i,i+1:end) = categrate0;
    constrate(i,i+1:end) = constrate0;
    sigma_est(i) = sigma_est0;
    countv(:,i) = countv0;
    countx(i) = countx0;
    countX(i) = countX0;
    countZ(i) = countZ0;
    countmu(i) = countmu0;
    ac_eta(i) = ac_eta0;
    ac_eta2(i) = ac_eta20;
    ac_xi(i) = ac_xi0;
end
time=toc;

aTPR = sum(sum(sum(ln_est.*atrue)))/sum(sum(sum(atrue)));
aFDR = sum(sum(sum(ln_est.*(1-atrue))))/sum(sum(sum(ln_est)));
pTPR = sum(sum(sum(categ_est.*ptrue)))/sum(sum(sum(ptrue)));
pFDR = sum(sum(sum(categ_est.*(1-ptrue))))/sum(sum(sum(categ_est)));
uTPR = sum(sum(sum(u_est.*utrue)))/sum(sum(sum(utrue)));
uFDR = sum(sum(sum(u_est.*(1-utrue))))/sum(sum(sum(u_est)));
%aAUC = ROC(atrue,lnrate,1000,0,1);
%aAUC5 = ROC(atrue,lnrate,1000,0,0.2);
%pAUC = ROC(ptrue,categrate,1000,0,1);
%pAUC5 = ROC(ptrue,categrate,1000,0,0.2);
%uAUC = ROC(utrue,urate,1000,0,1);
%uAUC5 = ROC(utrue,urate,1000,0,0.2);
%[aTPR,aFDR,pTPR,pFDR,uTPR,uFDR]

% 
% for i = 1:p-1
% aTPR = sum(sum(sum(ln_est(:,i,i+1:end).*atrue(:,i,i+1:end))))/sum(sum(sum(atrue(:,i,i+1:end))));
% aFDR = sum(sum(sum(ln_est(:,i,i+1:end).*(1-atrue(:,i,i+1:end)))))/sum(sum(sum(ln_est(:,i,i+1:end))));
% pTPR = sum(sum(sum(categ_est(:,i,i+1:end).*ptrue(:,i,i+1:end))))/sum(sum(sum(ptrue(:,i,i+1:end))));
% pFDR = sum(sum(sum(categ_est(:,i,i+1:end).*(1-ptrue(:,i,i+1:end)))))/sum(sum(sum(categ_est(:,i,i+1:end))));
% uTPR = sum(sum(sum(u_est(:,i,i+1:end).*utrue(:,i,i+1:end))))/sum(sum(sum(utrue(:,i,i+1:end))));
% uFDR = sum(sum(sum(u_est(:,i,i+1:end).*(1-utrue(:,i,i+1:end)))))/sum(sum(sum(u_est(:,i,i+1:end))));
% sum(sum(v_true(:,i,:)~=0))
% %t_est(i)
% %plot(t_est(i),uFDR,'o')
% %hold on
% [aTPR,aFDR,pTPR,pFDR,uTPR,uFDR]
% end
% plot(reshape(yt,nt*p,1),reshape(ypred,nt*p,1),'o')
% hold on
% plot([min([yt;ypred]),max([yt;ypred])],[min([yt;ypred]),max([yt;ypred])],'-')
% hold off
 MSE = mean(mean((ypred(:,1:p-1)-yt(:,1:p-1).*repmat(ystd(1:p-1)',nt,1)).^2));
 MSE_ls=0;
 for j=1:p-1
    MSE_ls= MSE_ls + mean((yt(:,j)*ystd(j)-[ones(nt,1),yt(:,j+1:p).*repmat(ystd(j+1:p)',nt,1)]*([ones(n,1),y(:,j+1:p).*repmat(ystd(j+1:p)',n,1)]\(y(:,j)*ystd(j)))).^2);%ls mse
 end
 MSE_ls=MSE_ls/(p-1);
fname = sprintf('BVCM_MH_Net_pilot_q%d_r%d_p%d_n%d_mc%d_seed%d.mat',q,r,p,n,N,seed);
save(fname)
