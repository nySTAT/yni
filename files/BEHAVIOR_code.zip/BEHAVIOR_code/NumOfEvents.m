cancertype=importdata('../data/Pancancer/data/cancertype.txt');
nc = length(cancertype);
events=zeros(nc,1);
samplesize = zeros(nc,1);
for c = 1:nc
    ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
    y=[ytmp(:,2),ytmp(:,1)];
    matchsubject=(y(:,1)>30);
    y=y(matchsubject,:);
    events(c)=sum(y(:,2));
    samplesize(c)=size(y,1);
end

censor = 1-events./samplesize;
[a,I]=sort(events,1,'descend');
[cancertype';cancertype(I)']
a'




