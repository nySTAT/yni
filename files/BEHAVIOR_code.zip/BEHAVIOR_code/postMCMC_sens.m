function [betax_est,betaX_est,betaZ_est,betamu_est,betax,betaX,betaZ,betamu,v0_est,v0_upper,v0_lower,v_est,v_upper,v_lower,urate,u_est,ypred,linkpred,lppred,v0_pred,v0_pred_upper,v0_pred_lower,v_pred,v_pred_upper,v_pred_lower,u_pred,u_pred_rate,t_est,sigma_est]=postMCMC_sens(y,u,x,z,cutoff,ut,xt,zt,lin_est,nlin_est,categ_est,const_est,Npo,burninpo,seed,family,eta_sd,xi_sd,t_sd,sigma_var,sens)

 

%t_sd = .25;%0.075
%eta_sd = .25;
%xi_sd = 0.5;
%sigma_var=1/5;
ifpredy=1;%predict or not
if isempty(ut)
    ifpredy=0;
end
ifpredu=1;%predict or not
if isempty(xt)&&isempty(zt)
    ifpredu=0;
end
rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end

[n,p]=size(u);

ximu_old = .1*randn(p,1);
etamu_old = .1*randn(p,1);
betamu = zeros(p,(Npo-burninpo));
betamu_old = etamu_old.*ximu_old;
%design matrix
inte = ones(n,1)/sqrt(n);%intercept
%categorical
Z = cell(p,1);
Zind = cell(p,1);
zmean = cell(p,1);
zscale = cell(p,1);
dZ = cell(p,1);
xiZ_old = cell(p,1);
betaZ = cell(p,1);
betaZ_old = cell(p,1);
etaZ_old = cell(p,1);
nr=zeros(p,1);
tauZ_old = cell(p,1);
for j =1:p
    Z{j}=double.empty(n,0);
    Zind{j}=double.empty(0,1);
    zmean{j}=[];
    zscale{j}=[];
    nr(j) = size(z{j},2);
    for i =1:nr(j)
        try
            Ztmp = dummyvar(z{j}(:,i));
            Ztmp = Ztmp(:,2:end);
        catch
            Ztmp=z{j}(:,i);
        end
        zmean{j} = [zmean{j},mean(Ztmp)];
        Ztmp = Ztmp-repmat(mean(Ztmp),n,1);
        zscale{j} = [zscale{j},norm(Ztmp,'fro')*ones(1,size(Ztmp,2))];
        Ztmp = Ztmp/norm(Ztmp,'fro');
        Z{j} = [Z{j},Ztmp];
        Zind{j} = [Zind{j};i*ones(size(Ztmp,2),1)];
    end
    dZ{j}=size(Z{j},2);
    xiZ_old{j} = .1*randn(dZ{j},1);
    betaZ{j} = zeros(dZ{j},Npo-burninpo);
    etaZ_old{j}=.1*randn(nr(j),1);
    tauZ_old{j}=ones(nr(j),1);
    betaZ_old{j}=etaZ_old{j}(Zind{j}).*xiZ_old{j};
end

%continuous
order = 4; %order of splines
nknots = 16; %number of interior knots
M = order + nknots;
K = makeK(M);
Kinv = pinv(K);
dX = cell(p,1);
X=cell(p,1);
Xind=cell(p,1);
xix_old = cell(p,1);
xiX_old=cell(p,1);
betaX = cell(p,1);
betaX_old=cell(p,1);
etax_old = cell(p,1);
etaX_old = cell(p,1);
xx= cell(p,1);
xxt=cell(p,1);
betax = cell(p,1);
betax_old = cell(p,1);
nq = zeros(p,1);
taux_old = cell(p,1);
tauX_old = cell(p,1);
for j = 1:p
    xx{j}=bspline_quantileknots(order,nknots,x{j},x{j});
    if ifpredu==1
        xxt{j}=bspline_quantileknots(order,nknots,x{j},xt{j});
    end
    X{j} = double.empty(n,0);
    Xind{j} =double.empty(0,1);
    nq(j) = size(x{j},2);
    for i = 1:nq(j)
        Xtmp = xx{j}(:,(i-1)*M+1:i*M);
        [U,S,~]=svd(Xtmp*Kinv*Xtmp','econ');
        S = diag(S);
        nullvals = S < 10^-10;
        d = max(3, find( cumsum(S(~nullvals))/sum(S(~nullvals)) > .995 ,1));
        d = min(d, sum(~nullvals));
        Xtmp = U(:,1:d)*diag(sqrt(S(1:d)));
        Xtmp2 = [ones(n,1),x{j}(:,i)];
        Xtmp = Xtmp- Xtmp2*(Xtmp2\Xtmp);
        Xtmp = Xtmp/norm(Xtmp,'fro');
        x{j}(:,i) = x{j}(:,i)-mean(x{j}(:,i));
        x{j}(:,i) = x{j}(:,i)/norm(x{j}(:,i),'fro');
        X{j} = [X{j},Xtmp];
        Xind{j} = [Xind{j};i*ones(size(Xtmp,2),1)];
    end
    dX{j}=size(X{j},2);
    xix_old{j} = .1*randn(nq(j),1);
    xiX_old{j} = .1*randn(dX{j},1);
    betaX{j} = zeros(dX{j},Npo-burninpo);
    etax_old{j} = .1*randn(nq(j),1);
    etaX_old{j} = .1*randn(nq(j),1);
    betax{j}=zeros(nq(j),(Npo-burninpo));
    betax_old{j} = etax_old{j}.*xix_old{j};
    taux_old{j}=ones(nq(j),1);
    tauX_old{j}=ones(nq(j),1);
    betaX_old{j} = etaX_old{j}(Xind{j}).*xiX_old{j};
end

%parameter
if sens==11
    b_t=2;
elseif sens==12
    b_t=5;
elseif sens==13
    b_t=10;
else
    b_t = 1;%uniform prior for t
end
a_t = 0;%uniform prior for t
a = 10^-4; b = 10^-4;%IG prior for sigma
a_tau = 5; b_tau = 100;
s0 = 2.5*10^-4;


for j = 1:p
    for i = 1:nq(j)
        xibar=mean(abs(xix_old{j}(i)),1);
        etax_old{j}(i) = etax_old{j}(i).*xibar;
        xix_old{j}(i) = xix_old{j}(i)./xibar;
        xibar=mean(abs(xiX_old{j}(Xind{j}==i)),1);
        etaX_old{j}(i) = etaX_old{j}(i).*xibar;
        xiX_old{j}(Xind{j}==i) = xiX_old{j}(Xind{j}==i)./repmat(xibar,[sum(Xind{j}==i),1]);
    end
    for i = 1:nr(j)
        xibar=mean(abs(xiZ_old{j}(Zind{j}==i)),1);
        etaZ_old{j}(i) = etaZ_old{j}(i).*xibar;
        xiZ_old{j}(Zind{j}==i) = xiZ_old{j}(Zind{j}==i)./repmat(xibar,[sum(Zind{j}==i),1]);
        
    end
end
etamu_old = etamu_old.*abs(ximu_old);
ximu_old = ximu_old./abs(ximu_old);
sigma = ones((Npo-burninpo),1);%sigma^2
t = zeros((Npo-burninpo),1);
t_old=t(1);
gammax_old=cell(p,1);
gammaX_old=cell(p,1);
gammaZ_old=cell(p,1);
gammamu_old = const_est+0;
gammamu_old(gammamu_old==0)=s0;
for j =1:p
    gammax_old{j} = lin_est{j}+0;
    gammaX_old{j} = nlin_est{j}+0;
    gammaZ_old{j} = categ_est{j}+0;
    gammax_old{j}(gammax_old{j}==0)=s0;
    gammaX_old{j}(gammaX_old{j}==0)=s0;
    gammaZ_old{j}(gammaZ_old{j}==0)=s0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%need modification
v = zeros(n,p,(Npo-burninpo));
v0 = zeros(n,p,(Npo-burninpo));
ac_eta=0;
ac_xi =0;
ac_t=0;
ac_sigma=0;

sigma_old = sigma(1);
taumu_old = ones(p,1);
regressor_old=zeros(n,p);
for j = 1:p
    regressor_old(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x{j}*betax_old{j}+X{j}*betaX_old{j}+Z{j}*betaZ_old{j},t_old);
end
%algorithm begins
%tic;
ll_old = loglike(y,regressor_old,sigma_old,family);
iter=0;
for mc = 2:Npo
    %update eta

    for j = 1:p
        for i = 1:nq(j)
            regressor_new = regressor_old;
            etax_new = etax_old{j};
            etax_new(i) = etax_old{j}(i) + eta_sd*randn(1);
            betax_new = etax_new.*xix_old{j};
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x{j}*betax_new+X{j}*betaX_old{j}+Z{j}*betaZ_old{j},t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*(etax_new(i).^2./gammax_old{j}(i)./taux_old{j}(i))...
                +.5*(etax_old{j}(i).^2./gammax_old{j}(i)./taux_old{j}(i));
            if lr > log(rand(1))
                ac_eta = ac_eta+1;
                ll_old=ll_new;
                etax_old{j}(i) = etax_new(i);
                betax_old{j} = betax_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    for j = 1:p
        for i = 1:nq(j)
            regressor_new = regressor_old;
            etaX_new = etaX_old{j};
            etaX_new(i) = etaX_old{j}(i) + eta_sd*randn(1);
            betaX_new = etaX_new(Xind{j}).*xiX_old{j};
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x{j}*betax_old{j}+X{j}*betaX_new+Z{j}*betaZ_old{j},t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*(etaX_new(i).^2./gammaX_old{j}(i)./tauX_old{j}(i))...
                +.5*(etaX_old{j}(i).^2./gammaX_old{j}(i)./tauX_old{j}(i));
            if lr > log(rand(1))
                ac_eta = ac_eta+1;
                ll_old=ll_new;
                etaX_old{j}(i) = etaX_new(i);
                betaX_old{j} = betaX_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    for j = 1:p
        for i = 1:nr(j)
            regressor_new = regressor_old;
            etaZ_new = etaZ_old{j};
            etaZ_new(i) = etaZ_old{j}(i) + eta_sd*randn(1);
            betaZ_new = etaZ_new(Zind{j}).*xiZ_old{j};
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x{j}*betax_old{j}+X{j}*betaX_old{j}+Z{j}*betaZ_new,t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*(etaZ_new(i).^2./gammaZ_old{j}(i)./tauZ_old{j}(i))...
                +.5*(etaZ_old{j}(i).^2./gammaZ_old{j}(i)./tauZ_old{j}(i));
            if lr > log(rand(1))
                ac_eta = ac_eta+1;
                ll_old=ll_new;
                etaZ_old{j}(i) = etaZ_new(i);
                betaZ_old{j} = betaZ_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    for j = 1:p
        regressor_new = regressor_old;
        etamu_new = etamu_old(j) + eta_sd*randn(1);
        betamu_new = etamu_new.*ximu_old(j);
        regressor_new(:,j) = u(:,j).*threshold(betamu_new*inte+x{j}*betax_old{j}+X{j}*betaX_old{j}+Z{j}*betaZ_old{j},t_old);
        ll_new = loglike(y,regressor_new,sigma_old,family);
        lr = ll_new-ll_old-.5*(etamu_new.^2./gammamu_old(j)./taumu_old(j))...
            +.5*(etamu_old(j).^2./gammamu_old(j)./taumu_old(j));
        if lr > log(rand(1))
            ac_eta = ac_eta+1;
            ll_old=ll_new;
            etamu_old(j) = etamu_new;
            betamu_old(j) = betamu_new;
            regressor_old(:,j) = regressor_new(:,j);
        end
    end
    
    %update
    
    mmu_old=2*binornd(1,1./(1+exp(-2*ximu_old)))-1;
    mx_old = cell(p,1);
    mX_old = cell(p,1);
    mZ_old = cell(p,1);

    %update xi
    for j = 1:p
        mx_old{j}=2*binornd(1,1./(1+exp(-2*xix_old{j})))-1;
        mX_old{j}=2*binornd(1,1./(1+exp(-2*xiX_old{j})))-1;
        mZ_old{j}=2*binornd(1,1./(1+exp(-2*xiZ_old{j})))-1;
        regressor_new = regressor_old;
        xix_new = xix_old{j} + xi_sd*randn(nq(j),1);
        betax_new = etax_old{j}.*xix_new;
        xiX_new = xiX_old{j} + xi_sd*randn(dX{j},1);
        betaX_new = etaX_old{j}(Xind{j}).*xiX_new;
        xiZ_new = xiZ_old{j} + xi_sd*randn(dZ{j},1);
        betaZ_new = etaZ_old{j}(Zind{j}).*xiZ_new;
        ximu_new = ximu_old(j) + xi_sd*randn(1);
        betamu_new = etamu_old(j).*ximu_new;
        regressor_new(:,j) = u(:,j).*threshold(betamu_new*inte+x{j}*betax_new+X{j}*betaX_new+Z{j}*betaZ_new,t_old);
        ll_new = loglike(y,regressor_new,sigma_old,family);
        lr = ll_new-ll_old-.5*(sum(sum((xix_new-mx_old{j}).^2))+sum(sum((xiX_new-mX_old{j}).^2))+sum(sum((xiZ_new-mZ_old{j}).^2))+sum((ximu_new-mmu_old(j)).^2))...
            +.5*(sum(sum((xix_old{j}-mx_old{j}).^2))+sum(sum((xiX_old{j}-mX_old{j}).^2))+sum(sum((xiZ_old{j}-mZ_old{j}).^2))+sum((ximu_old(j)-mmu_old(j)).^2));
        if lr > log(rand(1))
            ac_xi = ac_xi+1;
            ll_old=ll_new;
            xix_old{j} = xix_new;
            betax_old{j} = betax_new;
            xiX_old{j} = xiX_new;
            betaX_old{j} = betaX_new;
            xiZ_old{j} = xiZ_new;
            betaZ_old{j} = betaZ_new;
            ximu_old(j) = ximu_new;
            betamu_old(j) = betamu_new;
            regressor_old(:,j) = regressor_new(:,j);
        end
    end
    
    
    %rescale eta and xi
    for j =1:p
    for i = 1:nq(j)
        xibar=mean(abs(xix_old{j}(i)),1);
        etax_old{j}(i) = etax_old{j}(i).*xibar;
        xix_old{j}(i) = xix_old{j}(i)./xibar;
        xibar=mean(abs(xiX_old{j}(Xind{j}==i)),1);
        etaX_old{j}(i) = etaX_old{j}(i).*xibar;
        xiX_old{j}(Xind{j}==i) = xiX_old{j}(Xind{j}==i)./repmat(xibar,[sum(Xind{j}==i),1]);
    end
    for i = 1:nr(j)
        xibar=mean(abs(xiZ_old{j}(Zind{j}==i)),1);
        etaZ_old{j}(i) = etaZ_old{j}(i).*xibar;
        xiZ_old{j}(Zind{j}==i) = xiZ_old{j}(Zind{j}==i)./repmat(xibar,[sum(Zind{j}==i),1]);
    end
    end
    etamu_old = etamu_old.*abs(ximu_old);
    ximu_old = ximu_old./abs(ximu_old);
    

    %update t
    t_new = rtnorm(t_old,t_sd,a_t,b_t);
    for j = 1:p
        regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x{j}*betax_old{j}+X{j}*betaX_old{j}+Z{j}*betaZ_old{j},t_new);
    end
    ll_new = loglike(y,regressor_new,sigma_old,family);
    lr = ll_new-ll_old + log(dtnorm(t_old,t_new,t_sd,a_t,b_t)) - log(dtnorm(t_new,t_old,t_sd,a_t,b_t));
    if lr>log(rand(1))
        ac_t = ac_t + 1;
        t_old = t_new;
        regressor_old = regressor_new;
        ll_old=ll_new;
    end
    
    %update tau
    for j =1:p
        taux_old{j}=1./gamrnd(a_tau+.5,1./(b_tau+etax_old{j}.^2./gammax_old{j}/2));
        tauX_old{j}=1./gamrnd(a_tau+.5,1./(b_tau+etaX_old{j}.^2./gammaX_old{j}/2));
        tauZ_old{j}=1./gamrnd(a_tau+.5,1./(b_tau+etaZ_old{j}.^2./gammaZ_old{j}/2));
    end
    taumu_old=1./gamrnd(a_tau+.5,1./(b_tau+etamu_old.^2./gammamu_old/2));
    
    
    %update sigma
    if family=='n'
        sse = -(ll_old+.5*log(sigma_old))*2*sigma_old;
        sigma_old = 1/gamrnd(a+n/2,1/(b+sse/2));
        ll_old = -sse/2/sigma_old-.5*log(sigma_old);
    elseif family=='w'
        mm = log(sigma_old^2/sqrt(sigma_var+sigma_old^2));
        vv = sqrt(log(sigma_var/sigma_old^2+1));
        sigma_new = lognrnd(mm,vv);
        mm2 = log(sigma_new^2/sqrt(sigma_var+sigma_new^2));
        vv2 = sqrt(log(sigma_var/sigma_new^2+1));
        ll_new = loglike(y,regressor_old,sigma_new,family);
        lr = ll_new-ll_old + log(gampdf(sigma_new,a,1/b)) - log(gampdf(sigma_old,a,1/b))-log(lognpdf(sigma_new,mm,vv))+log(lognpdf(sigma_old,mm2,vv2)) ;
        if lr>log(rand(1))
            ac_sigma = ac_sigma + 1;
            sigma_old = sigma_new;
            ll_old=ll_new;
        end
    elseif family=='l'        
        mm = log(sigma_old^2/sqrt(sigma_var+sigma_old^2));
        vv = sqrt(log(sigma_var/sigma_old^2+1));
        sigma_new = lognrnd(mm,vv);
        mm2 = log(sigma_new^2/sqrt(sigma_var+sigma_new^2));
        vv2 = sqrt(log(sigma_var/sigma_new^2+1));
        ll_new = loglike(y,regressor_old,sigma_new,family);
        lr = ll_new-ll_old + log(gampdf(1/sigma_new,a,1/b)) - log(gampdf(1/sigma_old,a,1/b))-log(lognpdf(sigma_new,mm,vv))+log(lognpdf(sigma_old,mm2,vv2)) ;
        if lr>log(rand(1))
            ac_sigma = ac_sigma + 1;
            sigma_old = sigma_new;
            ll_old=ll_new;
        end
    end
    
    
    if mod(mc,200)==0
        fprintf('%d steps finished\n',mc)
        fprintf('%d steps to go\n',Npo-mc)
    end
    %save samples every "thin" iterations
    if mc>burninpo
        iter = iter + 1;
        for j =1:p
            betax{j}(:,iter)=betax_old{j};
            betaX{j}(:,iter)=betaX_old{j};
            betaZ{j}(:,iter)=betaZ_old{j};
            v0(:,j,iter) = betamu_old(j)*(gammamu_old(j)==1)*inte+x{j}*(betax_old{j}.*(gammax_old{j}==1))+X{j}*(betaX_old{j}.*(gammaX_old{j}(Xind{j})==1))+Z{j}*(betaZ_old{j}.*(gammaZ_old{j}(Zind{j})==1));
        end
        betamu(:,iter)=betamu_old;
        t(iter) = t_old;
        sigma(iter) = sigma_old;
        v(:,:,iter) = threshold(v0(:,:,iter),t_old);
    end
end

ac_eta = ac_eta/(Npo-1)/(2*sum(nq)+sum(nr)+p);
ac_xi = ac_xi/(Npo-1)/p;
ac_t = ac_t/(Npo-1);
ac_sigma = ac_sigma/(Npo-1);

%seed+1
betax_est=cell(p,1);
betaX_est=cell(p,1);
betaZ_est=cell(p,1);
for j =1:p
betax_est{j} = mean(betax{j},2);
betaX_est{j} = mean(betaX{j},2);
betaZ_est{j} = mean(betaZ{j},2);
end
betamu_est = mean(betamu,2);

% betax_sd = std(betax_est,0,3);
% betaX_sd = std(betaX_est,0,3);
% betaZ_sd = std(betaZ_est,0,3);
% betamu_sd = std(betamu_est,0,2);


% v0_est = mean(v0,3);
% v0_upper = v0_est + 1.96*std(v0,0,3);
% v0_lower = v0_est - 1.96*std(v0,0,3);

t_est = mean(t);
sigma_est = mean(sigma);
urate = 0;%regression strucutre
for mc = 1:(Npo-burninpo)
    urate = urate+(v(:,:,mc)~=0);
end
urate = urate/(Npo-burninpo);
u_est=urate>cutoff;




v_est = mean(v,3);
vsd = std(v,0,3);
v_upper = v_est+1.96*vsd;
v_lower = v_est-1.96*vsd;
v0_est=mean(v0,3);
vsd = std(v0,0,3);
v0_upper = v0_est+1.96*vsd;
v0_lower = v0_est-1.96*vsd;

% v_est=zeros(n,p);
% v0_est = v_est;
% v0_upper=v_est;
% v0_lower=v_est;
% v_upper=v_est;
% v_lower=v_est;
% v0_tmp = zeros(n,p,Npo-burninpo);
% v_tmp = v0_tmp;
%
%
%
%
%
% %v_est=zeros(n,p);
% countv=zeros(n,p);
% for mc = 1:(Npo-burninpo)
%     for i =1 :n
%         for j = 1:p
%         if 1%all(all(u_est(i,j)==(v(i,j,mc)~=0)))
%             countv(i,j)=countv(i,j)+1;
%             v_est(i,j) = v_est(i,j)+v(i,j,mc);
%             v0_est(i,j) = v0_est(i,j)+v0(i,j,mc);
%             v0_tmp(i,j,countv(i,j)) = v0(i,j,mc);
%             v_tmp(i,j,countv(i,j)) = v(i,j,mc);
%         end
%         end
%     end
% end
% v_est = v_est./countv;
% v0_est = v0_est./countv;
%
% for i = 1:n
%     for j = 1:p
%     v0_upper(i,j) = v0_est(i,j)+1.96*std(squeeze(v0_tmp(i,j,1:countv(i,j))));
%     v0_lower(i,j) = v0_est(i,j)-1.96*std(squeeze(v0_tmp(i,j,1:countv(i,j))));
%     v_upper(i,j) = v_est(i,j)+1.96*std(squeeze(v_tmp(i,j,1:countv(i,j))));
%     v_lower(i,j) = v_est(i,j)-1.96*std(squeeze(v_tmp(i,j,1:countv(i,j))));
%     end
% end
% countv=zeros(n,1);
% for mc = 1:(Npo-burninpo)
%     for i = 1:n
%         if all(all(u_est(i,:)==(v(i,:,mc)~=0)))
%             countv(i)=countv(i)+1;
%             v_est(i,:) = v_est(i,:)+v(i,:,mc);
%             v0_est(i,:) = v0_est(i,:)+v0(i,:,mc);
%             v0_tmp(i,:,countv(i)) = v0(i,:,mc);
%             v_tmp(i,:,countv(i)) = v(i,:,mc);
%         end
%     end
% end
% v_est = v_est./repmat(countv,[1,p]);
% v0_est = v0_est./repmat(countv,[1,p]);
%v_est = kron((betamu_est)',inte)+x*(betax_est)+X*(betaX_est)+Z*(betaZ_est);
%prediction
%seed+2
alpha=cell(p,1);
for j =1:p
    alpha{j}=zeros(nq(j)*M,(Npo-burninpo));
    [Q,R] = qr(xx{j},0);
    for mc = 1:(Npo-burninpo)
        alpha{j}(:,mc) = R\(Q'*(betamu(j,mc)*(gammamu_old(j)==1)*inte+X{j}*(betaX{j}(:,mc).*(gammaX_old{j}(Xind{j})==1))+x{j}*(betax{j}(:,mc).*(gammax_old{j}==1))));
    end
end

%seed+3


% alpha=zeros(q,p,M,(N-burninpo)/thin);
% for k = 1:q
%     Xtmp = xx(:,(k-1)*M+1:k*M);
%     Xtmp = (Xtmp'*Xtmp)\Xtmp';
%     Xtmp1 = Xtmp*X(:,Xind==k);
%     Xtmp2 = Xtmp*x(:,k);
%     for j = 1:p
%         alpha(k,j,:,:)=Xtmp1*squeeze(betaX(Xind==k,j,:))+Xtmp2*squeeze(betax(k,j,:))';
%     end
% end
% alpha = reshape(permute(alpha,[3,1,2,4]),q*M,p,(N-burninpo)/thin);
if ifpredu==1
    nt = size(ut,1);
    lppred=zeros(nt,1);
    u_pred_rate=zeros(nt,p);
    vtmp=zeros(nt,p,(Npo-burninpo));
    v0tmp=zeros(nt,p,(Npo-burninpo));
    Zt = cell(p,1);
    for j =1:p
        Zt{j}=double.empty(nt,0);
        %nr(j) = size(zt{j},2); %this should be the same as size(z{j},2),right?
        if nr(j)~=0
            for i =1:nr(j)
                Ztmp = dummyvar(zt{j}(:,i));
                Ztmp = Ztmp(:,2:end);
                Zt{j} = [Zt{j},Ztmp];
            end
            Zt{j} = Zt{j}-repmat(zmean{j},nt,1);
            Zt{j} = Zt{j}./repmat(zscale{j},nt,1);
        end 
    end
    
    inte = ones(nt,1)/sqrt(n);%intercept

    for mc = 1:(Npo-burninpo)
        for j =1:p
            if nq(j)~=0
                v0tmp(:,j,mc) = Zt{j}*(betaZ{j}(:,mc).*(gammaZ_old{j}(Zind{j})==1)) + xxt{j}*alpha{j}(:,mc);
                vtmp(:,j,mc) = threshold(v0tmp(:,j,mc),t(mc));
            else
                v0tmp(:,j,mc) = Zt{j}*(betaZ{j}(:,mc).*(gammaZ_old{j}(Zind{j})==1)) + betamu(j,mc)*(gammamu_old(j)==1)*inte;
                vtmp(:,j,mc) = threshold(v0tmp(:,j,mc),t(mc));
            end
        end
        if ifpredy==1
            lppred = lppred + sum(ut.*vtmp(:,:,mc),2);%response
        end
        u_pred_rate = u_pred_rate+(vtmp(:,:,mc)~=0);
    end
    if ifpredy==1
        lppred = lppred/((Npo-burninpo));
    else
        lppred=nan;
    end
    u_pred_rate = u_pred_rate/((Npo-burninpo));
    u_pred=u_pred_rate>cutoff;
    
    %     v_pred=zeros(nt,p);
    %     v0_pred = v_pred;
    %     v0_pred_upper=v_pred;
    %     v0_pred_lower=v_pred;
    %     v_pred_upper=v_pred;
    %     v_pred_lower=v_pred;
    %     v0_tmp = zeros(nt,p,Npo-burninpo);
    %     v_tmp = v0_tmp;
    %     countv_pred=zeros(nt,p);
    %     for mc = 1:(Npo-burninpo)
    %         for i = 1:nt
    %             for j = 1:p
    %             if u_pred(i,j)==(vtmp(i,j,mc)~=0)
    %                 countv_pred(i,j)=countv_pred(i,j)+1;
    %                 v_pred(i,j) = v_pred(i,j)+vtmp(i,j,mc);
    %                 v0_pred(i,j) = v0_pred(i,j)+v0tmp(i,j,mc);
    %                 v0_tmp(i,j,countv_pred(i,j)) = v0tmp(i,j,mc);
    %                 v_tmp(i,j,countv_pred(i,j)) = vtmp(i,j,mc);
    %             end
    %             end
    %         end
    %     end
    %     v_pred = v_pred./countv_pred;
    %     v0_pred = v0_pred./countv_pred;
    %     for i = 1:nt
    %         for j = 1:p
    %             v0_pred_upper(i,j) = v0_pred(i,j)+1.96*std(squeeze(v0_tmp(i,j,1:countv_pred(i,j))));
    %             v0_pred_lower(i,j) = v0_pred(i,j)-1.96*std(squeeze(v0_tmp(i,j,1:countv_pred(i,j))));
    %             v_pred_upper(i,j) = v_pred(i,j)+1.96*std(squeeze(v_tmp(i,j,1:countv_pred(i,j))));
    %             v_pred_lower(i,j) = v_pred(i,j)-1.96*std(squeeze(v_tmp(i,j,1:countv_pred(i,j))));
    %         end
    %     end
    v_pred = mean(vtmp,3);
    vsd = std(vtmp,0,3);
    v_pred_upper = v_pred+1.96*vsd;
    v_pred_lower = v_pred-1.96*vsd;
    v0_pred = mean(v0tmp,3);
    vsd = std(v0tmp,0,3);
    v0_pred_upper = v0_pred+1.96*vsd;
    v0_pred_lower = v0_pred-1.96*vsd;
    if family=='n'
        ypred = lppred;
        linkpred = lppred;
    elseif family=='b'
        linkpred=1./(1+exp(-lppred));
        ypred = linkpred>.5;%optimal classification rate prediction
    elseif family=='p'
        linkpred = exp(lppred);
        ypred = linkpred;
    elseif family=='w'
        linkpred = exp(lppred);
        ypred = gamma(1+sigma_est)./linkpred;
    elseif family=='l'
        linkpred = exp(lppred);
        ypred = linkpred; %probably this is wrong (just copied from weibull)
    end
else
    ypred=nan;
    linkpred=nan;
    lppred=nan;
    v_pred=nan;
    v0_pred=nan;
    v_pred_upper=nan;
    v_pred_lower=nan;
    v0_pred_upper=nan;
    v0_pred_lower=nan;
    u_pred=nan;
    u_pred_rate=nan;
end




% v0_est=kron((betamu_est.*(gammamu_old==1))',inte)+x*(betax_est.*(gammax_old==1))+X*(betaX_est.*(gammaX_old(Xind,:)==1))+Z*(betaZ_est.*(gammaZ_old(Zind,:)==1));
% v0_upper = kron((betamu_est+1.96*betamu_sd)',inte)+x*(betax_est+1.96*betax_sd)+X*(betaX_est+1.96*betaX_sd)+Z*(betaZ_est+1.96*betaZ_sd);
% v0_lower = kron((betamu_est-1.96*betamu_sd)',inte)+x*(betax_est-1.96*betax_sd)+X*(betaX_est-1.96*betaX_sd)+Z*(betaZ_est-1.96*betaZ_sd);


