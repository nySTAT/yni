%%
%convergence diagnostics
clear
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
np = length(pathway);
cor_u=zeros(4,12);
cor_const=zeros(4,12);
cor_lin=zeros(4,12);
cor_nlin=zeros(4,12);
RF_t=zeros(4,12);
RF_sigma=zeros(4,12);
RF_betax = cell(4,12);
RF_betaX = cell(4,12);
RF_betamu = cell(4,12);
RF_betax_med=zeros(4,12);
RF_betaX_med=zeros(4,12);
RF_betamu_med=zeros(4,12);
nou1 = zeros(4,12);
nou2 = zeros(4,12);
FDR=zeros(4,12);
npro=zeros(4,12);
cc=0;
ccc=0;
for c = [12,19,24,10]
    cc=cc+1;
    for pa = 1:np
        ccc=ccc+1;
        ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
        utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
        xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
        y=[ytmp(:,2),ytmp(:,1)];
        matchsubject=(y(:,1)>30&all(xtmp>0,2));
        y=y(matchsubject,:);
        %y(:,1)=y(:,1)+.1;
        %hist(log(y(:,1)))
        utmp=utmp(matchsubject,:);
        utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
        xtmp=log(xtmp(matchsubject,:));
        family='w';
        [n,p]=size(utmp);
        u=ones(n,1);
        u(:,2)=stdize(utmp(:,1));
        x=cell(1);
        x{1}=double.empty(n,0);
        x{2}=stdize(xtmp(:,1));
        z=cell(1,p);
        z{1}=double.empty(n,0);
        z{2}=double.empty(n,0);
        j=2;
        jj=2;
        while j<=p
            if ~all(utmp(:,j)==utmp(:,j-1))
                u=[u,stdize(utmp(:,j))];
                jj=jj+1;
                x{jj}=stdize(xtmp(:,j));
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
                z{jj}=double.empty(n,0);
            else
                x{jj}=[x{jj},stdize(xtmp(:,j))];
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
            end
            j=j+1;
        end
        p=size(u,2);
        N = 200000*2.5; %number of iterations
        
        %seed=1
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        u_est1 = u_est;
        constrate1=constrate;
        urate1 = urate;
        linrate1 = linrate;
        nlinrate1 = nlinrate;
        lnrate1 = lnrate;
        betax1 = betax;
        betaX1 = betaX;
        betamu1 = betamu;
        t1=t;
        sigma1=sigma;
        ll1=ll;
        %seed=2
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,2))
        u_est2 = u_est;
        constrate2=constrate;
        urate2 = urate;
        linrate2 = linrate;
        nlinrate2 = nlinrate;
        lnrate2 = lnrate;
        betax2 = betax;
        betaX2 = betaX;
        betamu2 = betamu;
        t2=t;
        sigma2=sigma;
        ll2=ll;
        RF_t(cc,pa)=psrf(t1,t2);
        RF_sigma(cc,pa)= psrf(sigma1,sigma2);
        for i = 2:length(betax1)
            [I,~]=size(betax1{i});
            for ii = 1:I
                RF_betax{cc,pa}=[RF_betax{cc,pa},psrf(betax1{i}(ii,:)',betax2{i}(ii,:)')];
            end
        end
        RF_betax_med(cc,pa)=median(RF_betax{cc,pa});
        for i = 2:length(betaX1)
            [I,~]=size(betaX1{i});
            for ii = 1:I
                RF_betaX{cc,pa}=[RF_betaX{cc,pa},psrf(betaX1{i}(ii,:)',betaX2{i}(ii,:)')];
            end
        end
        RF_betaX_med(cc,pa)=median(RF_betaX{cc,pa});
        [I,~]=size(betamu1);
        for ii = 1:I
            RF_betamu{cc,pa}=[RF_betamu{cc,pa},psrf(betamu1(ii,:)',betamu2(ii,:)')];
        end
        RF_betamu_med(cc,pa)=median(RF_betamu{cc,pa});
        
        
        
        %urate = (urate_post1+urate_post2)/2;
        %linrate = (linrate1+linrate2)/2;
        %nlinrate = (nlinrate1+nlinrate2)/2;
        %lnrate = (lnrate1+lnrate2)/2;
        %categrate = (categrate1+categrate2)/2;
        
        cor_u(cc,pa) = corr(urate1(:),urate2(:));
        cor_const(cc,pa) = corr(constrate1(:),constrate2(:));
        
        linrate_1=[];
        linrate_2=[];
        nlinrate_1=[];
        nlinrate_2=[];
        for i =1:length(linrate1)
            linrate_1=[linrate_1;linrate1{i}];
            linrate_2=[linrate_2;linrate2{i}];
            nlinrate_1=[nlinrate_1;nlinrate1{i}];
            nlinrate_2=[nlinrate_2;nlinrate2{i}];
        end
        cor_lin(cc,pa) = corr(linrate_1(:),linrate_2(:));
        cor_nlin(cc,pa) = corr(nlinrate_1(:),nlinrate_2(:));
        %         cor_ln = corr(lnrate1(:),lnrate2(:));
        %         ln_est=lin_est|nlin_est;
        nou1(cc,pa)=sum(sum(u_est1(:,2:end)))/n/(p-1);
        nou2(cc,pa)=sum(sum(u_est2(:,2:end)))/n/(p-1);
        
        %%%%%%only one of the plotting code blocks can be run at a time%%%%%
        
        %         %trace plots of loglikelihood
        %         subplot(4,12,ccc)
        %         plot(ll1)
        %         hold on
        %         s=plot(ll2);
        %         hold off
        %         xlim([0,length(ll1)])
        %         s.Color(4) = 0.2;
        %         if c==12
        %             title(pathway{pa},'FontSize', 15,'FontWeight','bold')
        %         end
        %         if pa==1
        %             ylabel(cancertype{c},'FontSize', 15,'FontWeight','bold')
        %         end
        
        %trace plots of different parameters for one cancer one pathway
        %         if c==12&&pa==5
        %             figure;
        %             subplot(3,4,1)
        %             plot(t1)
        %             hold on
        %             s=plot(t2);
        %             hold off
        %             xlim([0,length(t1)])
        %             s.Color(4) = 0.2;
        %             ylabel('Threshold','FontSize', 15,'FontWeight','bold')
        %             for i = 1:11
        %                 subplot(3,4,i+1)
        %                 plot(betamu1(i,:))
        %                 hold on
        %                 s=plot(betamu2(i,:));
        %                 hold off
        %                 xlim([0,length(betamu1(i,:))])
        %                 s.Color(4) = 0.2;
        %                 ylabel('Constant','FontSize', 15,'FontWeight','bold')
        %             end
        %             figure;
        %             for i = 1:10
        %                 subplot(7,10,i)
        %                 plot(betax1{i+1})
        %                 hold on
        %                 s=plot(betax2{i+1});
        %                 hold off
        %                 xlim([0,length(betax1{i+1})])
        %                 s.Color(4) = 0.2;
        %                 ylabel('Linear','FontSize', 15,'FontWeight','bold')
        %             end
        %             ccc=10;
        %             for i = 1:10
        %                 for j = 1:6
        %                     ccc=ccc+1;
        %                     subplot(7,10,ccc)
        %                     plot(betaX1{i+1}(j,:))
        %                     hold on
        %                     s=plot(betaX2{i+1}(j,:));
        %                     hold off
        %                     xlim([0,length(betaX1{i+1}(j,:))])
        %                     s.Color(4) = 0.2;
        %                     ylabel('Nonlinear','FontSize', 15,'FontWeight','bold')
        %                 end
        %             end
        %         end
        
        
        
        %plots of PPI
%         subplot(4,12,ccc)
%         plot([urate1(:);constrate1(:);linrate_1(:);nlinrate_1(:)],[urate2(:);constrate2(:);linrate_2(:);nlinrate_2(:)],'o');
%         hold on
%         plot([0,1],[0,1],'-r')
%         hold off
%         %xlim([0,length(ll1)])
%         if c==12
%             title(pathway{pa},'FontSize', 15,'FontWeight','bold')
%         end
%         if pa==1
%             ylabel(cancertype{c},'FontSize', 15,'FontWeight','bold')
%         end

        %expected FDR for protein selection
        N = 200000*5; %number of iterations
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        FDR(cc,pa)=sum(sum((1-urate_post(:,2:end)).*u_est(:,2:end)))/sum(sum(u_est(:,2:end)));
        npro(cc,pa)=sum(sum(u_est(:,2:end)));
    end
end
[median(cor_const(:)),median(cor_lin(:)),median(cor_nlin(:))]
[median(median(RF_t)),median(median(RF_sigma)),median(median(RF_betamu_med)),median(median(RF_betax_med)),median(median(RF_betaX_med))]
FDR(isnan(FDR))=0;
sum(npro,2)./[428,232,262,200]'/12%number of selected proteins per pathway per patient across 4 cancers
mean(FDR(:))
std(FDR(:))

c=12;pa=5;
ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
y=[ytmp(:,2),ytmp(:,1)];
matchsubject=(y(:,1)>30&all(xtmp>0,2));
y=y(matchsubject,:);
%y(:,1)=y(:,1)+.1;
%hist(log(y(:,1)))
utmp=utmp(matchsubject,:);
utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
xtmp=log(xtmp(matchsubject,:));
family='w';
[n,p]=size(utmp);
u=ones(n,1);
u(:,2)=stdize(utmp(:,1));
x=cell(1);
x{1}=double.empty(n,0);
x{2}=stdize(xtmp(:,1));
z=cell(1,p);
z{1}=double.empty(n,0);
z{2}=double.empty(n,0);
j=2;
jj=2;
while j<=p
    if ~all(utmp(:,j)==utmp(:,j-1))
        u=[u,stdize(utmp(:,j))];
        jj=jj+1;
        x{jj}=stdize(xtmp(:,j));
        if any(isnan(x{jj}))
            x{jj}=double.empty(n,0);
        end
        z{jj}=double.empty(n,0);
    else
        x{jj}=[x{jj},stdize(xtmp(:,j))];
        if any(isnan(x{jj}))
            x{jj}=double.empty(n,0);
        end
    end
    j=j+1;
end
p=size(u,2);
N = 200000*5; %number of iterations

%seed=1
load(sprintf('/Users/yangn/Box Sync/Pancancer_4/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))

tmp=squeeze(betax{9});
plot(tmp(abs(tmp)>0))
xlim([0,length(tmp(abs(tmp)>0))])
%ylabel('AUC','FontSize', 20,'FontWeight','bold')
set(gca,'XTickLabel',{})
set(gca,'YTickLabel',{})
xlabel('Iterations','FontSize', 20,'FontWeight','bold')
tmp=squeeze(betaX{6});
plot(tmp(abs(tmp)>0))
xlim([0,length(tmp(abs(tmp)>0))])
%ylabel('AUC','FontSize', 20,'FontWeight','bold')
set(gca,'XTickLabel',{})
set(gca,'YTickLabel',{})
xlabel('Iterations','FontSize', 20,'FontWeight','bold')
%%
clear
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
np = length(pathway);
for c = 12
    for pa = 1:np
        ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
        utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
        xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
        y=[ytmp(:,2),ytmp(:,1)];
        matchsubject=(y(:,1)>30&all(xtmp>0,2));
        y=y(matchsubject,:);
        %y(:,1)=y(:,1)+.1;
        %hist(log(y(:,1)))
        utmp=utmp(matchsubject,:);
        utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
        xtmp=log(xtmp(matchsubject,:));
        family='w';
        [n,p]=size(utmp);
        u=ones(n,1);
        u(:,2)=stdize(utmp(:,1));
        x=cell(1);
        x{1}=double.empty(n,0);
        x{2}=stdize(xtmp(:,1));
        z=cell(1,p);
        z{1}=double.empty(n,0);
        z{2}=double.empty(n,0);
        j=2;
        jj=2;
        while j<=p
            if ~all(utmp(:,j)==utmp(:,j-1))
                u=[u,stdize(utmp(:,j))];
                jj=jj+1;
                x{jj}=stdize(xtmp(:,j));
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
                z{jj}=double.empty(n,0);
            else
                x{jj}=[x{jj},stdize(xtmp(:,j))];
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
            end
            j=j+1;
        end
        p=size(u,2);
        N = 1000000; %number of iterations
        %load(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000 (yn2584@eid.utexas.edu)/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        load(sprintf('/Users/yangn/Box Sync/untitled folder/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        %         save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_urate.txt',cancertype{c},pathway{pa}),'urate_post','-ascii')
        %         save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_v0_est.txt',cancertype{c},pathway{pa}),'v0_est','-ascii')
        %         save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_v0_upper.txt',cancertype{c},pathway{pa}),'v0_upper','-ascii')
        %         save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_v0_lower.txt',cancertype{c},pathway{pa}),'v0_lower','-ascii')
        %         save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_x.txt',cancertype{c},pathway{pa}),'xtmp','-ascii')
        %save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_linrate.txt',cancertype{c},pathway{pa}),'linrate','-ascii')
        if pa==1
            xt = xt{8};
            urate_pred_vec = u_pred_rate(:);
            v0_pred_vec = v0_pred(:);
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Apoptosis/data/u_pred_rate.txt','u_pred_rate','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Apoptosis/data/v0_pred.txt','v0_pred','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Apoptosis/data/xt.txt','xt','-ascii')
        elseif pa==2
            xt = [xt{3},xt{4}(:,1),xt{7},xt{2},xt{5}];
            urate_pred_vec = u_pred_rate(:);
            v0_pred_vec = v0_pred(:);
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Breast/data/u_pred_rate.txt','u_pred_rate','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Breast/data/v0_pred.txt','v0_pred','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Breast/data/xt.txt','xt','-ascii')
        elseif pa==4
            xt = [xt{4},xt{6},xt{2},xt{3}];
            urate_pred_vec = u_pred_rate(:);
            v0_pred_vec = v0_pred(:);
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Core/data/u_pred_rate.txt','u_pred_rate','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Core/data/v0_pred.txt','v0_pred','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Core/data/xt.txt','xt','-ascii')
        elseif pa==5
            xt = [xt{6},xt{7},xt{8},xt{9},xt{2},xt{10}];
            urate_pred_vec = u_pred_rate(:);
            v0_pred_vec = v0_pred(:);
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_DNA/data/u_pred_rate.txt','u_pred_rate','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_DNA/data/v0_pred.txt','v0_pred','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_DNA/data/xt.txt','xt','-ascii')
        elseif pa==7
            xt = [xt{2},xt{3},xt{4},xt{5}];
            urate_pred_vec = u_pred_rate(:);
            v0_pred_vec = v0_pred(:);
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Hr/data/u_pred_rate.txt','u_pred_rate','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Hr/data/v0_pred.txt','v0_pred','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Hr/data/xt.txt','xt','-ascii')
        elseif pa==8
            xt = [xt{2},xt{3},xt{4}];
            urate_pred_vec = u_pred_rate(:);
            v0_pred_vec = v0_pred(:);
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Hs/data/u_pred_rate.txt','u_pred_rate','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Hs/data/v0_pred.txt','v0_pred','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_Hs/data/xt.txt','xt','-ascii')
        elseif pa==9
            xt = [xt{3}(:,2:3),xt{5}(:,2),xt{6},xt{10},xt{11}];
            urate_pred_vec = u_pred_rate(:);
            v0_pred_vec = v0_pred(:);
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_PI3K/data/u_pred_rate.txt','u_pred_rate','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_PI3K/data/v0_pred.txt','v0_pred','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_PI3K/data/xt.txt','xt','-ascii')
            %         elseif pa==10
            %             xt = xt{6}(:,1:2);
            %             urate_pred_vec = u_pred_rate(:);
            %             v0_pred_vec = v0_pred(:);
            %             save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_RAS/data/u_pred_rate.txt','u_pred_rate','-ascii')
            %             save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_RAS/data/v0_pred.txt','v0_pred','-ascii')
            %             save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_RAS/data/xt.txt','xt','-ascii')
        elseif pa==11
            xt = [xt{2},xt{3},xt{4},xt{5},xt{6},xt{7},xt{8}];
            urate_pred_vec = u_pred_rate(:);
            v0_pred_vec = v0_pred(:);
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_RTK/data/u_pred_rate.txt','u_pred_rate','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_RTK/data/v0_pred.txt','v0_pred','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_RTK/data/xt.txt','xt','-ascii')
        elseif pa==12
            xt = [xt{2},xt{3},xt{4},xt{5},xt{6},xt{7},xt{8},xt{9}];
            urate_pred_vec = u_pred_rate(:);
            v0_pred_vec = v0_pred(:);
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_TSC/data/u_pred_rate.txt','u_pred_rate','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_TSC/data/v0_pred.txt','v0_pred','-ascii')
            save('/Users/yangn/Dropbox/Research/projects/GVSM/KIRC_TSC/data/xt.txt','xt','-ascii')
        end
    end
end
%output for Rshiny

%%
clear
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
np = length(pathway);
for c = [19,24,10]
    for pa = 1:np
        ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
        utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
        xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
        y=[ytmp(:,2),ytmp(:,1)];
        matchsubject=(y(:,1)>30&all(xtmp>0,2));
        y=y(matchsubject,:);
        %y(:,1)=y(:,1)+.1;
        hist(log(y(:,1)))
        utmp=utmp(matchsubject,:);
        utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
        xtmp=log(xtmp(matchsubject,:));
        family='w';
        [n,p]=size(utmp);
        u=ones(n,1);
        u(:,2)=stdize(utmp(:,1));
        x=cell(1);
        x{1}=double.empty(n,0);
        x{2}=stdize(xtmp(:,1));
        z=cell(1,p);
        z{1}=double.empty(n,0);
        z{2}=double.empty(n,0);
        j=2;
        jj=2;
        while j<=p
            if ~all(utmp(:,j)==utmp(:,j-1))
                u=[u,stdize(utmp(:,j))];
                jj=jj+1;
                x{jj}=stdize(xtmp(:,j));
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
                z{jj}=double.empty(n,0);
            else
                x{jj}=[x{jj},stdize(xtmp(:,j))];
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
            end
            j=j+1;
        end
        p=size(u,2);
        N = 1000000; %number of iterations
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_urate.txt',cancertype{c},pathway{pa}),'urate_post','-ascii')
        save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_v0_est.txt',cancertype{c},pathway{pa}),'v0_est','-ascii')
        save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_v0_upper.txt',cancertype{c},pathway{pa}),'v0_upper','-ascii')
        save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_v0_lower.txt',cancertype{c},pathway{pa}),'v0_lower','-ascii')
        save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_x.txt',cancertype{c},pathway{pa}),'xtmp','-ascii')
        %save(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_linrate.txt',cancertype{c},pathway{pa}),'linrate','-ascii')
    end
end


%%
%c-index
clear
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
np = length(pathway);
c_ind = zeros(4,np);
c_ind_Enet = zeros(4,np);
TIME = zeros(4,np);
cc=0;
npro=0;%number of proteins selected across pathways and patients
for c = [12,19,24,10]
    cc=cc+1;
    for pa = 1:np
        ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
        utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
        xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
        y=[ytmp(:,2),ytmp(:,1)];
        matchsubject=(y(:,1)>30&all(xtmp>0,2));
        y=y(matchsubject,:);
        %y(:,1)=y(:,1)+.1;
        utmp=utmp(matchsubject,:);
        utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
        xtmp=log(xtmp(matchsubject,:));
        family='w';
        [n,p]=size(utmp);
        u=ones(n,1);
        u(:,2)=stdize(utmp(:,1));
        x=cell(1);
        x{1}=double.empty(n,0);
        x{2}=stdize(xtmp(:,1));
        z=cell(1,p);
        z{1}=double.empty(n,0);
        z{2}=double.empty(n,0);
        j=2;
        jj=2;
        while j<=p
            if ~all(utmp(:,j)==utmp(:,j-1))
                u=[u,stdize(utmp(:,j))];
                jj=jj+1;
                x{jj}=stdize(xtmp(:,j));
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
                z{jj}=double.empty(n,0);
            else
                x{jj}=[x{jj},stdize(xtmp(:,j))];
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
            end
            j=j+1;
        end
        p=size(u,2);
        N = 200000*5;
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        if c==12
            npro=npro+sum(sum(u_est(:,2:end)));
        end
        co = 0;
        for i = 1:n
            for j = 1:n
                if y(i,2)==1&&y(j,1)>y(i,1)
                    co = co+1;
                    if ypred(j)>ypred(i)
                        c_ind(cc,pa)=c_ind(cc,pa)+1;
                    elseif ypred(j)==ypred(i)
                        c_ind(cc,pa)=c_ind(cc,pa)+.5;
                    end
                end
            end
        end
        c_ind(cc,pa) = c_ind(cc,pa)/co;
        ypred=csvread(sprintf('/Users/yangn/Box Sync/Pancancer_4/pred_Enet_%s_%s.csv',cancertype{c},pathway{pa}),1,1);
        co = 0;
        for i = 1:n
            for j = 1:n
                if y(i,2)==1&&y(j,1)>y(i,1)
                    co = co+1;
                    if ypred(j)>ypred(i)
                        c_ind_Enet(cc,pa)=c_ind_Enet(cc,pa)+1;
                    elseif ypred(j)==ypred(i)
                        c_ind_Enet(cc,pa)=c_ind_Enet(cc,pa)+.5;
                    end
                end
            end
        end
        c_ind_Enet(cc,pa) = c_ind_Enet(cc,pa)/co;
        TIME(cc,pa) = time;
    end
end
mean(TIME(:))/3600
std(TIME(:))/3600
plot(c_ind(1,:),c_ind_Enet(1,:),'o')
xlabel('BEHAVIOR')
ylabel('Elastic Net')
title('C-index for 12 pathways in KIRC')
hold on
plot([0,1],[0,1],'-r')
xlim([min(c_ind(1,:)),max(c_ind(1,:))])
ylim([min(c_ind_Enet(1,:)),max(c_ind_Enet(1,:))])
hold off
save('/Users/yangn/Box Sync/Pancancer_4/c_index_table.txt','c_ind','-ascii')
save('/Users/yangn/Box Sync/Pancancer_4/c_index_Enet_table.txt','c_ind_Enet','-ascii')
%c-index for GSM (with out gene expressions)
clear
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
np = length(pathway);
c_ind = zeros(4,np);
TIME = zeros(4,np);
cc=0;
for c = [12,19,24,10]
    cc=cc+1;
    for pa = 1:np
        ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
        utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
        xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
        y=[ytmp(:,2),ytmp(:,1)];
        matchsubject=(y(:,1)>30&all(xtmp>0,2));
        y=y(matchsubject,:);
        %y(:,1)=y(:,1)+.1;
        utmp=utmp(matchsubject,:);
        utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
        xtmp=log(xtmp(matchsubject,:));
        family='w';
        [n,p]=size(utmp);
        u=ones(n,1);
        u(:,2)=stdize(utmp(:,1));
        x=cell(1);
        x{1}=double.empty(n,0);
        x{2}=stdize(xtmp(:,1));
        z=cell(1,p);
        z{1}=double.empty(n,0);
        z{2}=double.empty(n,0);
        j=2;
        jj=2;
        while j<=p
            if ~all(utmp(:,j)==utmp(:,j-1))
                u=[u,stdize(utmp(:,j))];
                jj=jj+1;
                x{jj}=stdize(xtmp(:,j));
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
                z{jj}=double.empty(n,0);
            else
                x{jj}=[x{jj},stdize(xtmp(:,j))];
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
            end
            j=j+1;
        end
        p=size(u,2);
        N = 200000*5;
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000 (yn2584@eid.utexas.edu)/NG_%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        co = 0;
        for i = 1:n
            for j = 1:n
                if y(i,2)==1&&y(j,1)>y(i,1)
                    co = co+1;
                    if ypred(j)>ypred(i)
                        c_ind(cc,pa)=c_ind(cc,pa)+1;
                    elseif ypred(j)==ypred(i)
                        c_ind(cc,pa)=c_ind(cc,pa)+.5;
                    end
                    
                end
            end
        end
        c_ind(cc,pa) = c_ind(cc,pa)/co;
        TIME(cc,pa) = time;
    end
end
mean(TIME(:))/3600
std(TIME(:))/3600
save('/Users/yangn/Box Sync/Pancancer_4_mc1000000/c_index_table_NG.txt','c_ind','-ascii')

%c-index for GACM (KIRC)
clear
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
np = length(pathway);
c_ind = zeros(1,np);
TIME = zeros(1,np);
cc=0;
for c = 12
    cc=cc+1;
    for pa = 1:np
        ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
        utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
        xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
        y=[ytmp(:,2),ytmp(:,1)];
        matchsubject=(y(:,1)>30&all(xtmp>0,2));
        y=y(matchsubject,:);
        %y(:,1)=y(:,1)+.1;
        utmp=utmp(matchsubject,:);
        utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
        xtmp=log(xtmp(matchsubject,:));
        family='w';
        [n,p]=size(utmp);
        u=ones(n,1);
        u(:,2)=stdize(utmp(:,1));
        x=cell(1);
        x{1}=double.empty(n,0);
        x{2}=stdize(xtmp(:,1));
        z=cell(1,p);
        z{1}=double.empty(n,0);
        z{2}=double.empty(n,0);
        j=2;
        jj=2;
        while j<=p
            if ~all(utmp(:,j)==utmp(:,j-1))
                u=[u,stdize(utmp(:,j))];
                jj=jj+1;
                x{jj}=stdize(xtmp(:,j));
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
                z{jj}=double.empty(n,0);
            else
                x{jj}=[x{jj},stdize(xtmp(:,j))];
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
            end
            j=j+1;
        end
        p=size(u,2);
        N = 200000*5;
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/GACM_%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        co = 0;
        for i = 1:n
            for j = 1:n
                if y(i,2)==1&&y(j,1)>y(i,1)
                    co = co+1;
                    if ypred(j)>ypred(i)
                        c_ind(cc,pa)=c_ind(cc,pa)+1;
                    elseif ypred(j)==ypred(i)
                        c_ind(cc,pa)=c_ind(cc,pa)+.5;
                    end
                    
                end
            end
        end
        c_ind(cc,pa) = c_ind(cc,pa)/co;
        TIME(cc,pa) = time;
    end
end
mean(TIME(:))/3600
std(TIME(:))/3600
save('/Users/yangn/Box Sync/Pancancer_4_mc1000000/c_index_table_GACM.txt','c_ind','-ascii')


%%
%output
clear
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
np = length(pathway);
hm = []; %heatmap matrix
pm = zeros(4,np);%number of proteins for each cancer/pathway combination
cc=0;
for c = [12,19,24,10]
    cc=cc+1;
    hm_tmp2=[];
    for pa = 1:np
        ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
        utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
        xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
        y=[ytmp(:,2),ytmp(:,1)];
        matchsubject=(y(:,1)>30&all(xtmp>0,2));
        y=y(matchsubject,:);
        %y(:,1)=y(:,1)+.1;
        utmp=utmp(matchsubject,:);
        utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
        xtmp=log(xtmp(matchsubject,:));
        family='w';
        [n,p]=size(utmp);
        u=ones(n,1);
        u(:,2)=stdize(utmp(:,1));
        x=cell(1);
        x{1}=double.empty(n,0);
        x{2}=stdize(xtmp(:,1));
        z=cell(1,p);
        z{1}=double.empty(n,0);
        z{2}=double.empty(n,0);
        j=2;
        jj=2;
        while j<=p
            if ~all(utmp(:,j)==utmp(:,j-1))
                u=[u,stdize(utmp(:,j))];
                jj=jj+1;
                x{jj}=stdize(xtmp(:,j));
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
                z{jj}=double.empty(n,0);
            else
                x{jj}=[x{jj},stdize(xtmp(:,j))];
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
            end
            j=j+1;
        end
        p=size(u,2);
        N = 200000*5;
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        if c == 10 && pa==5 %HNSC & DNA damage response
            p = p-2;
            pm(cc,pa)=p;
            hm_tmp = zeros(1,2*p);
            ind=1:p+1;
            ind(3)= [];%remove BRCA2 because it has NaN's for all other cancers except for HNSC
            jj=0;
            for j = ind
                jj=jj+1;
                [ks2,~] = myksdensity(x{j+1},x{j+1});
                hm_tmp((jj-1)*2+1)=sum(urate(:,j+1).*ks2)/sum(ks2);
                hm_tmp(2*jj)=max(lnrate{j+1});
            end
        else
            p = p-1;
            pm(cc,pa)=p;
            hm_tmp = zeros(1,2*p);
            for j =1:p
                [ks2,~] = myksdensity(x{j+1},x{j+1});
                hm_tmp((j-1)*2+1)=sum(urate(:,j+1).*ks2)/sum(ks2);
                hm_tmp(2*j)=max(lnrate{j+1});
            end
        end
        hm_tmp2=[hm_tmp2,hm_tmp];
    end
    hm = [hm;hm_tmp2];
end
pm=pm(1,:);
save('/Users/yangn/Box Sync/Pancancer_4_mc1000000/heatmap_matrix.txt','hm','-ascii')
save('/Users/yangn/Box Sync/Pancancer_4_mc1000000/numberofproteins.txt','pm','-ascii')



%%
%output
clear
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
np = length(pathway);
pm = zeros(4,np);%number of proteins for each cancer/pathway combination
cc=0;
for c = [12,19,24,10]
    cc=cc+1;
    hm=[];
    for pa = 1:np
        ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
        utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
        xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
        nn=size(ytmp,1);
        y=[ytmp(:,2),ytmp(:,1)];
        matchsubject=(y(:,1)>30&all(xtmp>0,2));
        y=y(matchsubject,:);
        %y(:,1)=y(:,1)+.1;
        utmp=utmp(matchsubject,:);
        utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
        xtmp=log(xtmp(matchsubject,:));
        family='w';
        [n,p]=size(utmp);
        u=ones(n,1);
        u(:,2)=stdize(utmp(:,1));
        x=cell(1);
        x{1}=double.empty(n,0);
        x{2}=stdize(xtmp(:,1));
        z=cell(1,p);
        z{1}=double.empty(n,0);
        z{2}=double.empty(n,0);
        j=2;
        jj=2;
        while j<=p
            if ~all(utmp(:,j)==utmp(:,j-1))
                u=[u,stdize(utmp(:,j))];
                jj=jj+1;
                x{jj}=stdize(xtmp(:,j));
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
                z{jj}=double.empty(n,0);
            else
                x{jj}=[x{jj},stdize(xtmp(:,j))];
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
            end
            j=j+1;
        end
        p=size(u,2);
        N = 200000*5;
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4_mc1000000/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        sum(u_est)>0        %size(u_est,1)
        hm_tmp=zeros(nn,sum(sum(u_est)>0));
        hm_tmp(matchsubject,:)=v0_est(:,sum(u_est)>0);
        hm=[hm,hm_tmp(:,2:end)];
    end
    if cc==1
        save('/Users/yangn/Box Sync/Pancancer_4_mc1000000/KIRC_heatmap_matrix.txt','hm','-ascii')
    elseif cc==2
        save('/Users/yangn/Box Sync/Pancancer_4_mc1000000/OVCA_heatmap_matrix.txt','hm','-ascii')
    elseif cc==3
        save('/Users/yangn/Box Sync/Pancancer_4_mc1000000/SKCM_heatmap_matrix.txt','hm','-ascii')
    else
        save('/Users/yangn/Box Sync/Pancancer_4_mc1000000/HNSC_heatmap_matrix.txt','hm','-ascii')
    end
end


%%
%c-index for KIRC across different approaches:
%1: BEHAVIOR with proteins and genes
%2: Elastic net wiht proteins only
%3: BEHAVIOR with stages, proteins and genes
%4: Elastic net wiht stages and proteins
clear
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
np = length(pathway);
c_ind=zeros(4,12);
tmp=importdata('/Users/yangn/Box Sync/Pancancer_4/c_index_table.txt');
c_ind(1,:)=tmp(1,:);
tmp=importdata('/Users/yangn/Box Sync/Pancancer_4/c_index_Enet_table.txt');
c_ind(2,:)=tmp(1,:);
npro=0;%number of proteins selected across pathways and patients
for c = 12
    for pa = 1:np
        N = 1000000; %number of iterations
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4/Stage_%s_%s_mc%d_seed%d.mat',cancertype{c},pathway{pa},N,1))
        npro=npro+sum(sum(u_est(:,5:end)));
        co = 0;
        for i = 1:n
            for j = 1:n
                if y(i,2)==1&&y(j,1)>y(i,1)
                    co = co+1;
                    if ypred(j)>ypred(i)
                        c_ind(3,pa)=c_ind(3,pa)+1;
                    elseif ypred(j)==ypred(i)
                        c_ind(3,pa)=c_ind(3,pa)+.5;
                    end
                    
                end
            end
        end
        c_ind(3,pa) = c_ind(3,pa)/co;
        ypred=csvread(sprintf('/Users/yangn/Box Sync/Pancancer_4/pred_Enet_Stage_%s_%s.csv',cancertype{c},pathway{pa}),1,1);
        co = 0;
        for i = 1:n
            for j = 1:n
                if y(i,2)==1&&y(j,1)>y(i,1)
                    co = co+1;
                    if ypred(j)>ypred(i)
                        c_ind(4,pa)=c_ind(4,pa)+1;
                    elseif ypred(j)==ypred(i)
                        c_ind(4,pa)=c_ind(4,pa)+.5;
                    end
                    
                end
            end
        end
        c_ind(4,pa) = c_ind(4,pa)/co;
    end
end
save('/Users/yangn/Box Sync/Pancancer_4/c_index_table_KIRC.txt','c_ind','-ascii')

% plot(c_ind(1,:),c_ind(2,:),'ok','MarkerSize',15,'MarkerFaceColor','k')
% hold on
% plot([0,1],[0,1],'-r')
% plot(c_ind(1,:),c_ind(3,:),'sk','MarkerSize',15,'MarkerFaceColor','k')
% for i = 1:12
%     plot([c_ind(1,i),c_ind(1,i)],[c_ind(3,i),c_ind(2,i)],'--k')
% end
% xlim([min(min(c_ind(1:3,:))),max(max(c_ind(1:3,:)))])
% ylim([min(min(c_ind(1:3,:))),max(max(c_ind(1:3,:)))])
% xlabel('BEHAVIOR','FontSize',20,'FontWeight','bold')
% ylabel('Elastic net/BEHAVIRO+stages','FontSize',20,'FontWeight','bold')
% title('C-index for 12 pathways in KIRC','FontSize',20,'FontWeight','bold')
% set(gca,'FontSize',30)
% hold off

%%
c_ind=importdata('/Users/yangn/Box Sync/Pancancer_4/c_index_table_KIRC.txt');
plot(c_ind(1,:),c_ind(2,:),'ok','MarkerSize',15,'MarkerFaceColor','k')
hold on
plot([0,1],[0,1],'-r')
%plot(c_ind(3,:),c_ind(4,:),'sk','MarkerSize',15,'MarkerFaceColor','k')
%for i = 1:12
%    plot([c_ind(1,i),c_ind(3,i)],[c_ind(2,i),c_ind(4,i)],'--k')
%end
xlim([min(min(c_ind(1:2,:))),max(max(c_ind(1:2,:)))])
ylim([min(min(c_ind(1:2,:))),max(max(c_ind(1:2,:)))])
xlabel('BEHAVIOR','FontSize',20,'FontWeight','bold')
ylabel('Elastic net','FontSize',20,'FontWeight','bold')
title('C-index for 12 pathways in KIRC','FontSize',20,'FontWeight','bold')
set(gca,'FontSize',30)
hold off
