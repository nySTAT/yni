function [lin_est,nlin_est,ln_est,categ_est,const_est,urate,linrate,nlinrate,lnrate,categrate,constrate,ac_eta,ac_t,ac_xi,ac_sigma,betax,betaX,betaZ,betamu,const,lin,nlin,ln,categ,t,sigma,eta_sd,xi_sd,t_sd,sigma_var]=GVSM_sameX_MCMC(y,u,x,z,cutoff,N,thin,burnin,seed,family)
%%
%varying coefficients regression with thresholding and reduced rank
%orthogonal basis matrix

%u_est: the structure of v_est, logical(v_est)

%why not set ll_old=ll_new when updating t

%proposal parameters
%tic;
t_sd_vec = .1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
eta_sd_vec = .1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
sigma_var_vec= .1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
% t_sd = .25/2;
% eta_sd = .25/2;
% sigma_var=.2/2;
rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end

[n,p]=size(u);
q = size(x,2);
r = size(z,2);
%xi_sd = .2;%1/sqrt(q)/1.5; %was .5 .2
xi_sd_vec=.1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
%design matrix
inte = ones(n,1)/sqrt(n);%intercept
Z = double.empty(n,0);
Zind = [];
zmean = [];
zscale = [];
for i =1:r
    try
        Ztmp = dummyvar(z(:,i));
        Ztmp = Ztmp(:,2:end);
    catch
        Ztmp = z(:,i);
    end
    zmean = [zmean,mean(Ztmp)];
    Ztmp = Ztmp-repmat(mean(Ztmp),n,1);
    %zscale = [zscale,norm(Ztmp,'fro')*sqrt(n)/2*ones(1,size(Ztmp,2))];
    %Ztmp = Ztmp/norm(Ztmp,'fro')*sqrt(n)/2;
    zscale = [zscale,norm(Ztmp,'fro')*ones(1,size(Ztmp,2))];
    Ztmp = Ztmp/norm(Ztmp,'fro');
    Z = [Z,Ztmp];
    Zind = [Zind;i*ones(size(Ztmp,2),1)];
end
%continuous
order = 4; %order of splines
nknots = 16; %number of interior knots
M = order + nknots;
xx=bspline_quantileknots(order,nknots,x,x);
%xx = xx-repmat(mean(xx),[n,1]);
K = makeK(M);
Kinv = pinv(K);
X = double.empty(n,0);
Xind =[];
%x= x-repmat(mean(x),[n,1]);
for i = 1:q
    Xtmp = xx(:,(i-1)*M+1:i*M);
    [U,S,~]=svd(Xtmp*Kinv*Xtmp','econ');
    S = diag(S);
    nullvals = S < 10^-10;
    d = max(3, find( cumsum(S(~nullvals))/sum(S(~nullvals)) > .995 ,1));
    d = min(d, sum(~nullvals));
    Xtmp = U(:,1:d)*diag(sqrt(S(1:d)));
    Xtmp2 = [ones(n,1),x(:,i)];
    Xtmp = Xtmp- Xtmp2*(Xtmp2\Xtmp);
    Xtmp = Xtmp/norm(Xtmp,'fro');
    x(:,i) = x(:,i)-mean(x(:,i));
    x(:,i) = x(:,i)/norm(x(:,i),'fro');
    X = [X,Xtmp];
    Xind = [Xind;i*ones(size(Xtmp,2),1)];
end
dX = size(X,2);
dZ = size(Z,2);


%parameter
a_t = 0; b_t = .5;%uniform prior for t
a = 10^-4; b = 10^-4;%IG prior for sigma
a_tau = 5; b_tau = 25;
s0 = 1*10^-4;
a_w = 1/2;b_w=1/2;


xix_old = .1*randn(q,p);
xiX_old = .1*randn(dX,p);
xiZ_old = .1*randn(dZ,p);
ximu_old = .1*randn(p,1);
etax_old = .1*randn(q,p);
etaX_old = .1*randn(q,p);
etaZ_old = .1*randn(r,p);
etamu_old = .1*randn(p,1);
betax = zeros(q,p,(N-burnin)/thin);
betaX = zeros(dX,p,(N-burnin)/thin);
betaZ = zeros(dZ,p,(N-burnin)/thin);
betamu = zeros(p,(N-burnin)/thin);
taux_old = ones(q,p);
tauX_old = ones(q,p);
tauZ_old = ones(r,p);
taumu_old = ones(p,1);
betamu_old = etamu_old.*ximu_old;
betax_old = etax_old.*xix_old;
betaX_old = etaX_old(Xind,:).*xiX_old;
betaZ_old = etaZ_old(Zind,:).*xiZ_old;

for i = 1:q
    xibar=mean(abs(xix_old(i,:)),1);
    etax_old(i,:) = etax_old(i,:).*xibar;
    xix_old(i,:) = xix_old(i,:)./xibar;
    xibar=mean(abs(xiX_old(Xind==i,:)),1);
    etaX_old(i,:) = etaX_old(i,:).*xibar;
    xiX_old(Xind==i,:) = xiX_old(Xind==i,:)./repmat(xibar,[sum(Xind==i),1]);
end
for i = 1:r
    xibar=mean(abs(xiZ_old(Zind==i,:)),1);
    etaZ_old(i,:) = etaZ_old(i,:).*xibar;
    xiZ_old(Zind==i,:) = xiZ_old(Zind==i,:)./repmat(xibar,[sum(Zind==i),1]);
end
etamu_old = etamu_old.*abs(ximu_old);
ximu_old = ximu_old./abs(ximu_old);
sigma = ones((N-burnin)/thin,1);%sigma^2
t = zeros((N-burnin)/thin,1);
t_old=t(1);
gammax= s0*ones(q,p,(N-burnin)/thin);
gammaX = s0*ones(q,p,(N-burnin)/thin);
gammaZ = s0*ones(r,p,(N-burnin)/thin);
gammamu = s0*ones(p,(N-burnin)/thin);
gammax_old = gammax(:,:,1);
gammaX_old = gammaX(:,:,1);
gammaZ_old = gammaZ(:,:,1);
gammamu_old = gammamu(:,1);

v = zeros(n,p,(N-burnin)/thin);
v0 = zeros(n,p,(N-burnin)/thin);
ac_eta=0;
ac_xi =0;
ac_t=0;
ac_sigma=0;
eta_iter=5;
xi_iter=5;
t_iter=5;
sigma_iter=5;
eta_sd=eta_sd_vec(eta_iter);
xi_sd=xi_sd_vec(xi_iter);
t_sd=t_sd_vec(t_iter);
sigma_var=sigma_var_vec(sigma_iter);

sigma_old = sigma(1);
omega_old = .2;
regressor_old=zeros(n,p);
for j = 1:p
    regressor_old(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_old(:,j)+X*betaX_old(:,j)+Z*betaZ_old(:,j),t_old);
end
%algorithm begins
%tic;
ll_old = loglike(y,regressor_old,sigma_old,family);
iter=0;
for mc = 2:N
    
    %update eta
    for i = 1:q
        for j = 1:p
            regressor_new = regressor_old;
            etax_new = etax_old(:,j);
            etax_new(i) = etax_old(i,j) + eta_sd*randn(1);
            betax_new = etax_new.*xix_old(:,j);
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_new+X*betaX_old(:,j)+Z*betaZ_old(:,j),t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*(etax_new(i).^2./gammax_old(i,j)./taux_old(i,j))...
                +.5*(etax_old(i,j).^2./gammax_old(i,j)./taux_old(i,j));
            if lr > log(rand(1))
                ac_eta = ac_eta+1;
                ll_old=ll_new;
                etax_old(i,j) = etax_new(i);
                betax_old(:,j) = betax_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    for i = 1:q
        for j = 1:p
            regressor_new = regressor_old;
            etaX_new = etaX_old(:,j);
            etaX_new(i) = etaX_old(i,j) + eta_sd*randn(1);
            betaX_new = etaX_new(Xind).*xiX_old(:,j);
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_old(:,j)+X*betaX_new+Z*betaZ_old(:,j),t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*(etaX_new(i).^2./gammaX_old(i,j)./tauX_old(i,j))...
                +.5*(etaX_old(i,j).^2./gammaX_old(i,j)./tauX_old(i,j));
            if lr > log(rand(1))
                ac_eta = ac_eta+1;
                ll_old=ll_new;
                etaX_old(i,j) = etaX_new(i);
                betaX_old(:,j) = betaX_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    for i = 1:r
        for j = 1:p
            regressor_new = regressor_old;
            etaZ_new = etaZ_old(:,j);
            etaZ_new(i) = etaZ_old(i,j) + eta_sd*randn(1);
            betaZ_new = etaZ_new(Zind).*xiZ_old(:,j);
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_old(:,j)+X*betaX_old(:,j)+Z*betaZ_new,t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*(etaZ_new(i).^2./gammaZ_old(i,j)./tauZ_old(i,j))...
                +.5*(etaZ_old(i,j).^2./gammaZ_old(i,j)./tauZ_old(i,j));
            if lr > log(rand(1))
                ac_eta = ac_eta+1;
                ll_old=ll_new;
                etaZ_old(i,j) = etaZ_new(i);
                betaZ_old(:,j) = betaZ_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    for j = 1:p
        regressor_new = regressor_old;
        etamu_new = etamu_old(j) + eta_sd*randn(1);
        betamu_new = etamu_new.*ximu_old(j);
        regressor_new(:,j) = u(:,j).*threshold(betamu_new*inte+x*betax_old(:,j)+X*betaX_old(:,j)+Z*betaZ_old(:,j),t_old);
        ll_new = loglike(y,regressor_new,sigma_old,family);
        lr = ll_new-ll_old-.5*(etamu_new.^2./gammamu_old(j)./taumu_old(j))...
            +.5*(etamu_old(j).^2./gammamu_old(j)./taumu_old(j));
        if lr > log(rand(1))
            ac_eta = ac_eta+1;
            ll_old=ll_new;
            etamu_old(j) = etamu_new;
            betamu_old(j) = betamu_new;
            regressor_old(:,j) = regressor_new(:,j);
        end
    end
    
    %update
    mx_old=2*binornd(1,1./(1+exp(-2*xix_old)))-1;
    mX_old=2*binornd(1,1./(1+exp(-2*xiX_old)))-1;
    mZ_old=2*binornd(1,1./(1+exp(-2*xiZ_old)))-1;
    mmu_old=2*binornd(1,1./(1+exp(-2*ximu_old)))-1;
    %     mx_old=mx_old*0;
    %     mX_old=mX_old*0;
    %     mZ_old=mZ_old*0;
    %     mmu_old=mmu_old*0;
    
    %update xi
    for i = 1:q
        for j = 1:p
            regressor_new = regressor_old;
            xix_new = xix_old(:,j);
            xix_new(i) = xix_old(i,j) + xi_sd*randn(1);
            betax_new = etax_old(:,j).*xix_new;
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_new+X*betaX_old(:,j)+Z*betaZ_old(:,j),t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*(xix_new(i)-mx_old(i,j)).^2+.5*(xix_old(i,j)-mx_old(i,j)).^2;
            if lr > log(rand(1))
                ac_xi = ac_xi+1;
                ll_old=ll_new;
                xix_old(:,j) = xix_new;
                betax_old(:,j) = betax_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    
    for i = 1:q
        for j = 1:p
            regressor_new = regressor_old;
            xiX_new = xiX_old(:,j);
            ind = (Xind==i);
            xiX_new(ind) = xiX_old(ind,j) + xi_sd*randn(sum(ind),1);
            betaX_new = etaX_old(Xind,j).*xiX_new;
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_old(:,j)+X*betaX_new+Z*betaZ_old(:,j),t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*sum((xiX_new(ind)-mX_old(ind,j)).^2)+.5*sum((xiX_old(ind,j)-mX_old(ind,j)).^2);
            if lr > log(rand(1))
                ac_xi = ac_xi+1;
                ll_old=ll_new;
                xiX_old(:,j) = xiX_new;
                betaX_old(:,j) = betaX_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    
    
    
    for i = 1:r
        for j = 1:p
            regressor_new = regressor_old;
            xiZ_new = xiZ_old(:,j);
            ind = (Zind==i);
            xiZ_new(ind) = xiZ_old(ind,j) + xi_sd*randn(sum(ind),1);
            betaZ_new = etaZ_old(Zind,j).*xiZ_new;
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x*betax_old(:,j)+X*betaX_old(:,j)+Z*betaZ_new,t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*sum((xiZ_new(ind)-mZ_old(ind,j)).^2)+.5*sum((xiZ_old(ind,j)-mZ_old(ind,j)).^2);
            if lr > log(rand(1))
                ac_xi = ac_xi+1;
                ll_old=ll_new;
                xiZ_old(:,j) = xiZ_new;
                betaZ_old(:,j) = betaZ_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    
    for j = 1:p
        regressor_new = regressor_old;
        ximu_new = ximu_old(j) + xi_sd*randn(1);
        betamu_new = etamu_old(j).*ximu_new;
        regressor_new(:,j) = u(:,j).*threshold(betamu_new*inte+x*betax_old(:,j)+X*betaX_old(:,j)+Z*betaZ_old(:,j),t_old);
        ll_new = loglike(y,regressor_new,sigma_old,family);
        lr = ll_new-ll_old-.5*(ximu_new-mmu_old(j)).^2+.5*(ximu_old(j)-mmu_old(j)).^2;
        if lr > log(rand(1))
            ac_xi = ac_xi+1;
            ll_old=ll_new;
            ximu_old(j) = ximu_new;
            betamu_old(j) = betamu_new;
            regressor_old(:,j) = regressor_new(:,j);
        end
    end
    
    %rescale eta and xi
    
    for i = 1:q
        xibar=mean(abs(xix_old(i,:)),1);
        etax_old(i,:) = etax_old(i,:).*xibar;
        xix_old(i,:) = xix_old(i,:)./xibar;
        xibar=mean(abs(xiX_old(Xind==i,:)),1);
        etaX_old(i,:) = etaX_old(i,:).*xibar;
        xiX_old(Xind==i,:) = xiX_old(Xind==i,:)./repmat(xibar,[sum(Xind==i),1]);
    end
    for i = 1:r
        xibar=mean(abs(xiZ_old(Zind==i,:)),1);
        etaZ_old(i,:) = etaZ_old(i,:).*xibar;
        xiZ_old(Zind==i,:) = xiZ_old(Zind==i,:)./repmat(xibar,[sum(Zind==i),1]);
    end
    etamu_old = etamu_old.*abs(ximu_old);
    ximu_old = ximu_old./abs(ximu_old);
    
    
    %update t
    t_new = rtnorm(t_old,t_sd,a_t,b_t);
    regressor_new = u.*threshold(kron(betamu_old',inte)+x*betax_old+X*betaX_old+Z*betaZ_old,t_new);
    ll_new = loglike(y,regressor_new,sigma_old,family);
    lr = ll_new-ll_old + log(dtnorm(t_old,t_new,t_sd,a_t,b_t)) - log(dtnorm(t_new,t_old,t_sd,a_t,b_t));
    if lr>log(rand(1))
        ac_t = ac_t + 1;
        t_old = t_new;
        regressor_old = regressor_new;
    end
    %t_old=0;
    %update tau
    taux_old=1./gamrnd(a_tau+.5,1./(b_tau+etax_old.^2./gammax_old/2));
    tauX_old=1./gamrnd(a_tau+.5,1./(b_tau+etaX_old.^2./gammaX_old/2));
    tauZ_old=1./gamrnd(a_tau+.5,1./(b_tau+etaZ_old.^2./gammaZ_old/2));
    taumu_old=1./gamrnd(a_tau+.5,1./(b_tau+etamu_old.^2./gammamu_old/2));
    
    
    
    %update gammma
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etax_old.^2/2/s0./taux_old);
    gammax_old=binornd(1,ptmp./(1+ptmp));
    gammax_old(ptmp==Inf)=1;
    gammax_old(gammax_old==0)=s0;
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etaX_old.^2/2/s0./tauX_old);
    gammaX_old=binornd(1,ptmp./(1+ptmp));
    gammaX_old(ptmp==Inf)=1;
    gammaX_old(gammaX_old==0)=s0;
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etaZ_old.^2/2/s0./tauZ_old);
    gammaZ_old=binornd(1,ptmp./(1+ptmp));
    gammaZ_old(ptmp==Inf)=1;
    gammaZ_old(gammaZ_old==0)=s0;
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etamu_old.^2/2/s0./taumu_old);
    gammamu_old=binornd(1,ptmp./(1+ptmp));
    gammamu_old(ptmp==Inf)=1;
    gammamu_old(gammamu_old==0)=s0;
    
    %update omega
    ngamma=sum(sum(gammax_old==1))+sum(sum(gammaX_old==1))+sum(sum(gammaZ_old==1))+sum(gammamu_old==1);
    omega_old = betarnd(a_w+ngamma,b_w+(2*q+r+1)*p-ngamma);
    
    %update sigma
    if family=='n'
        sse = -(ll_old+.5*log(sigma_old))*2*sigma_old;
        sigma_old = 1/gamrnd(a+n/2,1/(b+sse/2));
        ll_old = -sse/2/sigma_old-.5*log(sigma_old);
    elseif family=='w'
        mm = log(sigma_old^2/sqrt(sigma_var+sigma_old^2));
        vv = sqrt(log(sigma_var/sigma_old^2+1));
        sigma_new = lognrnd(mm,vv);
        mm2 = log(sigma_new^2/sqrt(sigma_var+sigma_new^2));
        vv2 = sqrt(log(sigma_var/sigma_new^2+1));
        ll_new = loglike(y,regressor_old,sigma_new,family);
        lr = ll_new-ll_old + log(gampdf(sigma_new,a,1/b)) - log(gampdf(sigma_old,a,1/b))-log(lognpdf(sigma_new,mm,vv))+log(lognpdf(sigma_old,mm2,vv2)) ;
        if lr>log(rand(1))
            ac_sigma = ac_sigma + 1;
            sigma_old = sigma_new;
            ll_old=ll_new;
        end
    elseif family=='l'
        mm = log(sigma_old^2/sqrt(sigma_var+sigma_old^2));
        vv = sqrt(log(sigma_var/sigma_old^2+1));
        sigma_new = lognrnd(mm,vv);
        mm2 = log(sigma_new^2/sqrt(sigma_var+sigma_new^2));
        vv2 = sqrt(log(sigma_var/sigma_new^2+1));
        ll_new = loglike(y,regressor_old,sigma_new,family);
        lr = ll_new-ll_old + log(gampdf(1/sigma_new,a,1/b)) - log(gampdf(1/sigma_old,a,1/b))-log(lognpdf(sigma_new,mm,vv))+log(lognpdf(sigma_old,mm2,vv2)) ;
        if lr>log(rand(1))
            ac_sigma = ac_sigma + 1;
            sigma_old = sigma_new;
            ll_old=ll_new;
        end
    end
    
    
    
    if mod(mc,2000)==0
        fprintf('%d steps finished\n',mc)
        fprintf('%d steps to go\n',N-mc)
    end
    
    if mod(mc,500)==0&&mc<=burnin
        ac_eta_mornitor = ac_eta/(mc-1)/p/(2*q+r+1);
        ac_xi_mornitor = ac_xi/(mc-1)/p/(2*q+r+1);
        ac_t_mornitor = ac_t/(mc-1);
        ac_sigma_mornitor=ac_sigma/(mc-1);
        if ac_eta_mornitor>.5&&eta_iter<9
            eta_iter=eta_iter+1;
            eta_sd=eta_sd_vec(eta_iter);
        elseif ac_eta_mornitor<.2&&eta_iter>1
            eta_iter=eta_iter-1;
            eta_sd=eta_sd_vec(eta_iter);
        end
        if ac_xi_mornitor>.5&&xi_iter<9
            xi_iter=xi_iter+1;
            xi_sd=xi_sd_vec(xi_iter);
        elseif ac_xi_mornitor<.2&&xi_iter>1
            xi_iter=xi_iter-1;
            xi_sd=xi_sd_vec(xi_iter);
        end
        if ac_t_mornitor>.5&&t_iter<9
            t_iter=t_iter+1;
            t_sd=t_sd_vec(t_iter);
        elseif ac_t_mornitor<.2&&t_iter>1
            t_iter=t_iter-1;
            t_sd=t_sd_vec(t_iter);
        end
        if ac_sigma_mornitor>.5&&sigma_iter<9
            sigma_iter=sigma_iter+1;
            sigma_var=sigma_var_vec(sigma_iter);
        elseif ac_sigma_mornitor<.2&&sigma_iter>1
            sigma_iter=sigma_iter-1;
            sigma_var=sigma_var_vec(sigma_iter);
        end        
    end
    %save samples every "thin" iterations
    if mod(mc,thin)==0&&mc>burnin
        iter = iter + 1;
        betax(:,:,iter)=betax_old;
        betaX(:,:,iter)=betaX_old;
        betaZ(:,:,iter)=betaZ_old;
        betamu(:,iter)=betamu_old;
        t(iter) = t_old;
        gammax(:,:,iter)=gammax_old;
        gammaX(:,:,iter)=gammaX_old;
        gammaZ(:,:,iter)=gammaZ_old;
        gammamu(:,iter)=gammamu_old;
        sigma(iter) = sigma_old;
        v0(:,:,iter) = kron((betamu_old.*(gammamu_old==1))',inte)+x*(betax_old.*(gammax_old==1))+X*(betaX_old.*(gammaX_old(Xind,:)==1))+Z*(betaZ_old.*(gammaZ_old(Zind,:)==1));
        v(:,:,iter) = threshold(v0(:,:,iter),t_old);
    end
end

ac_eta = ac_eta/(N-1)/p/(2*q+r+1);
ac_xi = ac_xi/(N-1)/p/(2*q+r+1);
ac_t = ac_t/(N-1);
ac_sigma=ac_sigma/(N-1);

%effect modifier structure
const = gammamu==1;
lin = gammax==1; %linear
nlin = gammaX==1;%nonlinear
ln = gammax==1|gammaX==1;%linear or nonlinear
categ = gammaZ==1;%categorical

constrate = mean(const,2);
linrate = mean(lin,3);
nlinrate = mean(nlin,3);
lnrate = mean(ln,3);
categrate = mean(categ,3);

const_est = constrate>cutoff;
lin_est = linrate>cutoff;
nlin_est = nlinrate>cutoff;
ln_est = lnrate>cutoff;
%ln_est2 = lin_est|nlin_est;
categ_est = categrate>cutoff;


urate = 0;%regression strucutre
for mc = 1:(N-burnin)/thin
    urate = urate+(v(:,:,mc)~=0);
end
urate = urate/((N-burnin)/thin);
%time2=toc;
