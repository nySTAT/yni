clear;
y = csvread('../data/GBM_image_volume/survdata.csv',0,0);
u = csvread('../data/GBM_image_volume/volumedata.csv',0,0);
x = csvread('../data/GBM_image/genedata_q49.csv',0,0);%18,20,49
clin = csvread('../data/GBM_image_volume/clinicaldata.csv',0,0);

volumename = importdata('../data/GBM_image_volume/volumename.txt');
genename = importdata('../data/GBM_image/genename_q49.txt');
clinicalname=importdata('../data/GBM_image_volume/clinicalname.txt');

matchsubject=[1:6,8:19,21:42,44:47,51];
x=x(matchsubject,[14,29,33,38,44]);%[14,29,33,38,44][14,33]
family='w';
[x,xmean,xstd]=stdize(x);
[u,umean,ustd]=stdize(u);
clin(:,1:2)=stdize(clin(:,1:2));
u = [u,clin(:,1:3)];
[n,p] = size(u);
u = [ones(n,1),u];
p=p+1;
q = size(x,2);
r=0;
z = double.empty(n,0);
N = 200000*5; %number of iterations
Npo=N/10;
thin = 5;
burnin = floor(N/2);
burninpo=floor(Npo/10);
cutoff=0.5;
seed=2;
ut=[];
xt=[];
zt=[];
tic;
[lin_est,nlin_est,ln_est,categ_est,const_est,urate,linrate,nlinrate,lnrate,categrate,constrate,ac_eta,ac_t,ac_xi,ac_sigma,betax,betaX,betaZ,betamu,const,lin,nlin,ln,categ,t,sigma,eta_sd,xi_sd,t_sd,sigma_var]=GVSM_sameX_MCMC(y,u,x,z,cutoff,N,thin,burnin,seed,family);
[betax_est,betaX_est,betaZ_est,betamu_est,~,~,~,~,v0_est,v0_upper,v0_lower,v_est,v_upper,v_lower,urate_post,u_est,ypred,linkpred,lppred,v0_pred,v0_pred_upper,v0_pred_lower,v_pred,v_pred_upper,v_pred_lower,u_pred,u_pred_rate,t_est,sigma_est]=postMCMC_sameX(y,u,x,z,cutoff,ut,xt,zt,lin_est,nlin_est,categ_est,const_est,Npo,burninpo,seed,family,eta_sd,xi_sd,t_sd,sigma_var);

time=toc;




fname = sprintf('GBM_volume_clinical_expression_p%d_q%d_r%d_mc%d_seed%d.mat',p-1,q,r,N,seed);
save(fname)

