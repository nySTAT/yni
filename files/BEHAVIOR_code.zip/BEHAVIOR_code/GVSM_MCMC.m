function [lin_est,nlin_est,ln_est,categ_est,const_est,urate,linrate,nlinrate,lnrate,categrate,constrate,ac_eta,ac_t,ac_xi,ac_sigma,betax,betaX,betaZ,betamu,const,lin,nlin,ln,categ,t,sigma,eta_sd,xi_sd,t_sd,sigma_var,ll]=GVSM_MCMC(y,u,x,z,cutoff,N,thin,burnin,seed,family)
%% 
%varying coefficients regression with thresholding and reduced rank
%orthogonal basis matrix

%u_est: the structure of v_est, logical(v_est)

%proposal parameters
%tic;
t_sd_vec = .1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
eta_sd_vec = .1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
sigma_var_vec= .1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
xi_sd_vec=.1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end

[n,p]=size(u);

ximu_old = .1*randn(p,1);
etamu_old = .1*randn(p,1);
betamu = zeros(p,(N-burnin)/thin);
betamu_old = etamu_old.*ximu_old;
%design matrix
inte = ones(n,1)/sqrt(n);%intercept
%categorical
Z = cell(p,1);
Zind = cell(p,1);
zmean = cell(p,1);
zscale = cell(p,1);
dZ = cell(p,1);
xiZ_old = cell(p,1);
betaZ = cell(p,1);
betaZ_old = cell(p,1);
etaZ_old = cell(p,1);
nr=zeros(p,1);
tauZ_old = cell(p,1);
for j =1:p
    Z{j}=double.empty(n,0);
    Zind{j}=double.empty(0,1);
    zmean{j}=[];
    zscale{j}=[];
    nr(j) = size(z{j},2);
    for i =1:nr(j)
        try
            Ztmp = dummyvar(z{j}(:,i));
            Ztmp = Ztmp(:,2:end);
        catch
            Ztmp=z{j}(:,i);
        end
        zmean{j} = [zmean{j},mean(Ztmp)];
        Ztmp = Ztmp-repmat(mean(Ztmp),n,1);
        zscale{j} = [zscale{j},norm(Ztmp,'fro')*ones(1,size(Ztmp,2))];
        Ztmp = Ztmp/norm(Ztmp,'fro');
        Z{j} = [Z{j},Ztmp];
        Zind{j} = [Zind{j};i*ones(size(Ztmp,2),1)];
    end
    dZ{j}=size(Z{j},2);
    xiZ_old{j} = .1*randn(dZ{j},1);
    betaZ{j} = zeros(dZ{j},(N-burnin)/thin);
    etaZ_old{j}=.1*randn(nr(j),1);
    tauZ_old{j}=ones(nr(j),1);
    betaZ_old{j}=etaZ_old{j}(Zind{j}).*xiZ_old{j};
end

%continuous
order = 4; %order of splines
nknots = 16; %number of interior knots
M = order + nknots;
K = makeK(M);
Kinv = pinv(K);
dX = cell(p,1);
X=cell(p,1);
Xind=cell(p,1);
xix_old = cell(p,1);
xiX_old=cell(p,1);
betaX = cell(p,1);
betaX_old=cell(p,1);
etax_old = cell(p,1);
etaX_old = cell(p,1);
xx= cell(p,1);
%xxt=cell(p,1);
betax = cell(p,1);
betax_old = cell(p,1);
nq = zeros(p,1);
taux_old = cell(p,1);
tauX_old = cell(p,1);
for j = 1:p
    xx{j}=bspline_quantileknots(order,nknots,x{j},x{j});
%     if ifpredu==1
%         xxt{j}=bspline_quantileknots(order,nknots,x{j},xt{j});
%     end
    X{j} = double.empty(n,0);
    Xind{j} =double.empty(0,1);
    nq(j) = size(x{j},2);
    for i = 1:nq(j)
        Xtmp = xx{j}(:,(i-1)*M+1:i*M);
        [U,S,~]=svd(Xtmp*Kinv*Xtmp','econ');
        S = diag(S);
        nullvals = S < 10^-10;
        d = max(3, find( cumsum(S(~nullvals))/sum(S(~nullvals)) > .995 ,1));
        d = min(d, sum(~nullvals));
        Xtmp = U(:,1:d)*diag(sqrt(S(1:d)));
        Xtmp2 = [ones(n,1),x{j}(:,i)];
        Xtmp = Xtmp- Xtmp2*(Xtmp2\Xtmp);
        Xtmp = Xtmp/norm(Xtmp,'fro');
        x{j}(:,i) = x{j}(:,i)-mean(x{j}(:,i));
        x{j}(:,i) = x{j}(:,i)/norm(x{j}(:,i),'fro');
        X{j} = [X{j},Xtmp];
        Xind{j} = [Xind{j};i*ones(size(Xtmp,2),1)];
    end
    dX{j}=size(X{j},2);
    xix_old{j} = .1*randn(nq(j),1);
    xiX_old{j} = .1*randn(dX{j},1);
    betaX{j} = zeros(dX{j},(N-burnin)/thin);
    etax_old{j} = .1*randn(nq(j),1);
    etaX_old{j} = .1*randn(nq(j),1);
    betax{j}=zeros(nq(j),(N-burnin)/thin);
    betax_old{j} = etax_old{j}.*xix_old{j};
    taux_old{j}=ones(nq(j),1);
    tauX_old{j}=ones(nq(j),1);
    betaX_old{j} = etaX_old{j}(Xind{j}).*xiX_old{j};
end

%parameter
a_t = 0; b_t = 1;%uniform prior for t
a = 10^-4; b = 10^-4;%IG prior for sigma
a_tau = 5; b_tau = 100; %use (5,25) for real data (5,100) for simulation  
s0 = 2.5*10^-4;
a_w = 1/2;b_w=1/2;


for j = 1:p
    for i = 1:nq(j)
        xibar=mean(abs(xix_old{j}(i)),1);
        etax_old{j}(i) = etax_old{j}(i).*xibar;
        xix_old{j}(i) = xix_old{j}(i)./xibar;
        xibar=mean(abs(xiX_old{j}(Xind{j}==i)),1);
        etaX_old{j}(i) = etaX_old{j}(i).*xibar;
        xiX_old{j}(Xind{j}==i) = xiX_old{j}(Xind{j}==i)./repmat(xibar,[sum(Xind{j}==i),1]);
    end
    for i = 1:nr(j)
        xibar=mean(abs(xiZ_old{j}(Zind{j}==i)),1);
        etaZ_old{j}(i) = etaZ_old{j}(i).*xibar;
        xiZ_old{j}(Zind{j}==i) = xiZ_old{j}(Zind{j}==i)./repmat(xibar,[sum(Zind{j}==i),1]);
        
    end
end
etamu_old = etamu_old.*abs(ximu_old);
ximu_old = ximu_old./abs(ximu_old);
sigma = ones((N-burnin)/thin,1);%sigma^2
t = zeros((N-burnin)/thin,1);
ll = zeros((N-burnin)/thin,1);
t_old=t(1);
gammax=cell(p,1);
gammaX=cell(p,1);
gammaZ=cell(p,1);
gammax_old=cell(p,1);
gammaX_old=cell(p,1);
gammaZ_old=cell(p,1);

for j =1:p
    gammax{j} = s0*ones(nq(j),(N-burnin)/thin);
    gammaX{j} = s0*ones(nq(j),(N-burnin)/thin);
    gammaZ{j} = s0*ones(nr(j),(N-burnin)/thin);
    gammax_old{j} = gammax{j}(:,1);
    gammaX_old{j} = gammaX{j}(:,1);
    gammaZ_old{j} = gammaZ{j}(:,1);
end
gammamu = s0*ones(p,(N-burnin)/thin);
gammamu_old = gammamu(:,1);
v = zeros(n,p,(N-burnin)/thin);
v0 = zeros(n,p,(N-burnin)/thin);
ac_eta=0;
ac_xi =0;
ac_t=0;
ac_sigma=0;
eta_iter=5;
xi_iter=5;
t_iter=5;
sigma_iter=5;
eta_sd=eta_sd_vec(eta_iter);
xi_sd=xi_sd_vec(xi_iter);
t_sd=t_sd_vec(t_iter);
sigma_var=sigma_var_vec(sigma_iter);
sigma_old = sigma(1);
taumu_old = ones(p,1);
omega_old = .2;
regressor_old=zeros(n,p);
for j = 1:p
    regressor_old(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x{j}*betax_old{j}+X{j}*betaX_old{j}+Z{j}*betaZ_old{j},t_old);
end
%algorithm begins
%tic;
ll_old = loglike(y,regressor_old,sigma_old,family);
iter=0;
for mc = 2:N
%update eta

    for j = 1:p
        for i = 1:nq(j)
            regressor_new = regressor_old;
            etax_new = etax_old{j};
            etax_new(i) = etax_old{j}(i) + eta_sd*randn(1);
            betax_new = etax_new.*xix_old{j};
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x{j}*betax_new+X{j}*betaX_old{j}+Z{j}*betaZ_old{j},t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*(etax_new(i).^2./gammax_old{j}(i)./taux_old{j}(i))...
                +.5*(etax_old{j}(i).^2./gammax_old{j}(i)./taux_old{j}(i));
            if lr > log(rand(1))
                ac_eta = ac_eta+1;
                ll_old=ll_new;
                etax_old{j}(i) = etax_new(i);
                betax_old{j} = betax_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    for j = 1:p
        for i = 1:nq(j)
            regressor_new = regressor_old;
            etaX_new = etaX_old{j};
            etaX_new(i) = etaX_old{j}(i) + eta_sd*randn(1);
            betaX_new = etaX_new(Xind{j}).*xiX_old{j};
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x{j}*betax_old{j}+X{j}*betaX_new+Z{j}*betaZ_old{j},t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*(etaX_new(i).^2./gammaX_old{j}(i)./tauX_old{j}(i))...
                +.5*(etaX_old{j}(i).^2./gammaX_old{j}(i)./tauX_old{j}(i));
            if lr > log(rand(1))
                ac_eta = ac_eta+1;
                ll_old=ll_new;
                etaX_old{j}(i) = etaX_new(i);
                betaX_old{j} = betaX_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    for j = 1:p
        for i = 1:nr(j)
            regressor_new = regressor_old;
            etaZ_new = etaZ_old{j};
            etaZ_new(i) = etaZ_old{j}(i) + eta_sd*randn(1);
            betaZ_new = etaZ_new(Zind{j}).*xiZ_old{j};
            regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x{j}*betax_old{j}+X{j}*betaX_old{j}+Z{j}*betaZ_new,t_old);
            ll_new = loglike(y,regressor_new,sigma_old,family);
            lr = ll_new-ll_old-.5*(etaZ_new(i).^2./gammaZ_old{j}(i)./tauZ_old{j}(i))...
                +.5*(etaZ_old{j}(i).^2./gammaZ_old{j}(i)./tauZ_old{j}(i));
            if lr > log(rand(1))
                ac_eta = ac_eta+1;
                ll_old=ll_new;
                etaZ_old{j}(i) = etaZ_new(i);
                betaZ_old{j} = betaZ_new;
                regressor_old(:,j) = regressor_new(:,j);
            end
        end
    end
    for j = 1:p
        regressor_new = regressor_old;
        etamu_new = etamu_old(j) + eta_sd*randn(1);
        betamu_new = etamu_new.*ximu_old(j);
        regressor_new(:,j) = u(:,j).*threshold(betamu_new*inte+x{j}*betax_old{j}+X{j}*betaX_old{j}+Z{j}*betaZ_old{j},t_old);
        ll_new = loglike(y,regressor_new,sigma_old,family);
        lr = ll_new-ll_old-.5*(etamu_new.^2./gammamu_old(j)./taumu_old(j))...
            +.5*(etamu_old(j).^2./gammamu_old(j)./taumu_old(j));
        if lr > log(rand(1))
            ac_eta = ac_eta+1;
            ll_old=ll_new;
            etamu_old(j) = etamu_new;
            betamu_old(j) = betamu_new;
            regressor_old(:,j) = regressor_new(:,j);
        end
    end
    
    %update
    
    mmu_old=2*binornd(1,1./(1+exp(-2*ximu_old)))-1;
    mx_old = cell(p,1);
    mX_old = cell(p,1);
    mZ_old = cell(p,1);

    %update xi
    for j = 1:p
        mx_old{j}=2*binornd(1,1./(1+exp(-2*xix_old{j})))-1;
        mX_old{j}=2*binornd(1,1./(1+exp(-2*xiX_old{j})))-1;
        mZ_old{j}=2*binornd(1,1./(1+exp(-2*xiZ_old{j})))-1;
        regressor_new = regressor_old;
        xix_new = xix_old{j} + xi_sd*randn(nq(j),1);
        betax_new = etax_old{j}.*xix_new;
        xiX_new = xiX_old{j} + xi_sd*randn(dX{j},1);
        betaX_new = etaX_old{j}(Xind{j}).*xiX_new;
        xiZ_new = xiZ_old{j} + xi_sd*randn(dZ{j},1);
        betaZ_new = etaZ_old{j}(Zind{j}).*xiZ_new;
        ximu_new = ximu_old(j) + xi_sd*randn(1);
        betamu_new = etamu_old(j).*ximu_new;
        regressor_new(:,j) = u(:,j).*threshold(betamu_new*inte+x{j}*betax_new+X{j}*betaX_new+Z{j}*betaZ_new,t_old);
        ll_new = loglike(y,regressor_new,sigma_old,family);
        lr = ll_new-ll_old-.5*(sum(sum((xix_new-mx_old{j}).^2))+sum(sum((xiX_new-mX_old{j}).^2))+sum(sum((xiZ_new-mZ_old{j}).^2))+sum((ximu_new-mmu_old(j)).^2))...
            +.5*(sum(sum((xix_old{j}-mx_old{j}).^2))+sum(sum((xiX_old{j}-mX_old{j}).^2))+sum(sum((xiZ_old{j}-mZ_old{j}).^2))+sum((ximu_old(j)-mmu_old(j)).^2));
        if lr > log(rand(1))
            ac_xi = ac_xi+1;
            ll_old=ll_new;
            xix_old{j} = xix_new;
            betax_old{j} = betax_new;
            xiX_old{j} = xiX_new;
            betaX_old{j} = betaX_new;
            xiZ_old{j} = xiZ_new;
            betaZ_old{j} = betaZ_new;
            ximu_old(j) = ximu_new;
            betamu_old(j) = betamu_new;
            regressor_old(:,j) = regressor_new(:,j);
        end
    end
    
    
    %rescale eta and xi
    for j =1:p
    for i = 1:nq(j)
        xibar=abs(xix_old{j}(i));
        etax_old{j}(i) = etax_old{j}(i).*xibar;
        xix_old{j}(i) = xix_old{j}(i)./xibar;
        xibar=mean(abs(xiX_old{j}(Xind{j}==i)),1);
        etaX_old{j}(i) = etaX_old{j}(i).*xibar;
        xiX_old{j}(Xind{j}==i) = xiX_old{j}(Xind{j}==i)./repmat(xibar,[sum(Xind{j}==i),1]);
    end
    for i = 1:nr(j)
        xibar=mean(abs(xiZ_old{j}(Zind{j}==i)),1);
        etaZ_old{j}(i) = etaZ_old{j}(i).*xibar;
        xiZ_old{j}(Zind{j}==i) = xiZ_old{j}(Zind{j}==i)./repmat(xibar,[sum(Zind{j}==i),1]);
    end
    end
    etamu_old = etamu_old.*abs(ximu_old);
    ximu_old = ximu_old./abs(ximu_old);
    
    
    %update t
    t_new = rtnorm(t_old,t_sd,a_t,b_t);
    for j = 1:p
        regressor_new(:,j) = u(:,j).*threshold(betamu_old(j)*inte+x{j}*betax_old{j}+X{j}*betaX_old{j}+Z{j}*betaZ_old{j},t_new);
    end
    ll_new = loglike(y,regressor_new,sigma_old,family);
    lr = ll_new-ll_old + log(dtnorm(t_old,t_new,t_sd,a_t,b_t)) - log(dtnorm(t_new,t_old,t_sd,a_t,b_t));
    if lr>log(rand(1))
        ac_t = ac_t + 1;
        t_old = t_new;
        regressor_old = regressor_new;
        ll_old=ll_new;
    end
    
    %update tau
    for j =1:p
        taux_old{j}=1./gamrnd(a_tau+.5,1./(b_tau+etax_old{j}.^2./gammax_old{j}/2));
        tauX_old{j}=1./gamrnd(a_tau+.5,1./(b_tau+etaX_old{j}.^2./gammaX_old{j}/2));
        tauZ_old{j}=1./gamrnd(a_tau+.5,1./(b_tau+etaZ_old{j}.^2./gammaZ_old{j}/2));
    end
    taumu_old=1./gamrnd(a_tau+.5,1./(b_tau+etamu_old.^2./gammamu_old/2));
    
    
    %update sigma
    if family=='n'
        sse = -(ll_old+.5*log(sigma_old))*2*sigma_old;
        sigma_old = 1/gamrnd(a+n/2,1/(b+sse/2));
        ll_old = -sse/2/sigma_old-.5*log(sigma_old);
    elseif family=='w'
        mm = log(sigma_old^2/sqrt(sigma_var+sigma_old^2));
        vv = sqrt(log(sigma_var/sigma_old^2+1));
        sigma_new = lognrnd(mm,vv);
        mm2 = log(sigma_new^2/sqrt(sigma_var+sigma_new^2));
        vv2 = sqrt(log(sigma_var/sigma_new^2+1));
        ll_new = loglike(y,regressor_old,sigma_new,family);
        lr = ll_new-ll_old + log(gampdf(sigma_new,a,1/b)) - log(gampdf(sigma_old,a,1/b))-log(lognpdf(sigma_new,mm,vv))+log(lognpdf(sigma_old,mm2,vv2)) ;
        if lr>log(rand(1))
            ac_sigma = ac_sigma + 1;
            sigma_old = sigma_new;
            ll_old=ll_new;
        end
    elseif family=='l'        
        mm = log(sigma_old^2/sqrt(sigma_var+sigma_old^2));
        vv = sqrt(log(sigma_var/sigma_old^2+1));
        sigma_new = lognrnd(mm,vv);
        mm2 = log(sigma_new^2/sqrt(sigma_var+sigma_new^2));
        vv2 = sqrt(log(sigma_var/sigma_new^2+1));
        ll_new = loglike(y,regressor_old,sigma_new,family);
        lr = ll_new-ll_old + log(gampdf(1/sigma_new,a,1/b)) - log(gampdf(1/sigma_old,a,1/b))-log(lognpdf(sigma_new,mm,vv))+log(lognpdf(sigma_old,mm2,vv2)) ;
        if lr>log(rand(1))
            ac_sigma = ac_sigma + 1;
            sigma_old = sigma_new;
            ll_old=ll_new;
        end
    end
    
    %update gammma
    aw = a_w;
    bw = b_w;
    for j = 1:p
        ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etax_old{j}.^2/2/s0./taux_old{j});
        gammax_old{j}=binornd(1,ptmp./(1+ptmp));
        gammax_old{j}(ptmp==Inf)=1;
        gammax_old{j}(gammax_old{j}==0)=s0;
        ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etaX_old{j}.^2/2/s0./tauX_old{j});
        gammaX_old{j}=binornd(1,ptmp./(1+ptmp));
        gammaX_old{j}(ptmp==Inf)=1;
        gammaX_old{j}(gammaX_old{j}==0)=s0;
        ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etaZ_old{j}.^2/2/s0./tauZ_old{j});
        gammaZ_old{j}=binornd(1,ptmp./(1+ptmp));
        gammaZ_old{j}(ptmp==Inf)=1;
        gammaZ_old{j}(gammaZ_old{j}==0)=s0;
        ngamma=sum(gammax_old{j}==1)+sum(gammaX_old{j}==1)+sum(gammaZ_old{j}==1);
        aw = aw+ngamma;
        bw = bw+2*nq(j)+nr(j)-ngamma;
    end
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etamu_old.^2/2/s0./taumu_old);
    gammamu_old=binornd(1,ptmp./(1+ptmp));
    gammamu_old(ptmp==Inf)=1;
    gammamu_old(gammamu_old==0)=s0;
    ngamma = sum(gammamu_old==1);
    aw = aw+ngamma;
    bw = bw+p-ngamma;
    %update omega
    omega_old = betarnd(aw,bw);
    
    
    if mod(mc,2000)==0
        fprintf('%d steps finished\n',mc)
        fprintf('%d steps to go\n',N-mc)
    end
    
    if mod(mc,500)==0&&mc<=burnin
        ac_eta_mornitor = ac_eta/(mc-1)/(2*sum(nq)+sum(nr)+p);
        ac_xi_mornitor = ac_xi/(mc-1)/p;
        ac_t_mornitor = ac_t/(mc-1);
        ac_sigma_mornitor=ac_sigma/(mc-1);
        if ac_eta_mornitor>.5&&eta_iter<9
            eta_iter=eta_iter+1;
            eta_sd=eta_sd_vec(eta_iter);
        elseif ac_eta_mornitor<.2&&eta_iter>1
            eta_iter=eta_iter-1;
            eta_sd=eta_sd_vec(eta_iter);
        end
        if ac_xi_mornitor>.5&&xi_iter<9
            xi_iter=xi_iter+1;
            xi_sd=xi_sd_vec(xi_iter);
        elseif ac_xi_mornitor<.2&&xi_iter>1
            xi_iter=xi_iter-1;
            xi_sd=xi_sd_vec(xi_iter);
        end
        if ac_t_mornitor>.5&&t_iter<9
            t_iter=t_iter+1;
            t_sd=t_sd_vec(t_iter);
        elseif ac_t_mornitor<.2&&t_iter>1
            t_iter=t_iter-1;
            t_sd=t_sd_vec(t_iter);
        end
        if ac_sigma_mornitor>.5&&sigma_iter<9
            sigma_iter=sigma_iter+1;
            sigma_var=sigma_var_vec(sigma_iter);
        elseif ac_sigma_mornitor<.2&&sigma_iter>1
            sigma_iter=sigma_iter-1;
            sigma_var=sigma_var_vec(sigma_iter);
        end        
    end
    
    %save samples every "thin" iterations
    if mod(mc,thin)==0&&mc>burnin
        iter = iter + 1;
        for j =1:p
            betax{j}(:,iter)=betax_old{j};
            betaX{j}(:,iter)=betaX_old{j};
            betaZ{j}(:,iter)=betaZ_old{j};
            v0(:,j,iter) = betamu_old(j)*(gammamu_old(j)==1)*inte+x{j}*(betax_old{j}.*(gammax_old{j}==1))+X{j}*(betaX_old{j}.*(gammaX_old{j}(Xind{j})==1))+Z{j}*(betaZ_old{j}.*(gammaZ_old{j}(Zind{j})==1));
            gammax{j}(:,iter)=gammax_old{j};
            gammaX{j}(:,iter)=gammaX_old{j};
            gammaZ{j}(:,iter)=gammaZ_old{j};
        end
        betamu(:,iter)=betamu_old;
        t(iter) = t_old;
        ll(iter) = ll_old;
        gammamu(:,iter)=gammamu_old;
        sigma(iter) = sigma_old;
        v(:,:,iter) = threshold(v0(:,:,iter),t_old);
    end
end
ntmp=0;
for j = 1:p
    ntmp=ntmp+sum(2*nq(j)+nr(j)+1);
end
ac_eta = ac_eta/(N-1)/(2*sum(nq)+sum(nr)+p);
ac_xi = ac_xi/(N-1)/p;
ac_t = ac_t/(N-1);
ac_sigma=ac_sigma/(N-1);

const = gammamu==1;
constrate = mean(const,2);
const_est = constrate>cutoff;

lin = cell(p,1);
nlin = cell(p,1);
ln = cell(p,1);
categ = cell(p,1);
linrate = cell(p,1);
nlinrate = cell(p,1);
lnrate = cell(p,1);
categrate = cell(p,1);
lin_est = cell(p,1);
nlin_est = cell(p,1);
ln_est = cell(p,1);
categ_est = cell(p,1);
for j = 1:p
    lin{j} = gammax{j}==1; %linear
    nlin{j} = gammaX{j}==1;%nonlinear
    ln{j} = gammax{j}==1|gammaX{j}==1;%linear or nonlinear
    categ{j} = gammaZ{j}==1;%categorical
    linrate{j} = mean(lin{j},2);
    nlinrate{j} = mean(nlin{j},2);
    lnrate{j} = mean(ln{j},2);
    categrate{j} = mean(categ{j},2);
    lin_est{j} = linrate{j}>cutoff;
    nlin_est{j} = nlinrate{j}>cutoff;
    ln_est{j} = lnrate{j}>cutoff;
    categ_est{j} = categrate{j}>cutoff;
end

urate = 0;%regression strucutre
for mc = 1:(N-burnin)/thin
    urate = urate+(v(:,:,mc)~=0);
end
urate = urate/((N-burnin)/thin);
%time2=toc;
