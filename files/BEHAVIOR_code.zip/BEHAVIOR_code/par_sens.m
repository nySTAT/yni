function par_sens(sens,b)
if isdeployed
    b = str2num(b);
end
if b==1
    parpool(17);
    parfor seed=1:17
        GVSM_sens(sens,seed)
    end
elseif b==2
    parpool(17);
    parfor seed=18:34
        GVSM_sens(sens,seed)
    end
else
    parpool(16)
    parfor seed=35:50
        GVSM_sens(sens,seed)
    end
end
