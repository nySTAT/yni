function [betamu_est,betamu_upper,betamu_lower,lppred,linkpred,ypred,const_est,urate,constrate,ac_eta,ac_xi,ac_sigma,betamu,const,sigma,eta_sd,xi_sd,sigma_var]=GSM_MCMC(y,u,ut,cutoff,N,thin,burnin,seed,family)
%%
%GVSM without external covariates (basically it's just AFT with variable
%selection)
%u_est: the structure of v_est, logical(v_est)

%proposal parameters
%tic;
eta_sd_vec = .1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
sigma_var_vec= .1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
xi_sd_vec=.1*[1/16,1/8,1/4,1/2,1,2,4,8,16];
rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end

[n,p]=size(u);

ximu_old = .1*randn(p,1);
etamu_old = .1*randn(p,1);
betamu = zeros(p,(N-burnin)/thin);
betamu_old = etamu_old.*ximu_old;
%parameter
a = 10^-4; b = 10^-4;%IG prior for sigma
a_tau = 5; b_tau = 100; %use (5,25) for real data (5,100) for simulation
s0 = 2.5*10^-4;
a_w = 1/2;b_w=1/2;


etamu_old = etamu_old.*abs(ximu_old);
ximu_old = ximu_old./abs(ximu_old);
sigma = ones((N-burnin)/thin,1);%sigma^2

gammamu = s0*ones(p,(N-burnin)/thin);
gammamu_old = gammamu(:,1);
v = zeros(n,p,(N-burnin)/thin);
v0 = zeros(n,p,(N-burnin)/thin);
ac_eta=0;
ac_xi =0;
ac_sigma=0;
eta_iter=5;
xi_iter=5;
sigma_iter=5;
eta_sd=eta_sd_vec(eta_iter);
xi_sd=xi_sd_vec(xi_iter);
sigma_var=sigma_var_vec(sigma_iter);
sigma_old = sigma(1);
taumu_old = ones(p,1);
omega_old = .2;
regressor_old=zeros(n,p);
for j = 1:p
    regressor_old(:,j) = u(:,j)*betamu_old(j);
end
%algorithm begins
%tic;
ll_old = loglike(y,regressor_old,sigma_old,family);
iter=0;
for mc = 2:N
    %update eta
    
    
    for j = 1:p
        regressor_new = regressor_old;
        etamu_new = etamu_old(j) + eta_sd*randn(1);
        betamu_new = etamu_new.*ximu_old(j);
        regressor_new(:,j) = u(:,j)*betamu_new;
        ll_new = loglike(y,regressor_new,sigma_old,family);
        lr = ll_new-ll_old-.5*(etamu_new.^2./gammamu_old(j)./taumu_old(j))...
            +.5*(etamu_old(j).^2./gammamu_old(j)./taumu_old(j));
        if lr > log(rand(1))
            ac_eta = ac_eta+1;
            ll_old=ll_new;
            etamu_old(j) = etamu_new;
            betamu_old(j) = betamu_new;
            regressor_old(:,j) = regressor_new(:,j);
        end
    end
    
    %update
    
    mmu_old=2*binornd(1,1./(1+exp(-2*ximu_old)))-1;
    
    
    %update xi
    for j = 1:p
        regressor_new = regressor_old;
        ximu_new = ximu_old(j) + xi_sd*randn(1);
        betamu_new = etamu_old(j).*ximu_new;
        regressor_new(:,j) = u(:,j)*betamu_new;
        ll_new = loglike(y,regressor_new,sigma_old,family);
        lr = ll_new-ll_old-.5*(sum((ximu_new-mmu_old(j)).^2))+.5*(sum((ximu_old(j)-mmu_old(j)).^2));
        if lr > log(rand(1))
            ac_xi = ac_xi+1;
            ll_old=ll_new;
            ximu_old(j) = ximu_new;
            betamu_old(j) = betamu_new;
            regressor_old(:,j) = regressor_new(:,j);
        end
    end
    
    
    %rescale eta and xi
    etamu_old = etamu_old.*abs(ximu_old);
    ximu_old = ximu_old./abs(ximu_old);
    
    
    
    %update tau
    taumu_old=1./gamrnd(a_tau+.5,1./(b_tau+etamu_old.^2./gammamu_old/2));
    
    
    %update sigma
    if family=='n'
        sse = -(ll_old+.5*log(sigma_old))*2*sigma_old;
        sigma_old = 1/gamrnd(a+n/2,1/(b+sse/2));
        ll_old = -sse/2/sigma_old-.5*log(sigma_old);
    elseif family=='w'
        mm = log(sigma_old^2/sqrt(sigma_var+sigma_old^2));
        vv = sqrt(log(sigma_var/sigma_old^2+1));
        sigma_new = lognrnd(mm,vv);
        mm2 = log(sigma_new^2/sqrt(sigma_var+sigma_new^2));
        vv2 = sqrt(log(sigma_var/sigma_new^2+1));
        ll_new = loglike(y,regressor_old,sigma_new,family);
        lr = ll_new-ll_old + log(gampdf(sigma_new,a,1/b)) - log(gampdf(sigma_old,a,1/b))-log(lognpdf(sigma_new,mm,vv))+log(lognpdf(sigma_old,mm2,vv2)) ;
        if lr>log(rand(1))
            ac_sigma = ac_sigma + 1;
            sigma_old = sigma_new;
            ll_old=ll_new;
        end
    elseif family=='l'
        mm = log(sigma_old^2/sqrt(sigma_var+sigma_old^2));
        vv = sqrt(log(sigma_var/sigma_old^2+1));
        sigma_new = lognrnd(mm,vv);
        mm2 = log(sigma_new^2/sqrt(sigma_var+sigma_new^2));
        vv2 = sqrt(log(sigma_var/sigma_new^2+1));
        ll_new = loglike(y,regressor_old,sigma_new,family);
        lr = ll_new-ll_old + log(gampdf(1/sigma_new,a,1/b)) - log(gampdf(1/sigma_old,a,1/b))-log(lognpdf(sigma_new,mm,vv))+log(lognpdf(sigma_old,mm2,vv2)) ;
        if lr>log(rand(1))
            ac_sigma = ac_sigma + 1;
            sigma_old = sigma_new;
            ll_old=ll_new;
        end
    end
    
    %update gammma
    aw = a_w;
    bw = b_w;
    
    ptmp=sqrt(s0)*omega_old/(1-omega_old)*exp((1-s0)*etamu_old.^2/2/s0./taumu_old);
    gammamu_old=binornd(1,ptmp./(1+ptmp));
    gammamu_old(ptmp==Inf)=1;
    gammamu_old(gammamu_old==0)=s0;
    ngamma = sum(gammamu_old==1);
    aw = aw+ngamma;
    bw = bw+p-ngamma;
    %update omega
    omega_old = betarnd(aw,bw);
    
    
    if mod(mc,2000)==0
        fprintf('%d steps finished\n',mc)
        fprintf('%d steps to go\n',N-mc)
    end
    
    if mod(mc,500)==0&&mc<=burnin
        ac_eta_mornitor = ac_eta/(mc-1)/p;
        ac_xi_mornitor = ac_xi/(mc-1)/p;
        ac_sigma_mornitor=ac_sigma/(mc-1);
        if ac_eta_mornitor>.5&&eta_iter<9
            eta_iter=eta_iter+1;
            eta_sd=eta_sd_vec(eta_iter);
        elseif ac_eta_mornitor<.2&&eta_iter>1
            eta_iter=eta_iter-1;
            eta_sd=eta_sd_vec(eta_iter);
        end
        if ac_xi_mornitor>.5&&xi_iter<9
            xi_iter=xi_iter+1;
            xi_sd=xi_sd_vec(xi_iter);
        elseif ac_xi_mornitor<.2&&xi_iter>1
            xi_iter=xi_iter-1;
            xi_sd=xi_sd_vec(xi_iter);
        end
        if ac_sigma_mornitor>.5&&sigma_iter<9
            sigma_iter=sigma_iter+1;
            sigma_var=sigma_var_vec(sigma_iter);
        elseif ac_sigma_mornitor<.2&&sigma_iter>1
            sigma_iter=sigma_iter-1;
            sigma_var=sigma_var_vec(sigma_iter);
        end
    end
    
    %save samples every "thin" iterations
    if mod(mc,thin)==0&&mc>burnin
        iter = iter + 1;
        for j =1:p
            v0(:,j,iter) = betamu_old(j)*(gammamu_old(j)==1);
        end
        betamu(:,iter)=betamu_old;
        gammamu(:,iter)=gammamu_old;
        sigma(iter) = sigma_old;
        v(:,:,iter) = v0(:,:,iter);
    end
end

ac_eta = ac_eta/(N-1)/p;
ac_xi = ac_xi/(N-1)/p;
ac_sigma=ac_sigma/(N-1);

const = gammamu==1;
constrate = mean(const,2);
const_est = constrate>cutoff;

urate = 0;%regression strucutre
for mc = 1:(N-burnin)/thin
    urate = urate+(v(:,:,mc)~=0);
end
urate = urate/((N-burnin)/thin);
%time2=toc;
betamu_est=mean(betamu,2);
betamu_sd=std(betamu,0,2);
betamu_upper=betamu_est+1.96*betamu_sd;
betamu_lower=betamu_est-1.96*betamu_sd;
sigma_est = mean(sigma);
nt = size(ut,1);
lppred=sum(ut.*repmat(betamu_est',[nt,1]),2);
if family=='n'
    ypred = lppred;
    linkpred = lppred;
elseif family=='b'
    linkpred=1./(1+exp(-lppred));
    ypred = linkpred>.5;%optimal classification rate prediction
elseif family=='p'
    linkpred = exp(lppred);
    ypred = linkpred;
elseif family=='w'
    linkpred = exp(lppred);
    ypred = gamma(1+sigma_est)./linkpred;
elseif family=='l'
    linkpred = exp(lppred);
    ypred = linkpred; %probably this is wrong (just copied from weibull)
end

