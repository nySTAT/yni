clear
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
np = length(pathway);
cor_u=zeros(4,12);
cor_const=zeros(4,12);
cor_lin=zeros(4,12);
cor_nlin=zeros(4,12);
RF_t=zeros(4,12);
RF_sigma=zeros(4,12);
RF_betax = cell(4,12);
RF_betaX = cell(4,12);
RF_betamu = cell(4,12);
RF_betax_med=zeros(4,12);
RF_betaX_med=zeros(4,12);
RF_betamu_med=zeros(4,12);
%nou1 = zeros(4,12);
%nou2 = zeros(4,12);
FDR=zeros(4,12);
npro=zeros(4,12);
cc=0;
ccc=0;
TIME=zeros(48,4);
for c = [12,19,24,10]
    cc=cc+1;
    for pa = 1:np
        ccc=ccc+1;
        ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
        utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
        xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
        y=[ytmp(:,2),ytmp(:,1)];
        matchsubject=(y(:,1)>30&all(xtmp>0,2));
        y=y(matchsubject,:);
        %y(:,1)=y(:,1)+.1;
        %hist(log(y(:,1)))
        utmp=utmp(matchsubject,:);
        utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
        xtmp=log(xtmp(matchsubject,:));
        family='w';
        [n,p]=size(utmp);
        u=ones(n,1);
        u(:,2)=stdize(utmp(:,1));
        x=cell(1);
        x{1}=double.empty(n,0);
        x{2}=stdize(xtmp(:,1));
        z=cell(1,p);
        z{1}=double.empty(n,0);
        z{2}=double.empty(n,0);
        j=2;
        jj=2;
        while j<=p
            if ~all(utmp(:,j)==utmp(:,j-1))
                u=[u,stdize(utmp(:,j))];
                jj=jj+1;
                x{jj}=stdize(xtmp(:,j));
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
                z{jj}=double.empty(n,0);
            else
                x{jj}=[x{jj},stdize(xtmp(:,j))];
                if any(isnan(x{jj}))
                    x{jj}=double.empty(n,0);
                end
            end
            j=j+1;
        end
        p=size(u,2);
        N = 200000*2.5; %number of iterations
        
        %seed=1
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
        u_est1 = u_est;
        constrate1=constrate;
        urate1 = urate;
        linrate1 = linrate;
        nlinrate1 = nlinrate;
        lnrate1 = lnrate;
        betax1 = betax;
        betaX1 = betaX;
        betamu1 = betamu;
        t1=t;
        sigma1=sigma;
        ll1=ll;
        TIME(ccc,1)=time;
        %seed=2
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,2))
        u_est2 = u_est;
        constrate2=constrate;
        urate2 = urate;
        linrate2 = linrate;
        nlinrate2 = nlinrate;
        lnrate2 = lnrate;
        betax2 = betax;
        betaX2 = betaX;
        betamu2 = betamu;
        t2=t;
        sigma2=sigma;
        ll2=ll;
        TIME(ccc,2)=time;
        %seed=3
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,3))
        u_est3 = u_est;
        constrate3=constrate;
        urate3 = urate;
        linrate3 = linrate;
        nlinrate3 = nlinrate;
        lnrate3 = lnrate;
        betax3 = betax;
        betaX3 = betaX;
        betamu3 = betamu;
        t3=t;
        sigma3=sigma;
        ll3=ll;
        TIME(ccc,3)=time;
        %seed=4
        load(sprintf('/Users/yangn/Box Sync/Pancancer_4/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,4))
        u_est4 = u_est;
        constrate4=constrate;
        urate4 = urate;
        linrate4 = linrate;
        nlinrate4 = nlinrate;
        lnrate4 = lnrate;
        betax4 = betax;
        betaX4 = betaX;
        betamu4 = betamu;
        t4=t;
        sigma4=sigma;
        ll4=ll;
        TIME(ccc,4)=time;
%         RF_t(cc,pa)=psrf(t1,t2,t3,t4);
%         RF_sigma(cc,pa)= psrf(sigma1,sigma2,sigma3,sigma4);
%         for i = 2:length(betax1)
%             [I,~]=size(betax1{i});
%             for ii = 1:I
%                 RF_betax{cc,pa}=[RF_betax{cc,pa},psrf(betax1{i}(ii,:)',betax2{i}(ii,:)',betax3{i}(ii,:)',betax4{i}(ii,:)')];
%             end
%         end
%         RF_betax_med(cc,pa)=median(RF_betax{cc,pa});
%         for i = 2:length(betaX1)
%             [I,~]=size(betaX1{i});
%             for ii = 1:I
%                 RF_betaX{cc,pa}=[RF_betaX{cc,pa},psrf(betaX1{i}(ii,:)',betaX2{i}(ii,:)',betaX3{i}(ii,:)',betaX4{i}(ii,:)')];
%             end
%         end
%         RF_betaX_med(cc,pa)=median(RF_betaX{cc,pa});
%         [I,~]=size(betamu1);
%         for ii = 1:I
%             RF_betamu{cc,pa}=[RF_betamu{cc,pa},psrf(betamu1(ii,:)',betamu2(ii,:)',betamu3(ii,:)',betamu4(ii,:)')];
%         end
%         RF_betamu_med(cc,pa)=median(RF_betamu{cc,pa});
%         
%         
%         
%         %urate = (urate_post1+urate_post2)/2;
%         %linrate = (linrate1+linrate2)/2;
%         %nlinrate = (nlinrate1+nlinrate2)/2;
%         %lnrate = (lnrate1+lnrate2)/2;
%         %categrate = (categrate1+categrate2)/2;
%         
%         triu_ind=true(4);
%         triu_ind=triu(triu_ind,1);
%         cor=corr([urate1(:),urate2(:),urate3(:),urate4(:)]);
%         cor_u(cc,pa) = median(cor(triu_ind));
%         cor=corr([constrate1(:),constrate2(:),constrate3(:),constrate4(:)]);
%         cor_const(cc,pa) = median(cor(triu_ind));
% %         
%         linrate_1=[];
%         linrate_2=[];
%         linrate_3=[];
%         linrate_4=[];
%         nlinrate_1=[];
%         nlinrate_2=[];
%         nlinrate_3=[];
%         nlinrate_4=[];
%         for i =1:length(linrate1)
%             linrate_1=[linrate_1;linrate1{i}];
%             linrate_2=[linrate_2;linrate2{i}];
%             linrate_3=[linrate_3;linrate3{i}];
%             linrate_4=[linrate_4;linrate4{i}];
%             nlinrate_1=[nlinrate_1;nlinrate1{i}];
%             nlinrate_2=[nlinrate_2;nlinrate2{i}];
%             nlinrate_3=[nlinrate_3;nlinrate3{i}];
%             nlinrate_4=[nlinrate_4;nlinrate4{i}];
%         end
%         cor=corr([linrate_1(:),linrate_2(:),linrate_3(:),linrate_4(:)]);
%         cor_lin(cc,pa) = median(cor(triu_ind));
%         cor=corr([nlinrate_1(:),nlinrate_2(:),nlinrate_3(:),nlinrate_4(:)]);
%         cor_nlin(cc,pa) = median(cor(triu_ind));
        %         cor_ln = corr(lnrate1(:),lnrate2(:));
        %         ln_est=lin_est|nlin_est;
        %nou1(cc,pa)=sum(sum(u_est1(:,2:end)))/n/(p-1);
        %nou2(cc,pa)=sum(sum(u_est2(:,2:end)))/n/(p-1);
        
        %%%%%%only one of the plotting code blocks can be run at a time%%%%%
        
                %trace plots of loglikelihood
%                 subplot(4,12,ccc)
%                 s=plot(ll1);
%                 s.Color(4) = 0.1;
%                 hold on
%                 s=plot(ll2);
%                 %hold off
%                 s.Color(4) = 0.1;
%                 s=plot(ll3);
%                 s.Color(4) = 0.1;
%                 s=plot(ll4);
%                 s.Color(4) = 0.1;
%                 xlim([0,length(ll1)])
%                 hold off
%                 if c==12
%                     title(pathway{pa},'FontSize', 15,'FontWeight','bold')
%                 end
%                 if pa==1
%                     ylabel(cancertype{c},'FontSize', 15,'FontWeight','bold')
%                 end
        
        %trace plots of different parameters for one cancer one pathway
%                 if c==12&&pa==5
%                     figure;
%                     subplot(3,4,1)
%                     s=plot(t1);
%                     s.Color(4) = 0.1;
%                     hold on
%                     s=plot(t2);
%                     s.Color(4) = 0.1;  
%                     s=plot(t3);
%                     s.Color(4) = 0.1;  
%                     s=plot(t4);
%                     s.Color(4) = 0.1;  
%                     xlim([0,length(t1)])
%                     hold off
% 
%                     ylabel('Threshold','FontSize', 15,'FontWeight','bold')
%                     for i = 1:11
%                         subplot(3,4,i+1)
%                         s=plot(betamu1(i,:));
%                         s.Color(4) = 0.1;
%                         hold on
%                         s=plot(betamu2(i,:));
%                         s.Color(4) = 0.1;
%                         s=plot(betamu3(i,:));
%                         s.Color(4) = 0.1;
%                         s=plot(betamu4(i,:));
%                         s.Color(4) = 0.1;
%                         xlim([0,length(betamu1(i,:))])
%                         hold off
%                         ylabel('Constant','FontSize', 15,'FontWeight','bold')
%                     end
%                     figure;
%                     for i = 1:10
%                         subplot(7,10,i)
%                         s=plot(betax1{i+1});
%                         s.Color(4) = 0.1;
%                         hold on
%                         s=plot(betax2{i+1});
%                         s.Color(4) = 0.1;
%                         s=plot(betax3{i+1});
%                         s.Color(4) = 0.1;
%                         s=plot(betax4{i+1});
%                         s.Color(4) = 0.1;
%                         xlim([0,length(betax1{i+1})])
%                         hold off
%                         ylabel('Linear','FontSize', 15,'FontWeight','bold')
%                     end
%                     ccc=10;
%                     for i = 1:10
%                         for j = 1:6
%                             ccc=ccc+1;
%                             subplot(7,10,ccc)
%                             s=plot(betaX1{i+1}(j,:));
%                             s.Color(4) = 0.1;
%                             hold on
%                             s=plot(betaX2{i+1}(j,:));
%                             s.Color(4) = 0.1;
%                             s=plot(betaX3{i+1}(j,:));
%                             s.Color(4) = 0.1;
%                             s=plot(betaX4{i+1}(j,:));
%                             s.Color(4) = 0.1;
%                             xlim([0,length(betaX1{i+1}(j,:))])
%                             hold off
%                             ylabel('Nonlinear','FontSize', 15,'FontWeight','bold')
%                         end
%                     end
%                 end
%         
%         
%         
        %plots of PPI
%         subplot(4,12,ccc)
%         plot([urate3(:);constrate3(:);linrate_3(:);nlinrate_3(:)],[urate4(:);constrate4(:);linrate_4(:);nlinrate_4(:)],'o');
%         hold on
%         plot([0,1],[0,1],'-r')
%         hold off
%         %xlim([0,length(ll1)])
%         if c==12
%             title(pathway{pa},'FontSize', 15,'FontWeight','bold')
%         end
%         if pa==1
%             ylabel(cancertype{c},'FontSize', 15,'FontWeight','bold')
%         end
% 
%         %expected FDR for protein selection
%         N = 200000*5; %number of iterations
%         load(sprintf('/Users/yangn/Box Sync/Pancancer_4/%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,1))
%         FDR(cc,pa)=sum(sum((1-urate_post(:,2:end)).*u_est(:,2:end)))/sum(sum(u_est(:,2:end)));
%         npro(cc,pa)=sum(sum(u_est(:,2:end)));
    end
end
[median(cor_const(:)),median(cor_lin(:)),median(cor_nlin(:)),median(cor_u(:))]
% [median(median(RF_t)),median(median(RF_sigma)),median(median(RF_betamu_med)),median(median(RF_betax_med)),median(median(RF_betaX_med))]
