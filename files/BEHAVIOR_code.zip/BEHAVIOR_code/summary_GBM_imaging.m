clear
%load seed1
p=19;
q=18;
N=200000;
load(sprintf('/Users/yangn/Box Sync/GBM_imaging_results/GBM_imaging_p%d_q%d_mc%d_seed%d.mat',p,q,N,1))
u_est1 = u_est;
constrate1=constrate;
urate1 = urate;
linrate1 = linrate;
nlinrate1 = nlinrate;
lnrate1 = lnrate;
betax1 = betax;
betaX1 = betaX;
betamu1 = betamu;
t1=t;
sigma1=sigma;


%load seed2
load(sprintf('/Users/yangn/Box Sync/GBM_imaging_results/GBM_imaging_p%d_q%d_mc%d_seed%d.mat',p-1,q,N,2))

u_est2 = u_est;
constrate2=constrate;
urate2 = urate;
linrate2 = linrate;
nlinrate2 = nlinrate;
lnrate2 = lnrate;
betax2 = betax;
betaX2 = betaX;
betamu2 = betamu;
t2=t;
sigma2=sigma;


%%
%convergence check
r=48;
RF_t = nan(r,1); %Gelman-Rubin potential scale reduction factor
RF_sigma=nan(r,1);
for j = 1:r-1
    RF_t(j)= psrf(t1(:,j),t2(:,j));
    RF_sigma(j)= psrf(sigma1(:,j),sigma2(:,j));
end
RF_t=psrf(t1,t2);
RF_sigma= psrf(sigma1,sigma2);

RF_betax = [];%cell(r-1,1); %Gelman-Rubin potential scale reduction factor
    [I,J,K]=size(betax1);
    RF_betax_tmp = nan(I,J);
    for i = 1:I
        for j = 1:J
            betax_1 = squeeze(betax1(i,j,:));
            betax_2 = squeeze(betax2(i,j,:));
            betax_1 = betax_1(logical(betax_1));
            betax_2 = betax_2(logical(betax_2));
            n1 = length(betax_1);
            n2 = length(betax_2);
            if n1 < n2
                i = randsample(n2,n1);
                betax_2 = betax_2(i);
            elseif n1 > n2
                i = randsample(n1,n2);
                betax_1 = betax_1(i);
            end
            if (n1>1 && n2>1)
                RF_betax_tmp(i,j) = psrf(betax_1,betax_2);
            end
        end
    end
    RF_betax=[RF_betax;RF_betax_tmp(:)];
RF_betaX = [];%cell(r-1,1); %Gelman-Rubin potential scale reduction factor
    [I,J,K]=size(betaX1);
    RF_betaX_tmp = nan(I,J);
    for i = 1:I
        for j = 1:J
            betaX_1 = squeeze(betaX1(i,j,:));
            betaX_2 = squeeze(betaX2(i,j,:));
            betaX_1 = betaX_1(logical(betaX_1));
            betaX_2 = betaX_2(logical(betaX_2));
            n1 = length(betaX_1);
            n2 = length(betaX_2);
            if n1 < n2
                i = randsample(n2,n1);
                betaX_2 = betaX_2(i);
            elseif n1 > n2
                i = randsample(n1,n2);
                betaX_1 = betaX_1(i);
            end
            if (n1>1 && n2>1)
                RF_betaX_tmp(i,j) = psrf(betaX_1,betaX_2);
            end
        end
    end
    RF_betaX=[RF_betaX;RF_betaX_tmp(:)];

    [I,K]=size(betamu1);
    RF_betamu = nan(I,1);
    for i = 1:I
            betamu_1 = squeeze(betamu1(i,:));
            betamu_2 = squeeze(betamu2(i,:));
            betamu_1 = betamu_1(logical(betamu_1));
            betamu_2 = betamu_2(logical(betamu_2));
            n1 = length(betamu_1);
            n2 = length(betamu_2);
            if n1 < n2
                i = randsample(n2,n1);
                betamu_2 = betamu_2(i);
            elseif n1 > n2
                i = randsample(n1,n2);
                betamu_1 = betamu_1(i);
            end
            if (n1>1 && n2>1)
                RF_betamu(i) = psrf(betamu_1',betamu_2');
            end
    end


urate = (urate_post1+urate_post2)/2;
linrate = (linrate1+linrate2)/2;
nlinrate = (nlinrate1+nlinrate2)/2;
lnrate = (lnrate1+lnrate2)/2;
categrate = (categrate1+categrate2)/2;

cor_u = corr(urate1(:),urate2(:));
cor_lin = corr(linrate1(:),linrate2(:));
cor_nlin = corr(nlinrate1(:),nlinrate2(:));
cor_ln = corr(lnrate1(:),lnrate2(:));
cor_const = corr(constrate1(:),constrate2(:));
ln_est=lin_est|nlin_est;


%cor_categ = corr(categrate1(:),categrate2(:));
u_est = u_est1&u_est2;
tmp=mean(u_est,1)>0.2; %only look at selection of covariates for which edge is included more than 30% of the samples
tmp=tmp([1,1],:,:);
cor_ln = corr(lnrate1(tmp),lnrate2(tmp));
cor_lin = corr(linrate1(tmp),linrate2(tmp));
cor_nlin = corr(nlinrate1(tmp),nlinrate2(tmp));
cor_const = corr(constrate1(tmp(1,:,:)),constrate2(tmp(1,:,:)));


[cor_u,cor_lin,cor_nlin,cor_const]
quantile(RF_betamu,[0,0.95])
quantile(RF_betax,[0,0.95])
quantile(RF_betaX,[0,0.95])
quantile(RF_t,[0,0.95])
quantile(RF_sigma,[0,0.95])

%tmp=squeeze(betaX1{5}(1,15,:));
tmp=squeeze(betax1{17}(2,30,:));
plot(tmp(abs(tmp)>0))
xlim([0,length(tmp(abs(tmp)>0))])
%ylabel('AUC','FontSize', 20,'FontWeight','bold')
set(gca,'XTickLabel',{})
set(gca,'YTickLabel',{})
xlabel('Iterations','FontSize', 20,'FontWeight','bold')





%%
%one single chain
clear
%urate to be replaced by urate_post
%load seed1
load('/Users/yangn/Box Sync/MMCR/MMCR_cont_mc1000000_seed1.mat')
vv_est=v0_est.*(abs(v0_est)>repmat(repmat(t_est',n,1),1,1,p));
[I,J,K]=ind2sub(size(ln_est),find(ln_est));
inds = [I,J,K];
%varying edges
[name(J),name(K)]

nfr = length(I);
%1. functional reconstruction
%some plots may look funky. reasons may include thresholding or lin|nlin 
%pick 9 in the paper
% for h = 1:nfr
%     i=I(h);
%     j=J(h);
%     k=K(h);
%     xtmp = x(:,i);
%     xtmp2 = xtmp-mean(xtmp);
%     xtmp2 = xtmp2/norm(xtmp2,'fro');
%     ytmp = v0_est(:,j,k);
%     ytmpu = v0_upper(:,j,k);
%     ytmpl = v0_lower(:,j,k);
%     [xtmp,ind] = sort(xtmp);
%     xtmp2 = xtmp2(ind);
%     ytmp = ytmp(ind);
%     ytmpu = ytmpu(ind);
%     ytmpl = ytmpl(ind);
%     plot(xtmp,ytmp,'-')
%     hold on
%     plot(xtmp,ytmpu,'--')
%     plot(xtmp,ytmpl,'--')
%     hold off
%     if i==1
%         xlabel('Serum beta-2 microglobulin','FontSize', 30,'FontWeight','bold');
%     else
%         xlabel('Serum albumin','FontSize', 30,'FontWeight','bold');
%     end
%     ylabel([name{j},' / ',name{k}],'FontSize', 30,'FontWeight','bold');
%     xlim([min(xtmp),max(xtmp)])
%     %title(['p=',num2str(round2(gamma_rate(i,j),.001)),', N=',num2str(round2(phi_rate(i,j),.001))],'FontSize',30,'FontWeight','bold')            
%     %title(['p=',num2str(round2(gamma_rate(i,j),.001))],'FontSize',30,'FontWeight','bold'
%     set(gca,'Fontsize',20)
%     figure;
% end
% %2. posterior vs additional covariates
% for h = 1:nfr
%     i=I(h);
%     j=J(h);
%     k=K(h);
%     xtmp = x(:,i);
%     xtmp2 = xtmp-mean(xtmp);
%     xtmp2 = xtmp2/norm(xtmp2,'fro');
%     ytmp = urate_post(:,j,k);
%     %ytmp = v_est(:,j,k)>t_est(j);
%     [xtmp,ind] = sort(xtmp);
%     xtmp2 = xtmp2(ind);
%     ytmp = ytmp(ind);
%     %plot(xtmp,ytmp.*(ytmp>.5),'o')
%     plot(xtmp,ytmp,'-')
%     if i==1
%         xlabel('Serum beta-2 microglobulin','FontSize', 30,'FontWeight','bold');
%     else
%         xlabel('Serum albumin','FontSize', 30,'FontWeight','bold');
%     end
%     ylabel([name{j},' / ',name{k}],'FontSize', 30,'FontWeight','bold');
%     xlim([min(xtmp),max(xtmp)])
%     %title(['p=',num2str(round2(gamma_rate(i,j),.001)),', N=',num2str(round2(phi_rate(i,j),.001))],'FontSize',30,'FontWeight','bold')            
%     %title(['p=',num2str(round2(gamma_rate(i,j),.001))],'FontSize',30,'FontWeight','bold'
%     set(gca,'Fontsize',20)
%     figure;
% end
% %1&2 top and bottom
% for h = 1:nfr
%     i=I(h);
%     j=J(h);
%     k=K(h);
%     xtmp = x(:,i);
%     xtmp2 = xtmp-mean(xtmp);
%     xtmp2 = xtmp2/norm(xtmp2,'fro');
%     ytmp = v0_est(:,j,k);
%     ytmpu = v0_upper(:,j,k);
%     ytmpl = v0_lower(:,j,k);
%     [xtmp,ind] = sort(xtmp);
%     xtmp2 = xtmp2(ind);
%     ytmp = ytmp(ind);
%     ytmpu = ytmpu(ind);
%     ytmpl = ytmpl(ind);
%     figure;%('Position',[0 0 2000 2000])
%     ha = tight_subplot(2,1,0,.17,.08);    
%     %subplot(2,1,1)
%     axes(ha(1))
%     plot(xtmp,ytmp,'-')
%     hold on
%     plot(xtmp,ytmpu,'--')
%     plot(xtmp,ytmpl,'--')
%     hold off
%     title([name{k},' \rightarrow ',name{j}],'FontSize', 100,'FontWeight','bold')
%     %ylabel([name{j},' / ',name{k}],'FontSize', 100,'FontWeight','bold');
%     ylabel('Functional','FontSize', 100,'FontWeight','bold')
%     xlim([min(xtmp),max(xtmp)])
%     set(gca, 'XTick', []);
%     a = gca;
%     % set box property to off and remove background color
%     set(a,'box','off','color','none')
%     % create new, empty axes with box but without ticks
%     b = axes('Position',get(a,'Position'),'box','on','xtick',[],'ytick',[]);
%     % set original axes as active
%     axes(a)
%     % link axes in case of zooming
%     linkaxes([a b])
%     %title(['p=',num2str(round2(gamma_rate(i,j),.001)),', N=',num2str(round2(phi_rate(i,j),.001))],'FontSize',100,'FontWeight','bold')            
%     %title(['p=',num2str(round2(gamma_rate(i,j),.001))],'FontSize',100,'FontWeight','bold'
%     set(gca,'Fontsize',100)
%     ytmp = urate_post(:,j,k);
%     %ytmp = v_est(:,j,k)>t_est(j);
%     ytmp = ytmp(ind);
%     %plot(xtmp,ytmp.*(ytmp>.5),'o')
%     %subplot(2,1,2)
%     axes(ha(2))
%     plot(xtmp+.01*randn(length(xtmp),1),ytmp,'.','MarkerSize',100)
%     if i==1
%         xlabel('Serum beta-2 microglobulin','FontSize', 100,'FontWeight','bold');
%     else
%         xlabel('Serum albumin','FontSize', 100,'FontWeight','bold');
%     end
%     %ylabel([name{j},' / ',name{k}],'FontSize', 100,'FontWeight','bold');
%     ylabel('Probabilities','FontSize', 100,'FontWeight','bold')
%     xlim([min(xtmp),max(xtmp)])
%     a = gca;
%     % set box property to off and remove background color
%     set(a,'box','off','color','none')
%     % create new, empty axes with box but without ticks
%     b = axes('Position',get(a,'Position'),'box','on','xtick',[],'ytick',[]);
%     % set original axes as active
%     axes(a)
%     % link axes in case of zooming
%     linkaxes([a b])
%     %title(['p=',num2str(round2(gamma_rate(i,j),.001)),', N=',num2str(round2(phi_rate(i,j),.001))],'FontSize',100,'FontWeight','bold')            
%     %title(['p=',num2str(round2(gamma_rate(i,j),.001))],'FontSize',100,'FontWeight','bold'
%     set(gca,'Fontsize',100)
%     print( ['/Users/yangn/Dropbox/Research/projects/CDG/Yang Covariate-dependent network report/plots/',name{j},'_',name{k},'_double'],'-deps')
% 
% end
% %1&2
% for h = 1:nfr
%     i=I(h);
%     j=J(h);
%     k=K(h);
%     xtmp = x(:,i);
%     xtmp2 = xtmp-mean(xtmp);
%     xtmp2 = xtmp2/norm(xtmp2,'fro');
%     ytmp = v0_est(:,j,k);
%     ytmpu = v0_upper(:,j,k);
%     ytmpl = v0_lower(:,j,k);
%     [xtmp,ind] = sort(xtmp);
%     xtmp2 = xtmp2(ind);
%     ytmp = ytmp(ind);
%     ytmpu = ytmpu(ind);
%     ytmpl = ytmpl(ind);
%     
%     ytmp2 = urate_post(:,j,k);
%     %ytmp2= v_est(:,j,k)>t_est(j);
%     ytmp2 = ytmp2(ind);
%     %ytmp2 = ytmp2.*(ytmp2>0.5);
%     
%     xtmp2=xtmp;
%     
%     [AX,H1,H2]=plotyy(xtmp2,ytmp,xtmp2,ytmp2,'plot','stem');
%     axes(AX(1))
%     hold on
%     %plot(xtmp2,ytmp,'-')
%     plot(xtmp2,ytmpu,'--')
%     plot(xtmp2,ytmpl,'--')
%     plot([xtmp2(1),xtmp2(end)],[t_est(j),t_est(j)],'-r')
%     plot([xtmp2(1),xtmp2(end)],[-t_est(j),-t_est(j)],'-r')
% 
%     axes(AX(2))
%     hold on
%     %stem(xtmp2,ytmp2)
%     figure;
% end

%3. movies and plots made in r 
urate_vec = urate_post(:);
v0_est_vec = v0_est(:);
v0_upper_vec = v0_upper(:);
v0_lower_vec = v0_lower(:);
urate_pred_vec = u_pred_rate(:);
v0_pred_vec = v0_pred(:);
v0_pred_upper_vec = v0_pred_upper(:);
v0_pred_lower_vec = v0_pred_lower(:);
inds = inds([1:6,9:nfr],:);%7,8 are excluded because their resulting curves are thresholded out
save('/Users/yangn/Box Sync/MMCR/urate.txt','urate_vec','-ascii')
save('/Users/yangn/Box Sync/MMCR/v0_est.txt','v0_est_vec','-ascii')
save('/Users/yangn/Box Sync/MMCR/v0_upper.txt','v0_upper_vec','-ascii')
save('/Users/yangn/Box Sync/MMCR/v0_lower.txt','v0_lower_vec','-ascii')
save('/Users/yangn/Box Sync/MMCR/inds.txt','inds','-ascii')
save('/Users/yangn/Box Sync/MMCR/u_pred_rate.txt','urate_pred_vec','-ascii')
save('/Users/yangn/Box Sync/MMCR/v0_pred.txt','v0_pred_vec','-ascii')
save('/Users/yangn/Box Sync/MMCR/v0_pred_upper.txt','v0_pred_upper_vec','-ascii')
save('/Users/yangn/Box Sync/MMCR/v0_pred_lower.txt','v0_pred_lower_vec','-ascii')
save('/Users/yangn/Box Sync/MMCR/xt.txt','xt','-ascii')

%4 cytoscapte
urate_tmp=squeeze(mean(urate,1));%not use urate_post b/c all probabilities close to 1
vest_tmp=(squeeze(mean(v_est,1))<0)+0;
for i =1:length(inds)
    urate_tmp(inds(i,2),inds(i,3))=2;
    vest_tmp(inds(i,2),inds(i,3))=0;    
end
utmp=squeeze(logical(sum(u_est,1)));
ind=find(utmp);
[I,J]=ind2sub(size(utmp),ind);
tbo = cell(length(I),4);
tbo(:,1) = name(J);
tbo(:,2) = name(I);
tbo(:,3) = num2cell(urate_tmp(ind));
ln_ind = zeros(n,n);
ind2=find(squeeze(logical(sum(lin_est,1))));
ln_ind(ind2) = 2;
ind2=find(squeeze(logical(sum(nlin_est,1))));
ln_ind(ind2) = 3;
ln_ind=ln_ind(utmp);
tbo(:,4) = num2cell(vest_tmp(ind)+ln_ind);
sum(vest_tmp(ind)+ln_ind==0)% # of positive constant effects
sum(vest_tmp(ind)+ln_ind==1)% # of negative constant effects
sum(vest_tmp(ind)+ln_ind==2)% # of linear varying effects
sum(vest_tmp(ind)+ln_ind==3)% # of nonlinear varying effects
%tbo(:,5) = num2cell(ln_ind);
cell2csv('/Users/yangn/Box Sync/MMCR/MMCR_net_cyto.csv', tbo, ',')

fname = sprintf('/Users/yangn/Box Sync/MMCR/MMCR_cont_mc%d_summary.mat',N);
save(fname)


