function [f, m] = genf(y,m)
%simulation true function evaluated at y, 5 possible functions
%-Input
%y: values where simulation true function is evaluated


%l = length(y);
%r = max(y)-min(y);
%m = mod(j,5);
%m = randi(8);
%m = 1;
if m == 1 %complicated
    %f = y.^3;
    f = 5*sin(8*pi/7*y);%period approximate the range of y
    %z = y-floor(y);
    %f = 2*sqrt(z.*(1-z)).*sin(2*pi*(1+2^(-.6))./(z+2^(-.6)));
elseif m == 2 %sine
    f = 5*sin(4*pi/7*y);%period approximate the range of 2y
elseif m == 3 %exp
    f = -2*exp(y)-1;
elseif m == 4 %quadratic
    f = y.^2-1;
else %linear
    f = 2*y;
    m=5;
end