function Pancancer_pathway_GACM(c,pa,seed)
%clear;
if isdeployed
    c=str2num(c);
    pa=str2num(pa);
    seed = str2num(seed);
end
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
nc = length(cancertype);
np = length(pathway);
%c=3;pa=9;seed=1;
ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
y=[ytmp(:,2),ytmp(:,1)];
matchsubject=(y(:,1)>30&all(xtmp>0,2));
y=y(matchsubject,:); 
%y(:,1)=y(:,1)+.1;
hist(log(y(:,1)))
utmp=utmp(matchsubject,:);
utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
xtmp=log(xtmp(matchsubject,:));
family='w';
[n,p]=size(utmp);
u=ones(n,1);
u(:,2)=stdize(utmp(:,1));
x=cell(1);
x{1}=double.empty(n,0);
x{2}=stdize(xtmp(:,1));
z=cell(1,p);
z{1}=double.empty(n,0);
z{2}=double.empty(n,0);
j=2;
jj=2;
while j<=p
    if ~all(utmp(:,j)==utmp(:,j-1))
        u=[u,stdize(utmp(:,j))];
        jj=jj+1;
        x{jj}=stdize(xtmp(:,j));
        if any(isnan(x{jj}))
            x{jj}=double.empty(n,0);
        end
        z{jj}=double.empty(n,0);
    else
        x{jj}=[x{jj},stdize(xtmp(:,j))];
        if any(isnan(x{jj}))
            x{jj}=double.empty(n,0);
        end
    end
    j=j+1;
end
p=size(u,2);
N = 200000*5; %number of iterations
Npo=N/10;
thin = 5;
burnin = floor(N/2);
burninpo=floor(Npo/10);
cutoff=0.5;
ut=u;
xt=x;
zt=z;

%c
%pa
corr(y(~isnan(y(:,1)),1),u(~isnan(y(:,1)),:))
tic;
[lin_est,nlin_est,ln_est,categ_est,const_est,urate,linrate,nlinrate,lnrate,categrate,constrate,ac_eta,ac_xi,ac_sigma,~,~,~,~,~,~,~,~,~,~,eta_sd,xi_sd,sigma_var]=GACM_MCMC(y,u,x,z,cutoff,N,thin,burnin,seed,family);
for j=1:p
    ln_est{j}=lin_est{j}|nlin_est{j};
end
% if c==12&&pa==9 %KIRC PI3K-AKT pathway
%     xt=cell(1,p);
%     nt = 900;
%     for j = 1:p%[3,5,6,10,11] %varying-sparsity genes 
%         ng = sum(ln_est{j});%number of genes for this protein
%         if ng == 0
%             xt{j}=zeros(nt,length(ln_est{j}));
%         elseif ng == 2
%             ind = find(ln_est{j});
%             xt1 = linspace(min(x{j}(:,ind(1))),max(x{j}(:,ind(1))),nt^.5);
%             xt2 = linspace(min(x{j}(:,ind(2))),max(x{j}(:,ind(2))),nt^.5);
%             nt1=length(xt1);
%             nt2=length(xt2);
%             xt{j}=zeros(nt,2);
%             k=0;
%             for i = 1:nt1
%                 for jj = 1:nt2
%                     k=k+1;
%                     xt{j}(k,ind(1))=xt1(i);
%                     xt{j}(k,ind(2))=xt2(jj);
%                 end
%             end
%             xt{j}(:,~ln_est{j})=0;
%         elseif ng==1
%             ind = find(ln_est{j});
%             xt{j}(:,ind) = linspace(min(x{j}(:,ind)),max(x{j}(:,ind)),nt);
%             xt{j}(:,~ln_est{j})=0;
%         end
%     end
%     ut=double.empty(nt,0);
%     zt=cell(1,16);
% end
[betax_est,betaX_est,betaZ_est,betamu_est,~,~,~,~,v_est,v_upper,v_lower,urate,u_est,ypred,linkpred,lppred,v_pred,v_pred_upper,v_pred_lower,u_pred,u_pred_rate,sigma_est]=GACM_postMCMC(y,u,x,z,cutoff,ut,xt,zt,lin_est,nlin_est,categ_est,const_est,Npo,burninpo,seed,family,eta_sd,xi_sd,sigma_var);
time=toc;

fname = sprintf('GACM_%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,seed);
save(fname)

