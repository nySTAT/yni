function [beta, GF] = genBeta(z,per,p,mu,noise,gamma,r)
%Generate graph for simulation
%-Input
%gamma: indicator matrix indicating which links are on with dim G by G
%beta: coefficients (should have same dimension as gamma)
%n: sample size
%noise (optional): the standard deviation of the error,default is 1.
%per: percentage of linearity
% 0: 0% linearity
% 1: about 1/5 linearity
% 2: about 1/2 linearity
% 3: about 3/4 linearity
% 4: 100% linearity
%r: binary; randomly assign funcitons or sequentially
%-Oput
%Y: protein expressions
%GF: GF(g,j),the function generating Y(g,:) from Y(g,j)
% 0: NONE
% 1: Cosine (Complicated)
% 2: Sine
% 3: Exponential
% 4: Quadratic
% 5: Linear
[n,q] = size(z);
if nargin<7
    r = 1;
end
if nargin<6
    gamma = ones(q,p);
end
if nargin<5
    noise = 0;
end
if nargin<4
    mu = zeros(p,1);
end
GF = zeros(q,p);
beta = zeros(n,p);
k = 0;
for j = 1:p
    for i = 1:q
        if gamma(i,j)>0
            k = k + 1;
            if per == 0
                if r ~= 1
                    m = mod(k-1,4) + 1;
                else
                    m = randi(4);
                end
            elseif per == 1
                if r ~= 1
                    m = mod(k,5);
                else
                    m = randi(5);
                end
            elseif per == 2
                if r ~= 1
                    m = mod(k,8);
                else
                    m = randi(8);
                    m(m>5)=5;
                end
            elseif per == 3
                if r~=1
                    m = mod(k,16);
                else
                    m = randi(16);
                    m(m>5)=5;
                end
            else
                m = 5;
            end
            [f, m] = genf(z(:,i),m);
            beta(:,j) = beta(:,j) +  2*f;
            GF(i,j) = m;
        end
    end
    %if beta(1,j)~=0
        beta(:,j) = mu(j) + beta(:,j) + noise*randn(n,1);
    %end
    %[beta(:,j),~,~] = stdize(beta(:,j));
end


