%%
clear
s=1;
seed=1;
Ni=1;
for famind=4:4
    for Ni=1:1
        GVSM(s,seed,Ni,famind);
    end
end
[)


%%
clear

seed=1;
Ni=1;
for s = 9:9
    for famind=4:4
        for Ni=1:1
            GVSM_sameX(s,seed,Ni,famind);
        end
    end
end
[)


%%
clear
for c=[12,19,24,10]
    for pa=1:12
        Pancancer_pathway_no_gene(c,pa,1);
    end
end
%%
clear
for c=12
    for pa=9
        Pancancer_pathway_GACM(c,pa,1);
    end
end