function GACM_sameX(s,seed,Ni,famind)
%%
%varying coefficients regression with thresholding and reduced rank
%orthogonal basis matrix
%clear
%famind=1;
% s=1;
% seed=1;
% Ni=1;
%data generation
if isdeployed
     seed=str2num(seed);
     Ni=str2num(Ni);
%      q = str2num(q);
%      r = str2num(r);
%      p = str2num(p);
     s = str2num(s);
     famind=str2num(famind);
end
if famind==1
    family='n';
elseif famind==2
    family='b';
elseif famind==3
    family='p';
elseif famind==4
    family='w';
end
if Ni==1
    N=200000;
elseif Ni==2
    N=500000;
elseif Ni==3
    N=1000000;
elseif Ni==4
    N=3000000;
elseif Ni==5
    N=5000000;
elseif Ni==6
    N=10000000;
end
%N = 1000000/10; %number of iterations
Npo=N/10;
thin = 5;
burnin = floor(N/2);
burninpo=floor(Npo/10);
cutoff=0.5;
[q,r,p,n,noise,nt,atrue,ptrue,y,yt,link,linkt,lp,lpt,u,ut,x,xt,z,zt,v0_true,v0_test,v_true,v_test,utrue,u_test,t_true,dens,Zind]=setup_reg_sameX(s,seed,family);


tic;
[v_est,u_est,betax_est,betaX_est,betaZ_est,betamu_est,lin_est,nlin_est,ln_est,categ_est,const_est,lppred,urate,linrate,nlinrate,lnrate,categrate,constrate,sigma_est,countv,countx,countX,countZ,countmu,ac_eta,ac_xi,ac_sigma]=GACM_sameX_MCMC(y,u,x,z,cutoff,ut,xt,zt,N,thin,burnin,seed,family);
time=toc;





aTPR = sum(sum(ln_est.*atrue))/sum(sum(atrue));
aFDR = sum(sum(ln_est.*(1-atrue)))/sum(sum(ln_est));
pTPR = sum(sum(categ_est.*ptrue))/sum(sum(ptrue));
pFDR = sum(sum(categ_est.*(1-ptrue)))/sum(sum(categ_est));
uTPR = sum(sum(u_est.*utrue))/sum(sum(utrue));
uFDR = sum(sum(u_est.*(1-utrue)))/sum(sum(u_est));


TP  = sum(sum(ln_est .*atrue));
FP  = sum(sum(ln_est ))-TP ;
TN  = q*p -sum(sum(atrue))-FP ;
FN  = q*p-TP -FP -TN ;
MCC_a  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));
TP  = sum(sum(categ_est .*ptrue));
FP  = sum(sum(categ_est ))-TP ;
TN  = r*p -sum(sum(ptrue))-FP ;
FN  = r*p-TP -FP -TN ;
MCC_p  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));
TP  = sum(sum(u_est .*utrue));
FP  = sum(sum(u_est ))-TP ;
TN  = n*p -sum(sum(utrue))-FP ;
FN  = n*p-TP -FP -TN ;
MCC_u  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));


try
    aAUC = ROC_reg(atrue,lnrate,1000,0,1);
catch
    aAUC = nan(1);
end
try
    aAUC5 = ROC_reg(atrue,lnrate,1000,0,0.2);
catch
    aAUC5 = nan(1);
end
try
    pAUC = ROC_reg(ptrue,categrate,1000,0,1);
catch
    pAUC = nan(1);
end
try
    pAUC5 = ROC_reg(ptrue,categrate,1000,0,0.2);
catch
    pAUC5 = nan(1);
end
try
    uAUC = ROC_reg(utrue,urate,1000,0,1);
catch
    uAUC = nan(1);
end
try
    uAUC5 = ROC_reg(utrue,urate,1000,0,0.2);
catch
    uAUC5 = nan(1);
end
[aTPR,aFDR,MCC_a;pTPR,pFDR,MCC_p;uTPR,uFDR,MCC_u]

% plot(yt,linkpred,'o')
% %plot(yt,sum(ut.*v_est,2),'o')
% %plot(yt,sum(ut.*v_test,2),'o')
% hold on
%ypred_ls=[ones(nt,1),ut]*([ones(n,1),u]\y);
% plot(yt,ypred_ls,'ro')
% plot([min([yt;linkpred]),max([yt;linkpred])],[min([yt;linkpred]),max([yt;linkpred])],'-')
% hold off
MSE_lp = mean((lppred-lpt).^2);
%MSE_ls=mean((yt-ypred_ls).^2);%ls mse
%1,28,39,41
% pp=1;
% qq=1;
% xtmp = x(:,qq);
% %xtmp2 = xtmp-mean(xtmp);
% %xtmp2 = xtmp2/norm(xtmp2,'fro');
% ytmp = v0_est(:,pp);
% %ytmpu = v0_upper(:,pp);
% %ytmpl = v0_lower(:,pp);
% %utmp = urate(:,pp);
% [xtmp,I] = sort(xtmp);
% %xtmp2 = xtmp2(I);
% %plot(xtmp,utmp(I),'ro')
% hold on
% plot(xtmp,ytmp(I),'--')
% %plot(xtmp,ytmpu(I),'--')
% %plot(xtmp,ytmpl(I),'--')
% hold on
% %plot(xtmp,sin(4*pi/7*xtmp),'o')
% plot(xtmp,v0_true(I,pp),'o')
% hold off



% xtmp = xt(:,qq);
% xtmp2 = xtmp-mean(xtmp);
% xtmp2 = xtmp2/norm(xtmp2,'fro');
% ytmp = v0_pred(:,pp);
% ytmpu = v0_pred_upper(:,pp);
% ytmpl = v0_pred_lower(:,pp);
% utmp = u_pred_rate(:,pp);
% [xtmp,I] = sort(xtmp);
% xtmp2 = xtmp2(I);
% %plot(xtmp,utmp(I))
% plot(xtmp,ytmp(I))
% hold on
% plot(xtmp,ytmpu(I),'--')
% plot(xtmp,ytmpl(I),'--')
% %plot(xtmp,sin(4*pi/7*xtmp),'o')
% plot(xtmp,v0_test(I,pp),'o')
% hold off
fname = sprintf('GACM_sameX_%s_s%d_mc%d_seed%d.mat',family,s,N,seed);
save(fname)
