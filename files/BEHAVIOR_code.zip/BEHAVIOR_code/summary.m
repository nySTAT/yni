clear
GVSM_FDR=zeros(4,1);
GVSM_MCC=zeros(4,1);
GACM_FDR=zeros(4,1);
GACM_MCC=zeros(4,1);
cGVSM_FDR=zeros(4,1);
cGVSM_MCC=zeros(4,1);
cGACM_FDR=zeros(4,1);
cGACM_MCC=zeros(4,1);
A=[];
B=[];
for s=0:3
    N=200000;
    family='w';
    TPRa = zeros(50,1);
    FDRa = zeros(50,1);
    MCCa = zeros(50,1);
    AUCa = zeros(50,1);
    %AUC5a = zeros(50,1);
    % TPRp = zeros(50,1);
    % FDRp = zeros(50,1);
    % MCCp = zeros(50,1);
    % AUCp = zeros(50,1);
    % AUC5p = zeros(50,1);
    TPRu = zeros(50,1);
    FDRu = zeros(50,1);
    MCCu = zeros(50,1);
    AUCu = zeros(50,1);
    %AUC5u = zeros(50,1);
    TPRpred = zeros(50,1);
    FDRpred = zeros(50,1);
    MCCpred = zeros(50,1);
    %AUCpred = zeros(50,1);
    %AUC5pred = zeros(50,1);
    mse_lp = zeros(50,1);
    mse_y = zeros(50,1);
    for seed = 1:50
        fname = sprintf('/Users/yangn/Box Sync/GVSM_sim/GVSM_%s_s%d_mc%d_seed%d.mat',family,s,N,seed);
        load(fname)
        for j=1:p
            ln_est{j}=lnrate{j}>.9;%linrate{j}>.8|nlinrate{j}>.8;
        end
        TP = 0;
        FP = 0;
        TN = 0;
        FN = 0;
        nq=cell(p,1);
        for j = 1:p
            TPtmp=sum(ln_est{j}.*atrue{j});
            TP  = TP+TPtmp;
            FPtmp = sum(sum(ln_est{j}))-TPtmp;
            FP  = FP+FPtmp;
            nq{j}=size(x{j},2);
            TNtmp=nq{j} -sum(sum(atrue{j}))-FPtmp;
            TN  = TN + TNtmp;
            FN  = FN+nq{j}-TPtmp -FPtmp -TNtmp ;
        end
        aTPR = TP/(TP+FN);
        aFDR = FP/(TP+FP);
        MCC_a  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));
        atrue_vec=[];
        arate_vec = [];
        for i = 1:p
            atrue_vec=[atrue_vec;atrue{i}];
            arate_vec=[arate_vec;bsxfun(@max,linrate{i},nlinrate{i})];
        end
        aAUC = ROC_reg(atrue_vec,arate_vec,1000,0,1);
        TPRa(seed) = aTPR;
        FDRa(seed) = aFDR;
        MCCa(seed) = MCC_a;
        
        AUCa(seed) = aAUC;
        %     AUC5a(seed) = aAUC5;
        %     TPRp(seed) = pTPR;
        %     FDRp(seed) = pFDR;
        %     MCCp(seed) = MCC_p;
        %     AUCp(seed) = pAUC;
        %     AUC5p(seed) = pAUC5;
        TPRu(seed) = uTPR;
        FDRu(seed) = uFDR;
        MCCu(seed) = MCC_u;
        %uAUC5 = ROC_reg(utrue,urate,1000,0,0.2);
        AUCu(seed) = uAUC;
        %AUC5u(seed) = uAUC5;
        TPRpred(seed) = uTPR_pred;
        FDRpred(seed) = uFDR_pred;
        MCCpred(seed) = MCC_upred;
        %     AUCpred(seed) = uAUC_pred;
        %     AUC5pred(seed) = uAUC5_pred;
        mse_lp(seed)= MSE_lp;
        mse_y(seed)=MSE_y;
    end
    MCCa(isnan(MCCa))=0;
    MCCu(isnan(MCCu))=0;
    MCCpred(isnan(MCCpred))=0;
    GVSM_FDR(s+1)=mean(FDRu);
    GVSM_MCC(s+1)=mean(MCCu);
    cGVSM_FDR(s+1)=mean(FDRa);
    cGVSM_MCC(s+1)=mean(MCCa);
    A=[A;round2([mean(TPRa),mean(FDRa),mean(MCCa),mean(AUCa),mean(TPRu),mean(FDRu),mean(MCCu),mean(AUCu),mean(mse_lp)]',0.001)];
    B=[B;round2([std(TPRa),std(FDRa),std(MCCa),std(AUCa),std(TPRu),std(FDRu),std(MCCu),std(AUCu),std(mse_lp)]',0.001)];
end

C=[];
D=[];
for s=0:3
    N=200000;
    family='w';
    TPRa = zeros(50,1);
    FDRa = zeros(50,1);
    MCCa = zeros(50,1);
    AUCa = zeros(50,1);
    %AUC5a = zeros(50,1);
    % TPRp = zeros(50,1);
    % FDRp = zeros(50,1);
    % MCCp = zeros(50,1);
    % AUCp = zeros(50,1);
    % AUC5p = zeros(50,1);
    TPRu = zeros(50,1);
    FDRu = zeros(50,1);
    MCCu = zeros(50,1);
    AUCu = zeros(50,1);
    %AUC5u = zeros(50,1);
    %TPRpred = zeros(50,1);
    %FDRpred = zeros(50,1);
    %MCCpred = zeros(50,1);
    %AUCpred = zeros(50,1);
    %AUC5pred = zeros(50,1);
    mse_lp = zeros(50,1);
    mse_y = zeros(50,1);
    for seed = 1:50
        fname = sprintf('/Users/yangn/Box Sync/GVSM_sim/GACM_%s_s%d_mc%d_seed%d.mat',family,s,N,seed);
        load(fname)
        for j=1:p
            ln_est{j}=lnrate{j}>.9;%linrate{j}>.8|nlinrate{j}>.8;
        end
        TP = 0;
        FP = 0;
        TN = 0;
        FN = 0;
        nq=cell(p,1);
        for j = 1:p
            TPtmp=sum(ln_est{j}.*atrue{j});
            TP  = TP+TPtmp;
            FPtmp = sum(sum(ln_est{j}))-TPtmp;
            FP  = FP+FPtmp;
            nq{j}=size(x{j},2);
            TNtmp=nq{j} -sum(sum(atrue{j}))-FPtmp;
            TN  = TN + TNtmp;
            FN  = FN+nq{j}-TPtmp -FPtmp -TNtmp ;
        end
        aTPR = TP/(TP+FN);
        aFDR = FP/(TP+FP);
        MCC_a  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));
        atrue_vec=[];
        arate_vec = [];
        for i = 1:p
            atrue_vec=[atrue_vec;atrue{i}];
            arate_vec=[arate_vec;bsxfun(@max,linrate{i},nlinrate{i})];
        end
        aAUC = ROC_reg(atrue_vec,arate_vec,1000,0,1);
        TPRa(seed) = aTPR;
        FDRa(seed) = aFDR;
        MCCa(seed) = MCC_a;
        AUCa(seed) = aAUC;
        %     AUC5a(seed) = aAUC5;
        %     TPRp(seed) = pTPR;
        %     FDRp(seed) = pFDR;
        %     MCCp(seed) = MCC_p;
        %     AUCp(seed) = pAUC;
        %     AUC5p(seed) = pAUC5;
        TPRu(seed) = uTPR;
        FDRu(seed) = uFDR;
        MCCu(seed) = MCC_u;
        AUCu(seed) = uAUC;
        %         TPRpred(seed) = uTPR_pred;
        %         FDRpred(seed) = uFDR_pred;
        %         MCCpred(seed) = MCC_upred;
        %     AUCpred(seed) = uAUC_pred;
        %     AUC5pred(seed) = uAUC5_pred;
        mse_lp(seed)= MSE_lp;
        mse_y(seed)=MSE_y;
    end
    MCCa(isnan(MCCa))=0;
    MCCu(isnan(MCCu))=0;
    %MCCpred(isnan(MCCpred))=0;
    GACM_FDR(s+1)=mean(FDRu);
    GACM_MCC(s+1)=mean(MCCu);
    cGACM_FDR(s+1)=mean(FDRa);
    cGACM_MCC(s+1)=mean(MCCa);
    C=[C;round2([mean(TPRa),mean(FDRa),mean(MCCa),mean(AUCa),mean(TPRu),mean(FDRu),mean(MCCu),mean(AUCu),mean(mse_lp)]',0.001)];
    D=[D;round2([std(TPRa),std(FDRa),std(MCCa),std(AUCa),std(TPRu),std(FDRu),std(MCCu),std(AUCu),std(mse_lp)]',0.001)];
end
op = cell(length(A),12);
op(:,1)={'&'};
op(:,2)={'cTPR';'cFDR';'cMCC';'cAUC';'TPR';'FDR';'MCC';'AUC';'MSPE';'cTPR';'cFDR';'cMCC';'cAUC';'TPR';'FDR';'MCC';'AUC';'MSPE';'cTPR';'cFDR';'cMCC';'cAUC';'TPR';'FDR';'MCC';'AUC';'MSPE';'cTPR';'cFDR';'cMCC';'cAUC';'TPR';'FDR';'MCC';'AUC';'MSPE'};%;'MSE\_t';'MSE\_v'
op(:,3)={'&'};
op(:,4)=num2cell(A);
op(:,5)={'$('};
op(:,6)=num2cell(B);
op(:,7)={')$'};
op(:,8)={'&'};
op(:,9)=num2cell(C);
op(:,10)={'$('};
op(:,11)=num2cell(D);
op(:,12)={')$'};



fid=fopen('table.txt','w');
[nrows,ncols] = size(op);
for row = 1:nrows
    fprintf(fid,'%s %s %s %4.3f %s %4.3f %s %s %4.3f %s %4.3f %s \\\\ \n',op{row,:});
end
fclose(fid);


save('/Users/yangn/Dropbox/Research/projects/GVSM/code/GVSM_FDR.txt','GVSM_FDR','-ascii')
save('/Users/yangn/Dropbox/Research/projects/GVSM/code/GVSM_MCC.txt','GVSM_MCC','-ascii')
save('/Users/yangn/Dropbox/Research/projects/GVSM/code/GACM_FDR.txt','GACM_FDR','-ascii')
save('/Users/yangn/Dropbox/Research/projects/GVSM/code/GACM_MCC.txt','GACM_MCC','-ascii')
save('/Users/yangn/Dropbox/Research/projects/GVSM/code/cGVSM_FDR.txt','cGVSM_FDR','-ascii')
save('/Users/yangn/Dropbox/Research/projects/GVSM/code/cGVSM_MCC.txt','cGVSM_MCC','-ascii')
save('/Users/yangn/Dropbox/Research/projects/GVSM/code/cGACM_FDR.txt','cGACM_FDR','-ascii')
save('/Users/yangn/Dropbox/Research/projects/GVSM/code/cGACM_MCC.txt','cGACM_MCC','-ascii')
%%
%GACM
clear
A=[];
cMCC=[];
cFDR=[];
MCC=[];
FDR=[];
MSPE=[];
family='w';
N=200000;
for s=14
    TPRa = zeros(50,1);
    FDRa = zeros(50,1);
    MCCa = zeros(50,1);
    AUCa = zeros(50,1);
    AUC5a = zeros(50,1);
    TPRp = zeros(50,1);
    FDRp = zeros(50,1);
    MCCp = zeros(50,1);
    AUCp = zeros(50,1);
    AUC5p = zeros(50,1);
    TPRu = zeros(50,1);
    FDRu = zeros(50,1);
    MCCu = zeros(50,1);
    AUCu = zeros(50,1);
    AUC5u = zeros(50,1);
    TPRpred = zeros(50,1);
    FDRpred = zeros(50,1);
    MCCpred = zeros(50,1);
    AUCpred = zeros(50,1);
    AUC5pred = zeros(50,1);
    mse_lp = zeros(50,1);
    for seed = 1:50
        fname = sprintf('/Users/yangn/Box Sync/GVSM/GVSM_sameX_%s_s%d_mc%d_seed%d.mat',family,s,N,seed);
        load(fname)
        TPRa(seed) = aTPR;
        FDRa(seed) = aFDR;
        MCCa(seed) = MCC_a;
        AUCa(seed) = aAUC;
        AUC5a(seed) = aAUC5;
        TPRp(seed) = pTPR;
        FDRp(seed) = pFDR;
        MCCp(seed) = MCC_p;
        AUCp(seed) = pAUC;
        AUC5p(seed) = pAUC5;
        TPRu(seed) = uTPR;
        FDRu(seed) = uFDR;
        MCCu(seed) = MCC_u;
        AUCu(seed) = uAUC;
        AUC5u(seed) = uAUC5;
        TPRpred(seed) = uTPR_pred;
        FDRpred(seed) = uFDR_pred;
        MCCpred(seed) = MCC_upred;
        AUCpred(seed) = uAUC_pred;
        AUC5pred(seed) = uAUC5_pred;
        mse_lp(seed)= MSE_lp;
    end
    A=[A,round2([mean(TPRa),mean(FDRa),mean(MCCa),mean(AUCa),mean(AUC5a),mean(TPRp),mean(FDRp),mean(MCCp),mean(AUCp),mean(AUC5p),mean(TPRu),mean(FDRu),mean(MCCu),mean(AUCu),mean(AUC5u),mean(TPRpred),mean(FDRpred),mean(MCCpred),mean(AUCpred),mean(AUC5pred),mean(mse_lp)]',0.01)];
    A=[A,round2([std(TPRa),std(FDRa),std(MCCa),std(AUCa),std(AUC5a),std(TPRp),std(FDRp),std(MCCp),std(AUCp),std(AUC5p),std(TPRu),std(FDRu),std(MCCu),std(AUCu),std(AUC5u),std(TPRpred),std(FDRpred),std(MCCpred),std(AUCpred),std(AUC5pred),std(mse_lp)]',0.01)];
    cMCC=[cMCC,mean(MCCa)];
    cFDR=[cFDR,mean(FDRa)];
    MCC=[MCC,mean(MCCu)];
    FDR=[FDR,mean(FDRu)];
    MSPE=[MSPE,mean(mse_lp)];
    dens1=dens;
    
    TPRa = zeros(50,1);
    FDRa = zeros(50,1);
    MCCa = zeros(50,1);
    AUCa = zeros(50,1);
    AUC5a = zeros(50,1);
    TPRp = zeros(50,1);
    FDRp = zeros(50,1);
    MCCp = zeros(50,1);
    AUCp = zeros(50,1);
    AUC5p = zeros(50,1);
    TPRu = zeros(50,1);
    FDRu = zeros(50,1);
    MCCu = zeros(50,1);
    AUCu = zeros(50,1);
    AUC5u = zeros(50,1);
    TPRpred = zeros(50,1);
    FDRpred = zeros(50,1);
    MCCpred = zeros(50,1);
    AUCpred = zeros(50,1);
    AUC5pred = zeros(50,1);
    mse_lp = zeros(50,1);
    for seed = 1:50
        fname = sprintf('/Users/yangn/Box Sync/GVSM/GACM_sameX_%s_s%d_mc%d_seed%d.mat',family,s,N,seed);
        load(fname)
        TPRa(seed) = aTPR;
        FDRa(seed) = aFDR;
        MCCa(seed) = MCC_a;
        AUCa(seed) = aAUC;
        AUC5a(seed) = aAUC5;
        TPRp(seed) = pTPR;
        FDRp(seed) = pFDR;
        MCCp(seed) = MCC_p;
        AUCp(seed) = pAUC;
        AUC5p(seed) = pAUC5;
        TPRu(seed) = uTPR;
        FDRu(seed) = uFDR;
        if ~isnan(MCC_u)
            MCCu(seed) = MCC_u;
        end
        AUCu(seed) = uAUC;
        AUC5u(seed) = uAUC5;
        %     TPRpred(seed) = uTPR_pred;
        %     FDRpred(seed) = uFDR_pred;
        %     MCCpred(seed) = MCC_upred;
        %     AUCpred(seed) = uAUC_pred;
        %     AUC5pred(seed) = uAUC5_pred;
        mse_lp(seed)= MSE_lp;
    end
    A=[A,round2([mean(TPRa),mean(FDRa),mean(MCCa),mean(AUCa),mean(AUC5a),mean(TPRp),mean(FDRp),mean(MCCp),mean(AUCp),mean(AUC5p),mean(TPRu),mean(FDRu),mean(MCCu),mean(AUCu),mean(AUC5u),mean(TPRpred),mean(FDRpred),mean(MCCpred),mean(AUCpred),mean(AUC5pred),mean(mse_lp)]',0.01)];
    A=[A,round2([std(TPRa),std(FDRa),std(MCCa),std(AUCa),std(AUC5a),std(TPRp),std(FDRp),std(MCCp),std(AUCp),std(AUC5p),std(TPRu),std(FDRu),std(MCCu),std(AUCu),std(AUC5u),std(TPRpred),std(FDRpred),std(MCCpred),std(AUCpred),std(AUC5pred),std(mse_lp)]',0.01)];
    cMCC=[cMCC,mean(MCCa)];
    cFDR=[cFDR,mean(FDRa)];
    MCC=[MCC,mean(MCCu)];
    FDR=[FDR,mean(FDRu)];
    MSPE=[MSPE,mean(mse_lp)];
    dens2=dens;
    if dens1~=dens2
        disp('different data!!!')
    end
end

%output
[nr,nc]=size(A);
nc2 = nc+nc/2*3+1;
op = cell(nr,nc2);
op(:,1)={'cTPR';'cFDR';'cMCC';'cAUC';'%cAUC5';'%dTPR';'%dFDR';'%dMCC';'%dAUC';'%dAUC5';'TPR';'FDR';'MCC';'AUC';'%AUC5';'pTPR';'pFDR';'pMCC';'pAUC';'%pAUC5';'MSPE'};
i=1;
j=1;
for h = 1:nc/4
    Atmp1=(A(:,j));
    Atmp2=(A(:,j+1));
    Atmp3=(A(:,j+2));
    Atmp4=(A(:,j+3));
    j=j+4;
    i=i+1;
    op(:,i)={'&'};
    i=i+1;
    op(:,i)=num2cell(Atmp1);
    i=i+1;
    op(:,i)={'$('};
    i=i+1;
    op(:,i)=num2cell(Atmp2);
    i=i+1;
    op(:,i)={')$'};
    i=i+1;
    op(:,i)={'&'};
    i=i+1;
    op(:,i)=num2cell(Atmp3);
    i=i+1;
    op(:,i)={'$('};
    i=i+1;
    op(:,i)=num2cell(Atmp4);
    i=i+1;
    op(:,i)={')$'};
end

fid=fopen('table.txt','w');
for row = 1:nr
    fprintf(fid,['%s ',repmat('%s %4.2f %s %4.2f %s ',1,nc/2),'\\\\ \n'],op{row,:});
end
fclose(fid);

%output for R to plot
OC = [cMCC',cFDR',MCC',FDR',MSPE'];
save('/Users/yangn/Dropbox/Research/projects/GVSM/code/OC.txt','OC','-ascii')



%%
%sensitivity analysis
s=2;
N=200000;
family='w';
E=[];
F=[];

for si = 1:10
    TPRa = zeros(50,1);
    FDRa = zeros(50,1);
    MCCa = zeros(50,1);
    AUCa = zeros(50,1);
    
    TPRu = zeros(50,1);
    FDRu = zeros(50,1);
    MCCu = zeros(50,1);
    AUCu = zeros(50,1);
    
    mse_lp = zeros(50,1);
    for seed = 1:50
        fname = sprintf('/Users/yangn/Box Sync/GVSM/sens%d_w_s2_mc200000_seed%d.mat',si,seed);
        load(fname)
        TPRa(seed) = aTPR;
        FDRa(seed) = aFDR;
        MCCa(seed) = MCC_a;
        if isnan(MCCa(seed))
            MCCa(seed)=0;
        end
        AUCa(seed) = aAUC;
        
        TPRu(seed) = uTPR;
        FDRu(seed) = uFDR;
        MCCu(seed) = MCC_u;
        AUCu(seed) = uAUC;
        if isnan(MCCu(seed))
            MCCu(seed)=0;
        end
        mse_lp(seed)= MSE_lp;
        
        
        
    end
    
    E=[E;round2([mean(TPRa),mean(FDRa),mean(MCCa),mean(AUCa),mean(TPRu),mean(FDRu),mean(MCCu),mean(AUCu),mean(mse_lp)]',0.001)];
    F=[F;round2([std(TPRa),std(FDRa),std(MCCa),std(AUCa),std(TPRu),std(FDRu),std(MCCu),std(AUCu),std(mse_lp)]',0.001)];
end
E =reshape(E,18,5);
F =reshape(F,18,5);

op = cell(18,26);
op(:,1)={'gTPR';'gFDR';'gMCC';'gAUC';'pTPR';'pFDR';'pMCC';'pAUC';'MSPE';'gTPR';'gFDR';'gMCC';'gAUC';'pTPR';'pFDR';'pMCC';'pAUC';'MSPE'};
op(:,2)={'&'};
op(:,3)=num2cell(E(:,1));
op(:,4)={'$('};
op(:,5)=num2cell(F(:,1));
op(:,6)={')$'};
op(:,7)={'&'};
op(:,8)=num2cell(E(:,2));
op(:,9)={'$('};
op(:,10)=num2cell(F(:,2));
op(:,11)={')$'};
op(:,12)={'&'};
op(:,13)=num2cell(E(:,3));
op(:,14)={'$('};
op(:,15)=num2cell(F(:,3));
op(:,16)={')$'};
op(:,17)={'&'};
op(:,18)=num2cell(E(:,4));
op(:,19)={'$('};
op(:,20)=num2cell(F(:,4));
op(:,21)={')$'};
op(:,22)={'&'};
op(:,23)=num2cell(E(:,5));
op(:,24)={'$('};
op(:,25)=num2cell(F(:,5));
op(:,26)={')$'};

fid=fopen('table.txt','w');
[nrows,ncols] = size(op);
for row = 1:nrows
    fprintf(fid,'%s %s %4.3f %s %4.3f %s %s %4.3f %s %4.3f %s %s %4.3f %s %4.3f %s %s %4.3f %s %4.3f %s %s %4.3f %s %4.3f %s \\\\ \n',op{row,:});
end
fclose(fid);

%%
%sensitivity of b_lambda (requested by referee)
clear
s=2;
N=200000;
family='w';
TPRa = zeros(50,3);
FDRa = zeros(50,3);
MCCa = zeros(50,3);
AUCa = zeros(50,3);
TPRu = zeros(50,3);
FDRu = zeros(50,3);
MCCu = zeros(50,3);
AUCu = zeros(50,3);
mse_lp = zeros(50,3);
for si = 11:13
    for seed = 1:50
        fname = sprintf('/Users/yangn/Box Sync/GVSM_sim/sens%d_w_s2_mc200000_seed%d.mat',si,seed);
        load(fname)
        TPRa(seed,si-10) = aTPR;
        FDRa(seed,si-10) = aFDR;
        MCCa(seed,si-10) = MCC_a;
        if isnan(MCCa(seed,si-10))
            MCCa(seed,si-10)=0;
        end
        AUCa(seed,si-10) = aAUC;
        TPRu(seed,si-10) = uTPR;
        FDRu(seed,si-10) = uFDR;
        MCCu(seed,si-10) = MCC_u;
        AUCu(seed,si-10) = uAUC;
        if isnan(MCCu(seed,si-10))
            MCCu(seed,si-10)=0;
        end
        mse_lp(seed,si-10)= MSE_lp;
    end
end
round2([mean(TPRa);mean(FDRa);mean(MCCa);mean(AUCa);mean(TPRu);mean(FDRu);mean(MCCu);mean(AUCu);mean(mse_lp)],0.001)
round2([std(TPRa);std(FDRa);std(MCCa);std(AUCa);std(TPRu);std(FDRu);std(MCCu);std(AUCu);std(mse_lp)],0.001)

%%
%s=4,5,6,7,10,11,12
clear
TPRa = zeros(50,1);
FDRa = zeros(50,1);
MCCa = zeros(50,1);
AUCa = zeros(50,1);
TPRu = zeros(50,1);
FDRu = zeros(50,1);
MCCu = zeros(50,1);
AUCu = zeros(50,1);
TPRpred = zeros(50,1);
FDRpred = zeros(50,1);
MCCpred = zeros(50,1);
mse_lp = zeros(50,1);
mse_y = zeros(50,1);
svec=[4,5,6,7,10,11,12,8,9];
A=[];
B=[];
for si=1:9
    s=svec(si);
    N=200000;
    family='w';
    for seed = 1:50
        fname = sprintf('/Users/yangn/Box Sync/GVSM_sim/GVSM_%s_s%d_mc%d_seed%d.mat',family,s,N,seed);
        load(fname)
        for j=1:p
            ln_est{j}=lnrate{j}>.9;%linrate{j}>.8|nlinrate{j}>.8;
        end
        if si<=7
            atrue{2}=1;
            atrue{3}=1;
            atrue{4}=1;
        end
        TP = 0;
        FP = 0;
        TN = 0;
        FN = 0;
        nq=cell(p,1);
        for j = 1:p
            TPtmp=sum(ln_est{j}.*atrue{j});
            TP  = TP+TPtmp;
            FPtmp = sum(sum(ln_est{j}))-TPtmp;
            FP  = FP+FPtmp;
            nq{j}=size(x{j},2);
            TNtmp=nq{j} -sum(sum(atrue{j}))-FPtmp;
            TN  = TN + TNtmp;
            FN  = FN+nq{j}-TPtmp -FPtmp -TNtmp ;
        end
        aTPR = TP/(TP+FN);
        aFDR = FP/(TP+FP);
        MCC_a  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));
        atrue_vec=[];
        arate_vec = [];
        for i = 1:p
            atrue_vec=[atrue_vec;atrue{i}];
            arate_vec=[arate_vec;bsxfun(@max,linrate{i},nlinrate{i})];
        end
        aAUC = ROC_reg(atrue_vec,arate_vec,1000,0,1);
        TPRa(seed) = aTPR;
        FDRa(seed) = aFDR;
        MCCa(seed) = MCC_a;
        AUCa(seed) = aAUC;
        TPRu(seed) = uTPR;
        FDRu(seed) = uFDR;
        MCCu(seed) = MCC_u;
        AUCu(seed) = uAUC;
        TPRpred(seed) = uTPR_pred;
        FDRpred(seed) = uFDR_pred;
        MCCpred(seed) = MCC_upred;
        mse_lp(seed)= MSE_lp;
        mse_y(seed)=MSE_y;
    end
    MCCa(isnan(MCCa))=0;
    MCCu(isnan(MCCu))=0;
    MCCpred(isnan(MCCpred))=0;
    A=[A;round2([mean(TPRa),mean(FDRa),mean(MCCa),mean(AUCa),mean(TPRu),mean(FDRu),mean(MCCu),mean(AUCu),mean(mse_lp)]',0.001)];
    B=[B;round2([std(TPRa),std(FDRa),std(MCCa),std(AUCa),std(TPRu),std(FDRu),std(MCCu),std(AUCu),std(mse_lp)]',0.001)];

end
%round2([mean(TPRa);mean(FDRa);mean(MCCa);mean(AUCa);mean(TPRu);mean(FDRu);mean(MCCu);mean(AUCu);mean(mse_lp)],0.001)
%round2([std(TPRa);std(FDRa);std(MCCa);std(AUCa);std(TPRu);std(FDRu);std(MCCu);std(AUCu);std(mse_lp)],0.001)
A =reshape(A,9,9);
B =reshape(B,9,9);
op = cell(length(A),47);
op(:,2)={'gTPR';'gFDR';'gMCC';'gAUC';'pTPR';'pFDR';'pMCC';'pAUC';'MSPE'};%;'MSE\_t';'MSE\_v'
op(:,3)={'&'};
op(:,4)=num2cell(A(:,1));
op(:,5)={'$('};
op(:,6)=num2cell(B(:,1));
op(:,7)={')$'};
op(:,8)={'&'};
op(:,9)=num2cell(A(:,2));
op(:,10)={'$('};
op(:,11)=num2cell(B(:,2));
op(:,12)={')$'};
op(:,13)={'&'};
op(:,14)=num2cell(A(:,3));
op(:,15)={'$('};
op(:,16)=num2cell(B(:,3));
op(:,17)={')$'};
op(:,18)={'&'};
op(:,19)=num2cell(A(:,4));
op(:,20)={'$('};
op(:,21)=num2cell(B(:,4));
op(:,22)={')$'};
op(:,23)={'&&'};
op(:,24)=num2cell(A(:,5));
op(:,25)={'$('};
op(:,26)=num2cell(B(:,5));
op(:,27)={')$'};
op(:,28)={'&'};
op(:,29)=num2cell(A(:,6));
op(:,30)={'$('};
op(:,31)=num2cell(B(:,6));
op(:,32)={')$'};
op(:,33)={'&'};
op(:,34)=num2cell(A(:,7));
op(:,35)={'$('};
op(:,36)=num2cell(B(:,7));
op(:,37)={')$'};
op(:,38)={'&&'};
op(:,39)=num2cell(A(:,8));
op(:,40)={'$('};
op(:,41)=num2cell(B(:,8));
op(:,42)={')$'};
op(:,43)={'&'};
op(:,44)=num2cell(A(:,9));
op(:,45)={'$('};
op(:,46)=num2cell(B(:,9));
op(:,47)={')$'};
op=op(:,2:end);

fid=fopen('table.txt','w');
[nrows,ncols] = size(op);
for row = 1:nrows
    fprintf(fid,'%s %s %4.3f %s %4.3f %s  %s %4.3f %s %4.3f %s %s %4.3f %s %4.3f %s  %s %4.3f %s %4.3f %s  %s %4.3f %s %4.3f %s  %s %4.3f %s %4.3f %s  %s %4.3f %s %4.3f %s %s %4.3f %s %4.3f %s %s %4.3f %s %4.3f %s \\\\ \n',op{row,:});
end
fclose(fid);
