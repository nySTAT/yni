function [q,r,p,n,nt,atrue,y,yt,link,linkt,lp,lpt,u,ut,x,xt,z,zt,v0_true,v0_test,v_true,v_test,utrue,u_test,t_true,dens]=setup_reg(s,seed)
%%
if s==0
    t_true=0;
    cpara=-.39;%censoring parameter: 62.5% on average across 50 seeds
elseif s==1
    t_true = 0.1;
    cpara=-.39;%censoring parameter: 62.5% on average across 50 seeds
elseif s==3
    t_true = 0.5;
    cpara=-.36;%censoring parameter: 62.5% on average across 50 seeds
else
    t_true = 0.3;
    cpara=-.39;%censoring parameter: 62.5% on average across 50 seeds
end
if s==8
    q=5;
elseif s==9
    q=10;
else
    q=1;
end
r=0;
if s==5
    p=20;
elseif s==6
    p=50;
elseif s==7
    p=100;
elseif s==13
    p=200;
else
    p=10;
end
if s==10
    n=100;
elseif s==11
    n=200;
elseif s==12
    n=300;
else
    n=400;
end
noise=1;
nt = 400;
seed_g=1;
rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed_g);
end

x = cell(p,1);
xt = cell(p,1);
z = cell(p,1);
zt = cell(p,1);
atrue=cell(p,1);
for j = 1:p
    atrue{j}=zeros(q,1);
    x{j} = stdize(randn(n,q));%continuous
    xt{j} = stdize(randn(nt,q));%testing
    z{j} = double.empty(n,0);%categorical
    zt{j} = double.empty(nt,0);%testing
end
x{1}=double.empty(n,0);
xt{1}=double.empty(n,0);
atrue{1}=double.empty(0,1);
if s<=3    
    x{2}=stdize(randn(n,2));%continuous
    xt{2}=stdize(randn(nt,2));%testing
    atrue{2}=[1;0];
    x{3}=stdize(randn(n,2));%continuous
    xt{3}=stdize(randn(nt,2));%testing
    atrue{3}=[1;0];
    x{4}=stdize(randn(n,3));%continuous
    xt{4}=stdize(randn(nt,3));%testing
    atrue{4}=[1;0;0];
    x{5}=stdize(randn(n,3));%continuous
    xt{5}=stdize(randn(nt,3));%testing
    atrue{5}=[0;0;0];
elseif s==8||s==9
    atrue{2}=[1;zeros(q-1,1)];
    atrue{3}=[1;zeros(q-1,1)];
    atrue{4}=[1;zeros(q-1,1)]; 
else
    atrue{2}=1;
    atrue{3}=1;
    atrue{4}=1;
end
% nq = zeros(p,1);
% for j =1:p
%     nq(j) = size(x{j},2);
%     for i = 1:nq(j)
%         x{j}(:,i) = x{j}(:,i)-mean(x{j}(:,i));
%         x{j}(:,i) = x{j}(:,i)/norm(x{j}(:,i),'fro');
%         xt{j}(:,i) = xt{j}(:,i)-mean(xt{j}(:,i));
%         xt{j}(:,i) = xt{j}(:,i)/norm(xt{j}(:,i),'fro');
%     end
% end
v0_true = zeros(n+nt,p);
v0_true(:,1)=-1;
v0_true(:,2)=-2*[x{2}(:,1);xt{2}(:,1)];
%v0_true(:,3)=2*(sin(2*pi*[x{3}(:,1);xt{3}(:,1)])./(2-sin(2*pi*[x{3}(:,1);xt{3}(:,1)])));
v0_true(:,3)=1*[x{3}(:,1);xt{3}(:,1)].^2-1;
v0_true(:,4)=2*sin(1/2*pi*[x{4}(:,1);xt{4}(:,1)]);

v_true = threshold(v0_true,t_true);
v_test = v_true(n+1:n+nt,:);
v_true = v_true(1:n,:);
utrue = v_true~=0;
u_test = v_test~=0;
v0_test= v0_true(n+1:n+nt,:);
v0_true = v0_true(1:n,:);
dens = sum(sum(utrue))/n/p;
fprintf('density (1-sparsity) is %f\n',dens)
%boxplot(reshape(v0_true,n*p,1))
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end
%u = 2*rand(n,p)-1;%regressors
u = stdize(randn(n,p));
u(:,1)=1;%intercept
%ut = 2*rand(nt,p)-1;%testing regressors
ut = stdize(randn(nt,p));
ut(:,1)=1;%testing intercept


lp = sum(u.*v_true,2); %linear predictor
lpt = sum(ut.*v_test,2);%linear predictor

link = exp(lp);
y = zeros(n,2);
ytmp=wblrnd(1./link,1/noise);%true survival times
c=exp(randn(n,1)+cpara);%censoring times
y(:,2) = (ytmp<c);%censoring indicator
fprintf('percentage of censoring is %f\n',mean(1-y(:,2)))
y(:,1)=min(ytmp,c);%censored survival times
%testing
linkt = exp(lpt);
yt=wblrnd(1./linkt,1/noise);%true survival times
c=exp(randn(nt,1)+cpara);%censoring times
fprintf('percentage of testing censoring is %f\n',mean(yt>c))
%yt=min(yt,c);%censored survival times

%max(y)
%hist(link)
%hist(lp)
%for uploaded examples
% csvwrite('y.csv',y)
% csvwrite('P.csv',u)
% csvwrite('Pt.csv',ut)
% xx=zeros(n,p);
% xxt=zeros(nt,p);
% for i=1:p
%     xx(:,i)=x{i};
%     xxt(:,i)=xt{i};
% end
% csvwrite('G.csv',xx)
% csvwrite('GT.csv',xxt)


