function Pancancer_pathway_no_gene(c,pa,seed)
%clear;
if isdeployed
    c=str2num(c);
    pa=str2num(pa);
    seed = str2num(seed);
end
cancertype=importdata('../data/Pancancer/data/cancertype.txt');
pathway=importdata('../data/Pancancer/data/pathway.txt');
nc = length(cancertype);
np = length(pathway);
%c=3;pa=9;seed=1;
ytmp = csvread(sprintf('../data/Pancancer/data/%s_surv.csv',cancertype{c}),1,0);
utmp = csvread(sprintf('../data/Pancancer/data/%s_%s_protein.csv',cancertype{c},pathway{pa}),1,1);
xtmp = csvread(sprintf('../data/Pancancer/data/%s_%s_gene.csv',cancertype{c},pathway{pa}),1,1);
y=[ytmp(:,2),ytmp(:,1)];
matchsubject=(y(:,1)>30&all(xtmp>0,2));
y=y(matchsubject,:); 
%y(:,1)=y(:,1)+.1;
hist(log(y(:,1)))
utmp=utmp(matchsubject,:);
utmp(:,any(isnan(utmp), 1))=[];%remove columns with NaN's
xtmp=log(xtmp(matchsubject,:));
family='w';
[n,p]=size(utmp);
u=ones(n,1);
u(:,2)=stdize(utmp(:,1));
x=cell(1);
x{1}=double.empty(n,0);
x{2}=stdize(xtmp(:,1));
z=cell(1,p);
z{1}=double.empty(n,0);
z{2}=double.empty(n,0);
j=2;
jj=2;
while j<=p
    if ~all(utmp(:,j)==utmp(:,j-1))
        u=[u,stdize(utmp(:,j))];
        jj=jj+1;
        x{jj}=stdize(xtmp(:,j));
        if any(isnan(x{jj}))
            x{jj}=double.empty(n,0);
        end
        z{jj}=double.empty(n,0);
    else
        x{jj}=[x{jj},stdize(xtmp(:,j))];
        if any(isnan(x{jj}))
            x{jj}=double.empty(n,0);
        end
    end
    j=j+1;
end
p=size(u,2);
N = 200000*5; %number of iterations
thin = 5;
burnin = floor(N/2);
cutoff=0.5;
ut=u;

%c
%pa
corr(y(~isnan(y(:,1)),1),u(~isnan(y(:,1)),:))
tic;
[betamu_est,betamu_upper,betamu_lower,lppred,linkpred,ypred,const_est,urate,constrate,ac_eta,ac_xi,ac_sigma,betamu,const,sigma,eta_sd,xi_sd,sigma_var]=GSM_MCMC(y,u,ut,cutoff,N,thin,burnin,seed,family);
time=toc;

fname = sprintf('NG_%s_%s_p%d_mc%d_seed%d.mat',cancertype{c},pathway{pa},p-1,N,seed);
save(fname)

