%%
function BVCM_reg(s,seed,Ni)
%varying coefficients regression with thresholding and reduced rank
%orthogonal basis matrix
%clear
%data generation
if isdeployed
     seed=str2num(seed);
     Ni=str2num(Ni);
%      q = str2num(q);
%      r = str2num(r);
%      p = str2num(p);
     s = str2num(s);
end
if Ni==1
    N=100000;
elseif Ni==2
    N=500000;
elseif Ni==3
    N=1000000;
elseif Ni==4
    N=3000000;
elseif Ni==5
    N=5000000;
elseif Ni==6
    N=10000000;
end
%N = 1000000/10; %number of iterations
Np = 2;
Npo=N/10;
thin = 5;
burnin = floor(N/2);
cutoff=0.5;
[q,r,p,n,noise,nt,atrue,ptrue,y,yt,u,ut,x,xt,z,zt,v0_true,v0_test,v_true,v_test,utrue,u_test,t_true,dens,Zind]=setup_reg(s,seed);



tic;
[v_est,u_est,betax_est,betaX_est,betaZ_est,betamu_est,lin_est,nlin_est,ln_est,categ_est,const_est,ypred,urate,linrate,nlinrate,lnrate,categrate,constrate,sigma_est,countv,countx,countX,countZ,countmu,ac_eta,ac_eta2,ac_xi]=BVCM_MH_pilot(y,u,x,z,cutoff,ut,xt,zt,N,thin,burnin,Np,seed);
%[v0_est,v0_upper,v0_lower]=postMCMC(y,u,x,z,tm,lin_est,nlin_est,categ_est,const_est,Np,floor(Np/10),seed);
time=toc;
aTPR = sum(sum(ln_est.*atrue))/sum(sum(atrue));
aFDR = sum(sum(ln_est.*(1-atrue)))/sum(sum(ln_est));
pTPR = sum(sum(categ_est.*ptrue))/sum(sum(ptrue));
pFDR = sum(sum(categ_est.*(1-ptrue)))/sum(sum(categ_est));
uTPR = sum(sum(u_est.*utrue))/sum(sum(utrue));
uFDR = sum(sum(u_est.*(1-utrue)))/sum(sum(u_est));

TP  = sum(sum(ln_est .*atrue));
FP  = sum(sum(ln_est ))-TP ;
TN  = q*p -sum(sum(atrue))-FP ;
FN  = q*p-TP -FP -TN ;
MCC_a  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));
TP  = sum(sum(categ_est .*ptrue));
FP  = sum(sum(categ_est ))-TP ;
TN  = r*p -sum(sum(ptrue))-FP ;
FN  = r*p-TP -FP -TN ;
MCC_p  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));
TP  = sum(sum(u_est .*utrue));
FP  = sum(sum(u_est ))-TP ;
TN  = n*p -sum(sum(utrue))-FP ;
FN  = n*p-TP -FP -TN ;
MCC_u  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));

try
    aAUC = ROC_reg(atrue,lnrate,1000,0,1);
    aAUC5 = ROC_reg(atrue,lnrate,1000,0,0.2);
    pAUC = ROC_reg(ptrue,categrate,1000,0,1);
    pAUC5 = ROC_reg(ptrue,categrate,1000,0,0.2);
    uAUC = ROC_reg(utrue,urate,1000,0,1);
    uAUC5 = ROC_reg(utrue,urate,1000,0,0.2);
catch
    aAUC = nan(1);
    aAUC5 = nan(1);
    pAUC = nan(1);
    pAUC5 = nan(1);
    uAUC = nan(1);
    uAUC5 = nan(1);
end
[aTPR,aFDR;pTPR,pFDR;uTPR,uFDR]

% plot(yt,ypred,'o')
% %plot(yt,sum(ut.*v_est,2),'o')
% %plot(yt,sum(ut.*v_test,2),'o')
% hold on
 ypred_ls=[ones(nt,1),ut]*([ones(n,1),u]\y);
 
% plot(yt,ypred_ls,'ro')
% plot([min([yt;ypred]),max([yt;ypred])],[min([yt;ypred]),max([yt;ypred])],'-')
% hold off
MSE = mean((ypred-yt).^2);
MSE_ls=mean((yt-ypred_ls).^2);%ls mse
%MSE_v = mean(mean(mean((v0_est-v0_true(1:n,:,:)).^2)));
%MSE_t = mean((t_est-t_true).^2);
%1,28,39,41
%plot(x(:,1),v_est(:,8),'o')

fname = sprintf('BVCM_reg_s%d_mc%d_seed%d.mat',s,N,seed);
save(fname)
