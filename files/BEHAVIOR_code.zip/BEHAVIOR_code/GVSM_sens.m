function GVSM_sens(sens,seed)
 Ni=1;
 famind=4;
 s=2;
if isdeployed
    %seed=str2num(seed);
    %Ni=str2num(Ni);
    sens = str2num(sens);
    %famind=str2num(famind);
end
if famind==1
    family='n';
elseif famind==2
    family='b';
elseif famind==3
    family='p';
elseif famind==4
    family='w';
elseif famind==5
    family='l';
end
if Ni==1
    N=200000;
elseif Ni==2
    N=500000;
elseif Ni==3
    N=1000000;
elseif Ni==4
    N=3000000;
elseif Ni==5
    N=5000000;
elseif Ni==6
    N=10000000;
end
%N = 1000000/10; %number of iterations
Npo=N/10;
thin = 5;
burnin = floor(N/2);
burninpo=floor(Npo/10);
cutoff=0.5;
%[q,r,p,n,noise,nt,atrue,ptrue,y,yt,link,linkt,lp,lpt,u,ut,x,xt,z,zt,v0_true,v0_test,v_true,v_test,utrue,u_test,t_true,dens,Zind]=setup_reg(s,seed,family);
[q,r,p,n,nt,atrue,y,yt,link,linkt,lp,lpt,u,ut,x,xt,z,zt,v0_true,v0_test,v_true,v_test,utrue,u_test,t_true,dens]=setup_reg(s,seed);

tic;
[lin_est,nlin_est,ln_est,categ_est,const_est,urate2,linrate,nlinrate,lnrate,categrate,constrate,ac_eta,ac_t,ac_xi,ac_sigma,~,~,~,~,~,~,~,~,~,~,~,eta_sd,xi_sd,t_sd,sigma_var]=GVSM_MCMC_sens(y,u,x,z,cutoff,N,thin,burnin,seed,family,sens);
[betax_est,betaX_est,betaZ_est,betamu_est,~,~,~,~,v0_est,v0_upper,v0_lower,v_est,v_upper,v_lower,urate,u_est,ypred,linkpred,lppred,v0_pred,v0_pred_upper,v0_pred_lower,v_pred,v_pred_upper,v_pred_lower,u_pred,u_pred_rate,t_est,sigma_est]=postMCMC_sens(y,u,x,z,cutoff,ut,xt,zt,lin_est,nlin_est,categ_est,const_est,Npo,burninpo,seed,family,eta_sd,xi_sd,t_sd,sigma_var,sens);
time=toc;


for j=1:p
    ln_est{j}=lin_est{j}|nlin_est{j};
end

uTPR = sum(sum(u_est.*utrue))/sum(sum(utrue));
uFDR = sum(sum(u_est.*(1-utrue)))/sum(sum(u_est));
uTPR_pred = sum(sum(u_pred.*u_test))/sum(sum(u_test));
uFDR_pred = sum(sum(u_pred.*(1-u_test)))/sum(sum(u_pred));
TP = 0;
FP = 0;
TN = 0;
FN = 0;
nq=cell(p,1);
for j = 1:p
    TPtmp=sum(ln_est{j}.*atrue{j});
    TP  = TP+TPtmp;
    FPtmp = sum(sum(ln_est{j}))-TPtmp;
    FP  = FP+FPtmp;
    nq{j}=size(x{j},2);
    TNtmp=nq{j} -sum(sum(atrue{j}))-FPtmp;
    TN  = TN + TNtmp;
    FN  = FN+nq{j}-TPtmp -FPtmp -TNtmp ;
end
aTPR = TP/(TP+FN);
aFDR = FP/(TP+FP);
MCC_a  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));

TP  = sum(sum(u_est .*utrue));
FP  = sum(sum(u_est ))-TP ;
TN  = n*p -sum(sum(utrue))-FP ;
FN  = n*p-TP -FP -TN ;
MCC_u  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));
TP  = sum(sum(u_pred .*u_test));
FP  = sum(sum(u_pred ))-TP ;
TN  = nt*p -sum(sum(u_test))-FP ;
FN  = nt*p-TP -FP -TN ;
MCC_upred  = (TP *TN -FP *FN )/sqrt((TP +FP )*(TP +FN )*(TN +FP )*(TN +FN ));
[aTPR,aFDR,MCC_a;uTPR,uFDR,MCC_u;uTPR_pred,uFDR_pred,MCC_upred]
%
% try
%     aAUC = ROC_reg(atrue,lnrate,1000,0,1);
%     aAUC5 = ROC_reg(atrue,lnrate,1000,0,0.2);
%     pAUC = ROC_reg(ptrue,categrate,1000,0,1);
%     pAUC5 = ROC_reg(ptrue,categrate,1000,0,0.2);
%     uAUC = ROC_reg(utrue,urate,1000,0,1);
%     uAUC5 = ROC_reg(utrue,urate,1000,0,0.2);
%     uAUC_pred = ROC_reg(u_test,u_pred_rate,1000,0,1);
%     uAUC5_pred = ROC_reg(u_test,u_pred_rate,1000,0,0.2);
% catch
%     aAUC = nan(1);
%     aAUC5 = nan(1);
%     pAUC = nan(1);
%     pAUC5 = nan(1);
%     uAUC = nan(1);
%     uAUC5 = nan(1);
%     uAUC_pred = nan(1);
%     uAUC5_pred = nan(1);
% end
%
atrue_vec=[];
arate_vec = [];
for i = 1:p
    atrue_vec=[atrue_vec;atrue{i}];
    arate_vec=[arate_vec;bsxfun(@max,linrate{i},nlinrate{i})];
end
%fname = sprintf('/Users/yangn/Box Sync/GVSM/GVSM_%s_s%d_mc%d_seed%d.mat',family,s,N,seed);
uAUC = ROC_reg(utrue,urate,1000,0,1);
aAUC = ROC_reg(atrue_vec,arate_vec,1000,0,1);
MSE_lp = median((lppred-lpt).^2);
MSE_link = median((linkpred-linkt).^2);
MSE_y = median((yt-ypred).^2);
MSE_v = median(mean(mean((v0_est-v0_true(1:n,:,:)).^2)));
MSE_t = median((t_est-t_true).^2);


%fname = sprintf('GVSM_%s_s%d_mc%d_seed%d.mat',family,s,N,seed);
fname = sprintf('sens%d_%s_s%d_mc%d_seed%d.mat',sens,family,s,N,seed);
save(fname)
