function [AUC,ROC1,ROC2,T] = ROC_reg(gamma_true,gamma_rate,ncut,Hua, percentage)
%Compute (or plot) the ROC curve and AUC
%-Input(only use the upper triangle part)
%gamma_rate: the inclusion probability matrix 
%ncut: number of cutoffs
%percentage: the AUC is calculated restricted to FPR<=percentage
%Hua: do not plot if it is zero, plot otherwise
%-Output
%AUC: area under ROC curve (normalized if percentage<1)
%ROC1: Vector of False Positive Rates
%ROC2: Vector of True Positive Rates
%T: Vector of Thresholds (cutoffs)
%Plot of ROC curve if Hua is not zero
ROC2 = NaN(1,ncut);
ROC1 = NaN(1,ncut);
[n,G] = size(gamma_true);
if n==0;
    AUC=nan;
    ROC1=nan;
    ROC2=nan;
    T=nan;
else
    if percentage ==1
        T = linspace(1,0,ncut);
        for i = 1:ncut
            gamma_tmp = gamma_rate>T(i);
            ROC2(i) = sum(sum(sum(gamma_tmp.*gamma_true)))/sum(sum(sum(gamma_true)));
            ROC1(i) = sum(sum(sum(gamma_tmp.*(1-gamma_true))))/(n*G-sum(sum(sum(gamma_true))));
        end
        ind = ncut+1;
        AUC = trapz([0,ROC1(1:ind-1),1],[0,ROC2(1:ind-1),1]);
    else
        T = linspace(1,0,ncut);
        for i = 1:ncut
            gamma_tmp = gamma_rate>T(i);
            ROC1(i) = sum(sum(sum(gamma_tmp.*(1-gamma_true))))/(n*G-sum(sum(sum(gamma_true))));
        end
        ind = find(ROC1>percentage,1);
        T = linspace(1,T(ind),ncut);
        for i = 1:ncut
            gamma_tmp = gamma_rate>T(i);
            ROC2(i) = sum(sum(sum(gamma_tmp.*gamma_true)))/sum(sum(sum(gamma_true)));
            ROC1(i) = sum(sum(sum(gamma_tmp.*(1-gamma_true))))/(n*G-sum(sum(sum(gamma_true))));
        end
        ind = find(ROC1>percentage,1);
        AUC = trapz([0,ROC1(1:ind-1)],[0,ROC2(1:ind-1)])/ROC1(ind-1);
    end
    if Hua ~=0
        plot(ROC1,ROC2)
    end
end




