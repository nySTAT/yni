function [q,r,p,n,noise,nt,atrue,ptrue,y,yt,link,linkt,lp,lpt,u,ut,x,xt,z,zt,v0_true,v0_test,v_true,v_test,utrue,u_test,t_true,dens,Zind]=setup_reg(s,seed,family)
%%

if s == 1
    q=2;
    r=2;
    p=50;
    n=250;
    if family=='w'
        noise=2;
    else
        noise=1;
    end
    nt = n;
end
seed_g=1;
rel = version('-release');
if (all(rel>='2011a'))
    rng('default');
    rng(seed_g);
end

x = cell(p,1);
xt = cell(p,1);
z = cell(p,1);
zt = cell(p,1);

for j = 1:p
    x{j}=randn(n,q);%continuous
    xt{j}=randn(nt,q);%testing
    z{j}=randi(3,n,r);%categorical
    zt{j} = randi(3,nt,r);%testing
end

atrue = zeros(q,p);
ptrue = zeros(r,p);
atrue(1,1)=1;
atrue(2,2)=1;
atrue(1,3)=1;
ptrue(1,3)=0;
ptrue(2,4)=1;

%atrue = binornd(1,.05,q,p);
%ptrue = binornd(1,.05,r,p);
%x = x(1:n,:);
v0_true = zeros(n+nt,p);
Z = cell(p,1);
Zt = cell(p,1);
Zind = cell(p,1);
v0_true(:,1)=-[x{1}(:,1);xt{1}(:,1)];
v0_true(:,2)=[x{2}(:,2);xt{2}(:,2)].^2-1;
%v0_true(:,3)=exp(.5*[x{3}(:,1);xt{3}(:,1)])-2;
v0_true(:,3)=1.5*sin(1/2*pi*[x{3}(:,1);xt{3}(:,1)]);
%v0_true(:,1)=2*[x(:,1);xt(:,1)];
%v0_true(:,2)=-3*[x(:,2);xt(:,2)];
for j =1:p
    Z{j}=double.empty(n,0);
    Zt{j}=double.empty(nt,0);
    Zind{j}=[];
    for i =1:r
        Ztmp = dummyvar(z{j}(:,i));
        Z{j} = [Z{j},Ztmp];
        Zt{j} = [Zt{j},dummyvar(zt{j}(:,i))];
        Zind{j} = [Zind{j};i*ones(size(Ztmp,2),1)];
    end
    v0_true(:,j) = v0_true(:,j) + [Z{j};Zt{j}]*(ptrue(Zind{j},j).*[0,1.5,1,1,1.5,0]');
    %(ptrue(Zind{j},j).*(randn(length(Zind{j}),1)));
end
v0_true(:,5)=-1;
t_true = 0.5;%!
v_true = threshold(v0_true,t_true);
v_test = v_true(n+1:n+nt,:);
v_true = v_true(1:n,:);
utrue = v_true~=0;
u_test = v_test~=0;
v0_test= v0_true(n+1:n+nt,:);
v0_true = v0_true(1:n,:);
dens = sum(sum(utrue))/n/p;
fprintf('density (1-sparsity) is %f\n',dens)
%boxplot(reshape(v0_true,n*p,1))
%%
if (all(rel>='2011a'))
    rng('default');
    rng(seed);
end
u = 3*rand(n,p)-1.6;%regressors
%u = stdize(u);
u(:,1)=1;%intercept
ut = 3*rand(nt,p)-1.6;%testing regressors
%ut = stdize(ut);
ut(:,1)=1;%testing intercept


lp = sum(u.*v_true,2); %linear predictor
lpt = sum(ut.*v_test,2);%linear predictor
if family=='n'
    y = lp+noise*randn(n,1);%response
    link = lp;
    yt = lpt+noise*randn(nt,1);
    linkt = lpt;
    ym=mean(y);
    y = y-ym;
    yt = yt-ym;
elseif family=='b'
    link=1./(1+exp(-lp));
    y = binornd(1,link);
    linkt=1./(1+exp(-lpt));
    yt = binornd(1,linkt);
elseif family=='p'
    link = exp(lp);
    y = poissrnd(link);
    linkt = exp(lpt);
    yt = poissrnd(linkt);
elseif family=='w'
    link = exp(lp);
    y = zeros(n,2);
    ytmp=wblrnd(1./link,1/noise);%true survival times
    c=exp(randn(n,1)+4);%censoring times
    y(:,2) = (ytmp<c);%censoring indicator
    fprintf('percentage of censoring is %f\n',mean(1-y(:,2)))    
    y(:,1)=min(ytmp,c);%censored survival times
    %testing
    linkt = exp(lpt);
    yt=wblrnd(1./linkt,1/noise);%true survival times
    c=exp(randn(nt,1)+4);%censoring times
    fprintf('percentage of testing censoring is %f\n',mean(yt>c))    
    yt=min(yt,c);%censored survival times
end

hist(link)




