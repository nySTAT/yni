function [y, m, sd] = stdize(x)
%standardize data x
%-Input
%x: data to be standardize
%-Output
%y: standardized data
%m: column means of x
%sd: column standard deviation of x
n = size(x,1);
m = mean(x);
sd = std(x);
y = (x - repmat(m,[n 1])) ./ repmat(sd,[n 1]);