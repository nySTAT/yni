source("util.R")

#Read in data 
y=as.matrix(read.csv("y.csv",header = FALSE))#responses (n x p)
x=as.matrix(read.csv("x.csv",header = FALSE))#covariates (n x q+1)
Omega0=as.matrix(read.csv("Omega.csv",header = FALSE))#true precision matrices 
xnew=as.matrix(read.csv("xnew.csv",header = FALSE))#covariates for new observations
Omega0new=as.matrix(read.csv("Omeganew.csv",header = FALSE))#true precision matrices for new observations 

#MCMC parameters
MCMC.param = list(niter=10000,
                  burnin=5000,
                  thin=10,
                  warmstart=TRUE,
                  beta_sd=0.2,
                  t_sd=.15,
                  gam_sd=.15)

#Model hyperparameters
model.param = list(a_tau=.1,
                   b_tau=.1)


#Run MCMC
result= GGMx_MCMC(y,x,xnew,model.param,MCMC.param)

Omega_est=result$Omega_est#estimated precision matrix (p x p x n)
Omega_new_est=result$Omega_new_est#interpolated precision matrix


