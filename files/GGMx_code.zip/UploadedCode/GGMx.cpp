// [[Rcpp::depends(RcppArmadillo)]]
#include <iostream> 
#include <RcppArmadillo.h>
#include <RcppArmadilloExtensions/rmultinom.h>
#include <stdlib.h> 
//#include <RcppArmadilloExtensions/fixprob.h>
using namespace Rcpp;
using namespace std;
using namespace arma;

// Enable C++11 via this plugin (Rcpp 0.10.3 or later)
// [[Rcpp::plugins(cpp11)]]


rowvec threshold(rowvec a, double t){
  return a%(abs(a)>t);
}


// norm_rs(a, b)
// generates a sample from a N(0,1) RV restricted to be in the interval
// (a,b) via rejection sampling.
// ======================================================================
double norm_rs(double a, double b)
{
  double  x;
  x = Rf_rnorm(0.0, 1.0);
  while( (x < a) || (x > b) ) x = norm_rand();
  return x;
}

// half_norm_rs(a, b)
// generates a sample from a N(0,1) RV restricted to the interval
// (a,b) (with a > 0) using half normal rejection sampling.
// ======================================================================
double half_norm_rs(double a, double b)
{
  double   x;
  x = fabs(norm_rand());
  while( (x<a) || (x>b) ) x = fabs(norm_rand());
  return x;
}

// unif_rs(a, b)
// generates a sample from a N(0,1) RV restricted to the interval
// (a,b) using uniform rejection sampling. 
// ======================================================================
double unif_rs(double a, double b)
{
  double xstar, logphixstar, x, logu;
  
  // Find the argmax (b is always >= 0)
  // This works because we want to sample from N(0,1)
  if(a <= 0.0) xstar = 0.0;
  else xstar = a;
  logphixstar = R::dnorm(xstar, 0.0, 1.0, 1.0);
  
  x = R::runif(a, b);
  logu = log(R::runif(0.0, 1.0));
  while( logu > (R::dnorm(x, 0.0, 1.0,1.0) - logphixstar))
  {
    x = R::runif(a, b);
    logu = log(R::runif(0.0, 1.0));
  }
  return x;
}

// exp_rs(a, b)
// generates a sample from a N(0,1) RV restricted to the interval
// (a,b) using exponential rejection sampling.
// ======================================================================
double exp_rs(double a, double b)
{
  double  z, u, rate;
  
  //  Rprintf("in exp_rs");
  rate = 1/a;
  //1/a
  
  // Generate a proposal on (0, b-a)
  z = R::rexp(rate);
  while(z > (b-a)) z = R::rexp(rate);
  u = R::runif(0.0, 1.0);
  
  while( log(u) > (-0.5*z*z))
  {
    z = R::rexp(rate);
    while(z > (b-a)) z = R::rexp(rate);
    u = R::runif(0.0,1.0);
  }
  return(z+a);
}
// rtnorm( mu, sigma, lower, upper)
//
// generates one random normal RVs with mean 'mu' and standard
// deviation 'sigma', truncated to the interval (lower,upper), where
// lower can be -Inf and upper can be Inf.
//======================================================================
double rtnorm (double mu, double sigma, double lower, double upper)
{
  int change;
  double a, b;
  double logt1 = log(0.150), logt2 = log(2.18), t3 = 0.725;
  double z, tmp, lograt;
  
  change = 0;
  a = (lower - mu)/sigma;
  b = (upper - mu)/sigma;
  
  // First scenario
  if( (a == R_NegInf) || (b == R_PosInf))
  {
    if(a == R_NegInf)
    {
      change = 1;
      a = -b;
      b = R_PosInf;
    }
    
    // The two possibilities for this scenario
    if(a <= 0.45) z = norm_rs(a, b);
    else z = exp_rs(a, b);
    if(change) z = -z;
  }
  // Second scenario
  else if((a * b) <= 0.0)
  {
    // The two possibilities for this scenario
    if((R::dnorm(a, 0.0, 1.0,1.0) <= logt1) || (R::dnorm(b, 0.0, 1.0, 1.0) <= logt1))
    {
      z = norm_rs(a, b);
    }
    else z = unif_rs(a,b);
  }
  // Third scenario
  else
  {
    if(b < 0)
    {
      tmp = b; b = -a; a = -tmp; change = 1;
    }
    
    lograt = R::dnorm(a, 0.0, 1.0, 1.0) - R::dnorm(b, 0.0, 1.0, 1.0);
    if(lograt <= logt2) z = unif_rs(a,b);
    else if((lograt > logt1) && (a < t3)) z = half_norm_rs(a,b);
    else z = exp_rs(a,b);
    if(change) z = -z;
  }
  double output;
  output = sigma*z + mu;
  return (output);
}



double dtnorm(double x,double mu,double sig,double a=0.01,double b=10){
  double alpha = (a-mu)/sig;
  double beta = (b-mu)/sig;
  return R::dnorm4((x-mu)/sig,0,1,1)-log(sig)-log(R::pnorm5(beta,0,1,1,0)-R::pnorm5(alpha,0,1,1,0));
}
double tprior(double x,uword type,double tt=1, double tv=.2){//log prior density for threshold parameter t
  double d;
  if (type==1){//Fréchet (alpha=1,s=2) 
    d=log(2.0)-2*log(x)-2/x;
  }else if (type==2){//Gamma(k=2,theta=.5)
    d=R::dgamma(x,2,.5,1);
  }else if (type==3){//beta
    d=R::dbeta(x,1,1,1);
  }else{//Truncated normal
    d=dtnorm(x,tt,tv,0,10);
  }
  return d;
}

// [[Rcpp::export]]
List GGMx_MCMC_C(cube S, mat x, mat xnew, int niter, int burnin, int thin, cube Omega_old, cube Sig_old, cube beta_old, cube tau_old, mat t_old, cube psi_old, vec gam_old, mat c_old,umat ind_noi_all,uword type,double beta_sd,double t_sd,double gam_sd, double a_tau, double b_tau, vec Temp){
  int k,i,j,m;
  int n = S.n_slices;
  int p = S.n_cols;
  int q = x.n_cols;
  int nnew=xnew.n_rows;
  uvec k_vec(1);
  vec ll(niter,fill::zeros);
  int eff_size=(niter-burnin)/thin;
  cube Omega(p*p,n,eff_size,fill::zeros);
  cube Sig(p*p,n,eff_size,fill::zeros);
  ucube G(p*p,n,eff_size,fill::zeros);
  cube Omega_pred(p*p,nnew,eff_size,fill::zeros);
  ucube G_pred(p*p,nnew,eff_size,fill::zeros);
  mat I=eye<mat>(p,p);
  double val;
  double sign;
  cube beta(p*p,q,eff_size,fill::zeros);
  cube tau(p*p,q,eff_size,fill::zeros);
  cube psi(p*p,n,eff_size,fill::zeros);
  mat t=0.1*ones(p*p,eff_size);
  mat gam=ones(p,eff_size);
  double ac_beta=0;
  
  double gam_new,gam_tmp,ltmp,max_c;
  uvec indtmp;
  
  vec c(n,fill::zeros);
  uvec ind_noi(p-1,fill::zeros);
  uvec ind_noi_seq(p-1,fill::zeros);
  mat Sig11(p-1,p-1,fill::zeros);
  vec Sig12(p-1,fill::zeros);
  cube invC11(p-1,p-1,n,fill::zeros);
  vec c_tmp(1,fill::zeros);
  rowvec c_new(n,fill::zeros);
  cube invC11beta_old(p-1,p,n,fill::zeros);
  mat invC11beta_new(p-1,n,fill::zeros);
  mat invC11_tmp(p-1,p-1,fill::zeros);
  int iter_save=0;
  int count=0;
  //variables that we need for each iteration
  double lr;
  uword this_ind;
  uword this_ind2;
  cube Omega_new(size(Omega_old),fill::zeros);
  cube Sig_new(size(Sig_old),fill::zeros);
  mat beta_new;
  vec t_new;
  mat psi_new;
  vec p_tmp(2);
  vec u(p,fill::zeros);
  rowvec vtmp(p,fill::zeros);
  cube ctmp(1,p,1,fill::zeros);
  uword jj,kk;
  Rcpp::Rcout<<"MCMC starts"<<endl;
  //iteration starts here
  for (int it=0; it<niter;it++){
    Rcpp::checkUserInterrupt();
    
    beta_new.zeros(1,q);
    t_new.zeros(1);
    psi_new.zeros(1,n);
    
    for (k=0;k<p;k++){//k-th column of the precision matrix
      k_vec(0)=k;
      ind_noi_seq=ind_noi_all.col(k);
      ind_noi=shuffle(ind_noi_seq);
      for (i=0;i<n;i++){
        Sig11 = Sig_old.slice(i).submat(ind_noi_seq,ind_noi_seq); 
        Sig12 = Sig_old.slice(i).submat(ind_noi_seq,k_vec);
        invC11.slice(i) = Sig11 - Sig12*Sig12.t()/Sig_old(k,k,i);
        c_tmp=(Omega_old.slice(i).submat(k_vec,ind_noi_seq)*invC11.slice(i)*Omega_old.slice(i).submat(ind_noi_seq,k_vec));
        c_old(k,i)=c_tmp(0);
        invC11beta_old.slice(i).col(k) = invC11.slice(i)*Omega_old.slice(i).submat(ind_noi_seq,k_vec);
      }
      for (j=0;j<(p-1);j++){
        this_ind=ind_noi(j);
        this_ind2=this_ind-(this_ind>k);
        ltmp=0;
        for (m=0;m<q;m++){
          count++;
          Omega_new=Omega_old;
          Sig_new=Sig_old;
          beta_new=beta_old.tube(this_ind,k);
          psi_new=psi_old.tube(this_ind,k);
          
          lr=0;
          beta_new(0,m)=beta_old(this_ind,k,m)+beta_sd*R::rnorm(0,1);
          lr+=(-.5*(beta_new(0,m)*beta_new(0,m))/tau_old(this_ind,k,m)+.5*pow(beta_old(this_ind,k,m),2)/tau_old(this_ind,k,m));//prior on beta
          
          t_new(0)=R::rlnorm(log(pow(t_old(this_ind,k),2)/sqrt(t_sd*t_sd+pow(t_old(this_ind,k),2))),sqrt(log(t_sd*t_sd/pow(t_old(this_ind,k),2)+1)));
          psi_new.row(0)+=((beta_new(0,m)-beta_old(this_ind,k,m))*x.col(m)).t();
          
          Omega_new(span(this_ind),span(k),span())=threshold(psi_new.row(0),t_new(0));
          Omega_new(span(k),span(this_ind),span())=Omega_new(span(this_ind),span(k),span());
          
          for (i=0;i<n;i++){
            c_new(i)=c_old(k,i);
            for (kk=0;kk<p-1;kk++){
              c_new(i)+=2*invC11(kk,this_ind2,i)*(Omega_new(k,this_ind,i)*Omega_new(k,ind_noi_seq(kk),i)-Omega_old(k,this_ind,i)*Omega_old(k,ind_noi_seq(kk),i));
            }
            c_new(i)+=-invC11(this_ind2,this_ind2,i)*(Omega_new(k,this_ind,i)*Omega_new(k,this_ind,i)-Omega_old(k,this_ind,i)*Omega_old(k,this_ind,i));
          }
          gam_new = max(R::rlnorm(log(gam_old(k)*gam_old(k)/sqrt(gam_sd*gam_sd+gam_old(k)*gam_old(k))),sqrt(log(gam_sd*gam_sd/gam_old(k)/gam_old(k)+1))),.01);
          max_c=max(c_new);
          
          for (i=0;i<n;i++){
            Omega_new(k,k,i) = gam_new+max_c;//transform back from (u,v) to (omega_12, omega_22)
            invC11beta_new.col(i)=invC11beta_old.slice(i).col(k);
            invC11beta_new.col(i)+=invC11.slice(i).col(this_ind2)*(Omega_new(this_ind,k,i)-Omega_old(this_ind,k,i));
            gam_tmp=(Omega_new(k,k,i)-c_new(i));
            Sig_new.slice(i).submat(ind_noi_seq,ind_noi_seq) = invC11.slice(i)+invC11beta_new.col(i)*invC11beta_new.col(i).t()/gam_tmp;//bottleneck
            Sig12 = -invC11beta_new.col(i)/gam_tmp;
            Sig_new.slice(i).submat(ind_noi_seq,k_vec) = Sig12;
            Sig_new.slice(i).submat(k_vec,ind_noi_seq) = Sig12.t();
            Sig_new(k,k,i) = 1/gam_tmp;
            u=Omega_new(span(),span(k),span(i))-Omega_old(span(),span(k),span(i));
            u(k)/=2;
            ctmp=S(span(k),span(),span(i));
            vtmp=ctmp.slice(0).row(0);
            lr+=Temp(it)*(.5*(log(Sig_old(k,k,i))+log(gam_tmp)-2*dot(vtmp,u)));
          }
          
          lr+= -R::dlnorm(gam_new,log(gam_old(k)*gam_old(k)/sqrt(gam_sd*gam_sd+gam_old(k)*gam_old(k))),sqrt(log(gam_sd*gam_sd/gam_old(k)/gam_old(k)+1)),1)+R::dlnorm(gam_old(k),log(gam_new*gam_new/sqrt(gam_sd*gam_sd + gam_new*gam_new)),sqrt(log(gam_sd*gam_sd/gam_new/gam_new+1)),1);//proposal on gam
          lr+=(tprior(t_new(0),type)-tprior(t_old(this_ind,k),type));//prior on t
          lr+=- R::dlnorm(t_new(0),log(pow(t_old(this_ind,k),2)/sqrt(t_sd*t_sd+pow(t_old(this_ind,k),2))),sqrt(log(t_sd*t_sd/pow(t_old(this_ind,k),2)+1)),1)+R::dlnorm(t_old(this_ind,k),log(t_new(0)*t_new(0)/sqrt(t_sd*t_sd + t_new(0)*t_new(0))),sqrt(log(t_sd*t_sd/t_new(0)/t_new(0)+1)),1);//proposal on t
          lr+=-gam_new+gam_old(k);
          
          
          if (lr > log(R::runif(0,1))) {
            ac_beta++;
            c_old.row(k)=c_new;
            invC11beta_old(span(),span(k),span())=invC11beta_new;
            beta_old(this_ind,k,m)=beta_new(0,m);
            beta_old(k,this_ind,m)=beta_new(0,m);
            for (i=0;i<n;i++){
              psi_old(this_ind,k,i)=psi_new(0,i);
              psi_old(k,this_ind,i)=psi_new(0,i);
            }
            t_old(this_ind,k)=t_new(0);
            t_old(k,this_ind)=t_new(0);
            Omega_old(span(),span(k),span())=Omega_new(span(),span(k),span());
            Omega_old(span(k),span(),span())=Omega_new(span(k),span(),span());
            Sig_old=Sig_new;
            gam_old(k)=gam_new;
          }
        }
      }
    }
    
    Rcpp::checkUserInterrupt();
    
    for (k=1;k<p;k++){
      for (j=0;j<k;j++){
        for (m=0;m<q;m++){
          tau_old(j,k,m)=max(1/R::rgamma(a_tau+.5,1/(b_tau+beta_old(j,k,m)*beta_old(j,k,m)/2)),.000001);
          tau_old(k,j,m)=tau_old(j,k,m);
        }
      }
    }
    
    for (m=0;m<q;m++){
      tau_old.slice(m).diag().ones();
    }
    
    
    for (i=0;i<n;i++){
      log_det(val, sign, Omega_old.slice(i));
      ll(it)+=.5*val-.5*trace(S.slice(i)*Omega_old.slice(i));
    }
    if ((it+1)%100==0){
      Rcpp::Rcout<<"MCMC: "<<it+1<<"/"<<niter<<" finished"<<endl;
    }
    if (it>=burnin&&it%thin==0){
      jj=0;
      for (k=0;k<p;k++){
        for (j=0;j<p;j++){
          for (i=0;i<n;i++){
            G(jj,i,iter_save)=(Omega_old(k,j,i)!=0);
            Omega(jj,i,iter_save)=Omega_old(k,j,i);
            Sig(jj,i,iter_save)=Sig_old(k,j,i);
            psi(jj,i,iter_save)=psi_old(k,j,i);
          }
          for (m=0;m<q;m++){
            beta(jj,m,iter_save)=beta_old(k,j,m);
            tau(jj,m,iter_save)=tau_old(k,j,m);
          }
          t(jj,iter_save)=t_old(k,j);
          for (i=0;i<nnew;i++){
            beta_new=beta_old.tube(k,j);
            Omega_pred(jj,i,iter_save)=threshold(xnew.row(i)*beta_new.t(),t_old(k,j))[0];
            G_pred(jj,i,iter_save)=(Omega_pred(jj,i,iter_save)!=0);
          }
          jj++;
        }
      }
      gam.col(iter_save)=gam_old;
      iter_save++;
    }
  }
  ac_beta/=count;
  ucube G_old = (Omega_old!=0);
  return List::create(
    List::create(Named("G")=G,
                 Named("Omega")=Omega,
                 Named("Sig")=Sig,
                 Named("beta")=beta,
                 Named("tau")=tau,
                 Named("psi")=psi,
                 Named("t")=t,
                 Named("G_pred")=G_pred,
                 Named("Omega_pred")=Omega_pred,
                 Named("gam")=gam,
                 Named("ac_beta")=ac_beta,
                 Named("ll")=ll),
                 List::create(Named("Omega_old")=Omega_old,
                              Named("Sig_old")=Sig_old,
                              Named("beta_old")=beta_old,
                              Named("tau_old")=tau_old,
                              Named("t_old")=t_old,
                              Named("psi_old")=psi_old,
                              Named("gam_old")=gam_old,
                              Named("c_old")=c_old,
                              Named("G_old")=G_old)
  );
}


