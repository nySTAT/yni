This folder contains R files for GGMx.

Run the DEMO.R file which performs the simulation experiments.