library(Rcpp)
sourceCpp("GGMx.cpp")



GGMx_MCMC=function(y,x,xnew,model.param,MCMC.param){
  p=ncol(y)
  n=nrow(y)
  nnew=nrow(xnew)
  q=ncol(x)-1
  S=array(apply(y,1,function(x) x%*%t(x)),c(p,p,n))
  
  
  
  temp_step=MCMC.param$burnin
  Temp=rep(1,MCMC.param$niter)#0,5
  if (MCMC.param$warmstart){
    Temp[1:temp_step]=1/c(exp(seq(log(10),0,length=temp_step)))#2,4,6,7 (6 with Gamma prior on t,7 with Frechet)
  }
  
  t_prior_type=4#1:Fréchet 2:Gamma 3: beta 4: truncated Normal
  #initialization
  Omega_old=Sig_old=array(0,c(p,p,n))
  Sig_tmp=cov(y)
  Omega_tmp=solve(Sig_tmp)
  for (i in 1:n){
    Omega_old[,,i]=Omega_tmp
    Sig_old[,,i]=Sig_tmp
  }
  tmp=array(rnorm(p*p*(q+1),0,.001),c(p,p,q+1))
  beta_old=array(apply(tmp,3,function(x) x+t(x)),c(p,p,q+1))
  beta_old[,,q+1]=Omega_tmp#!!
  t_old=matrix(0.01,p,p)
  tau_old=array(1,c(p,p,q+1))
  
  
  ind_noi_all=matrix(0,p-1,p)
  gam_old=rep(0,p)
  c_old=matrix(0,p,n)
  for (k in 1:p){
    ind_noi=(1:p)[-k]
    ind_noi_all[,k]= ind_noi-1
    for (i in 1:n){
      Sig11 = Sig_old[ind_noi,ind_noi,i];
      Sig12 = Sig_old[ind_noi,k,i];
      invC11 = Sig11 - Sig12%*%t(Sig12)/Sig_old[k,k,i];
      c_old[k,i]=Omega_old[k,ind_noi,i]%*%invC11%*%Omega_old[ind_noi,k,i]
    }
    gam_old[k] = max(mean(Omega_old[k,k,]-c_old[k,]),0.1)
  }
  psi_old=array(0,c(p,p,n))
  for (k in 2:p){
    for (j in 1:(k-1)){
      psi_old[k,j,]=psi_old[j,k,]=x%*%beta_old[j,k,]
    }
  }

  
  re= GGMx_MCMC_C(S, x, xnew, MCMC.param$niter, MCMC.param$burnin, MCMC.param$thin,  Omega_old, Sig_old,  beta_old, tau_old, t_old,psi_old, gam_old, c_old, ind_noi_all, t_prior_type,MCMC.param$beta_sd,MCMC.param$t_sd,MCMC.param$gam_sd,model.param$a_tau,model.param$b_tau,Temp)
  
  G_rate=apply(re[[1]]$G,c(1,2),mean)
  G_rate=array(G_rate,c(p,p,n))
  G_est=G_rate>.5
  Omega_est=apply(re[[1]]$Omega,c(1,2),mean)
  Omega_est=array(Omega_est,c(p,p,n))
  Omega_est=Omega_est*G_est
  G_new_rate=apply(re[[1]]$G_pred,c(1,2),mean)
  G_new_rate=array(G_new_rate,c(p,p,nnew))
  G_new_est=G_new_rate>.5
  Omega_new_est=apply(re[[1]]$Omega_pred,c(1,2),mean)
  Omega_new_est=array(Omega_new_est,c(p,p,nnew))
  Omega_new_est=Omega_new_est*G_new_est
  return(c(re,list(G_est=G_est,Omega_est=Omega_est,G_new_est=G_new_est,Omega_new_est=Omega_new_est)))
}