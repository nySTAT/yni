// [[Rcpp::depends(RcppArmadillo)]]
#include <iostream> 
#include <RcppArmadillo.h>
#include <RcppArmadilloExtensions/rmultinom.h>
#include <stdlib.h> 
#include "util.h"


arma::umat sub(int n,arma::uvec v) {
  
  arma::umat m(0,n);
  //vec iv(1);
  arma::uvec utmp;
  arma::uvec vtmp;
  arma::umat mtmp;
  if (n == 1){ 
    return v;
  }else {
    for (int i=0;i<n;i++){
      if (i==0){
        utmp = arma::linspace<arma::uvec>(1,n-1,n-1);
      }else if (i==(n-1)){
        utmp = arma::linspace<arma::uvec>(0,n-2,n-1);
      }else{
        utmp = join_cols(arma::linspace<arma::uvec>(0,i-1,i),arma::linspace<arma::uvec>(i+1,n-1,n-i-1));
      }
      vtmp = v(utmp);
      mtmp=sub(n - 1,vtmp);
      vtmp = arma::uvec(mtmp.n_rows);
      vtmp.fill(v(i));
      m =join_cols(m, join_rows(vtmp, mtmp));
    } 
    return m;
  }
  //return m;
}
arma::umat my_permutations(int n){ //permutations=permutations-1
  return sub(n,arma::linspace<arma::uvec>(0,n-1,n));
}
arma::mat hamming_matrix(arma::mat x){
  int p=x.n_cols;
  arma::mat m=arma::zeros(p,p);
  for (int i=0;i<p-1;i++){
    for (int j=i+1;j<p;j++){
      m(i,j)=sum(x.col(i)!=x.col(j));
    }
  }
  m=m+m.t();
  return m;
}
double hamming_perm (arma::urowvec perm, arma::mat z, arma::mat zp){
  return accu(abs(z - zp.cols(perm)));
}
arma::vec hamming_vec_matrix(arma::mat z, arma::mat zp, arma::uvec ind){//ind = ind-1
  arma::rowvec s = sum(abs(repmat(z,1,zp.n_cols) - zp),0);
  s(ind).fill(INFINITY);
  arma::uword i = index_min(s);
  arma::vec v(2);
  v(0)=s(i);
  v(1)=i;
  return v;
}
arma::vec hamming_vec_matrix(arma::vec z, arma::mat zp){//ind = ind-1
  arma::rowvec s = sum(abs(repmat(z,1,zp.n_cols) - zp),0);
  arma::uword i = index_min(s);
  arma::vec v(2);
  v(0)=s(i);
  v(1)=i;
  return v;
}
double Dist_perm(arma::mat z, arma::mat zp) {
  int C = z.n_cols;
  arma::umat perm = my_permutations(C);
  arma::vec v(perm.n_rows);
  for (int i=0;i<perm.n_rows;i++){
    v(i)=hamming_perm(perm.row(i),z,zp);
  }
  return min(v);
}
arma::vec Dist_perm_PBC(arma::mat z, arma::mat zp, arma::mat a, arma::mat ap, arma::mat b, arma::mat bp) {
  int C = z.n_cols;
  arma::umat perm = my_permutations(C);
  arma::vec v1(perm.n_rows),v2(perm.n_rows),v3(perm.n_rows);
  for (int i=0;i<perm.n_rows;i++){
    v1(i)=hamming_perm(perm.row(i),z,zp);
    v2(i)=hamming_perm(perm.row(i),a,ap);
    v3(i)=hamming_perm(perm.row(i),b,bp);
  }
  arma::vec v(3);
  v(0) = min(v1);
  v(1) = min(v2);
  v(2) = min(v3);
  return v;
}
arma::urowvec Dist_perm_K(arma::mat z, arma::mat zp,int K) { 
  arma::urowvec tmp(K+1);
  int C = zp.n_cols;
  arma::umat perm = my_permutations(C);
  arma::vec v(perm.n_rows);
  for (int i=0;i<perm.n_rows;i++){
    v(i)=hamming_perm(perm(i,arma::span(0,K-1)),z,zp);
  }
  arma::uword j=index_min(v);
  tmp(0)=v(j);
  tmp.tail(K)=perm(j,arma::span(0,K-1))+1;
  return tmp;
}

double Dist_seq(arma::mat z, arma::mat zp) {
  int C = z.n_cols;
  double d = 0;
  arma::vec l;
  arma::uvec ind(C);
  l = hamming_vec_matrix(z.col(0), zp);
  d+= l(0);
  ind(0)=l(1);
  for (int j=1;j<C;j++) {
    l = hamming_vec_matrix(z.col(j), zp, ind.head(j));
    d+= l(0);
    ind(j) = l(1);
  }
  return d;
}
Rcpp::List Dist_seq_ord(arma::mat z, arma::mat zp){//ord=ord-1
  int C = z.n_cols;
  double d = 0;
  arma::uvec ind(C);
  arma::vec l = hamming_vec_matrix(z.col(0), zp);
  d+= l(0);
  ind(0)=l(1);
  for (int j=1;j<C;j++) {
    l = hamming_vec_matrix(z.col(j), zp, ind.head(j));
    d+= l(0);
    ind(j) = l(1);
  }
  return Rcpp::List::create(Rcpp::Named("d")=d,Rcpp::Named("ord")=ind);
}
arma::rowvec Dist(arma::mat z, arma::cube za, arma::uword flag) {
  int n=za.n_slices;
  int i;
  arma::rowvec r(n);
  if (flag == 0) {//0=="p"
    for (i=0;i<n;i++){
      r(i)=Dist_perm(za.slice(i),z);
    }
  } else {
    for (i=0;i<n;i++){
      r(i)=Dist_seq(za.slice(i),z);
    }  
  }
  return r;
}
arma::uword MAP(arma::cube z) {
  int i;
  int n1=z.n_rows;
  int n2=z.n_cols;
  int n3=z.n_slices;
  if (n2==1){
    //z=matrix(z,nrow=n1,ncol=n3)
    arma::mat zm=mean(z,2);
    arma::mat distance(n1,n3);
    for (i=0;i<n3;i++){
      distance.col(i)=z.slice(i).col(0)-zm.col(0);
    }
    arma::rowvec tmp=sum(pow(distance,2),0);
    return index_min(tmp);
    //return find(tmp==min(tmp));
  }else{
    arma::mat m = arma::zeros(n3,n3);
    if (n2 > 3) {
      for (i=0;i<(n3-2);i++) {
        m(i, arma::span((i + 1),(n3-1))) = Dist(z.slice(i), z.slices(i + 1,n3-1), 1);
      }
      m(n3 - 2, n3-1) = Dist_seq(z.slice(n3 - 2), z.slice(n3-1));
    } else {
      for (i=0;i<(n3-2);i++) {
        m(i, arma::span((i + 1),(n3-1))) = Dist(z.slice(i), z.slices(i + 1,n3-1), 0);
      }
      m(n3 - 2, n3-1) = Dist_perm(z.slice(n3 - 2), z.slice(n3-1));
    }
    m = m + m.t();
    arma::vec tmp=sum(m,1);
    return index_min(tmp);
    //return find(tmp==min(tmp));
  }
}
arma::vec K_FREQ(arma::vec K){
  double m=max(K);
  arma::vec v(m+1,arma::fill::zeros);
  int n = K.size();
  for (int i=0;i<n;i++){
    v(K(i))++;
  }
  return v;
}

arma::uvec my_OR(arma::rowvec x, arma::rowvec y){
  int n =x.n_elem;
  arma::uvec z(n,arma::fill::zeros);
  for (int i=0;i<n;i++){
    if ((x(i)!=0)||(y(i)!=0)){
      z(i)=1;
    }
  }
  return z;
}

arma::uvec my_NAND(arma::rowvec x, arma::uvec y){
  int n =x.n_elem;
  arma::uvec z(n,arma::fill::zeros);
  for (int i=0;i<n;i++){
    if ((x(i)==0)||(y(i)==0)){
      z(i)=1;
    }
  }
  return z;
}

arma::uvec my_NAND(arma::rowvec x, arma::rowvec y){
  int n =x.n_elem;
  arma::uvec z(n,arma::fill::zeros);
  for (int i=0;i<n;i++){
    if ((x(i)==0)||(y(i)==0)){
      z(i)=1;
    }
  }
  return z;
}


int rcateg(Rcpp::NumericVector prob) {
  int i = sum(find(Rcpp::as<arma::vec>(Rcpp::RcppArmadillo::rmultinom(1, prob/sum(prob)))==1)-1);
  return i;
}
arma::vec rcateg(int n, Rcpp::NumericVector prob) {
  arma::vec m(n);
  for (int i=0; i<n; i++) {
    m(i) = rcateg(prob);
  }
  return m;
}

double logsumexp(double x,double y){//logsumexp(c(x,y))
  double offset=std::max(x,y);
  double s=exp(x-offset)+exp(y-offset);
  return log(s) + offset;
}
double logsumexp(double x,double y,double z){//logsumexp(c(x,y,z))
  double offset=std::max(std::max(x,y),z);
  double s=exp(x-offset)+exp(y-offset)+exp(z-offset);
  return log(s) + offset;
}
double logsumexp0(double x){//logsumexp(c(0,x))
  return logsumexp(x,0.0);
}

double logsumexp0(double x,double y){//logsumexp(c(0,x,y))
  return logsumexp(x,y,0.0);
}
