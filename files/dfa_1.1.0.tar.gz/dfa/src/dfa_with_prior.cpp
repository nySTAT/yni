// [[Rcpp::depends(RcppArmadillo)]]
#include <iostream> 
#include <RcppArmadillo.h>
#include <stdlib.h> 
#include "util.h"




// [[Rcpp::export]]
Rcpp::List dfa_with_prior(arma::mat y, arma::mat z, arma::mat P_fix1, arma::mat B_fix1, arma::mat C_fix1,arma::mat B_fix2, arma::mat C_fix2, int N = 1000, int burnin = 0, int thin = 1){//main function
  arma::uword i,j,k,it,jj,kk,nb,nc,np,ncp,ncm,nk;//iterators
  arma::uvec iv(1);
  
  int N2 = N / 10;
  int burnin2 = N2 / 2;
  int thin2 = thin;
  int Kmax=50;
  
  int fix1K = B_fix1.n_cols;
  int fix2K = B_fix2.n_cols;
  
  
  
  double a_beta=1;
  double b_beta=1;
  arma::vec pi = arma::ones<arma::vec>(3);
  double w_sig=10;
  double alpha=1;
  double w_sd=1.5;
  double zeta_sd=.8;
  double etap_sd=.8;
  double etam_sd=.8;
  double zeta_sig=100;
  double eta_sig=100;
  
  
  
  int n = y.n_rows;
  int q = y.n_cols;
  int p = z.n_cols;
  int effN = (N-burnin)/thin;
  arma::vec K(effN,arma::fill::zeros);
  arma::cube P = arma::zeros(n,Kmax,effN);
  arma::cube P_fix2 = arma::zeros(n,fix2K,effN);
  
  int K_old=1;
  arma::mat P_old=arma::zeros(n,Kmax);
  arma::mat P_fix2_old=arma::zeros(n,fix2K);
  
  arma::mat B_old=arma::zeros(p,Kmax);
  arma::mat B_fix1_old=B_fix1;
  arma::mat B_fix2_old=B_fix2;
  arma::mat C_old=arma::zeros(q,Kmax);
  arma::mat C_fix1_old=C_fix1;
  arma::mat C_fix2_old=C_fix2;
  arma::mat w_B_old(p,Kmax,arma::fill::ones);
  arma::mat w_B_fix1_old(p,fix1K,arma::fill::ones);
  arma::mat w_B_fix2_old(p,fix2K,arma::fill::ones);
  arma::mat w_Cp_old(q,Kmax,arma::fill::ones);
  arma::mat w_Cp_fix1_old(q,fix1K,arma::fill::ones);
  arma::mat w_Cp_fix2_old(q,fix2K,arma::fill::ones);
  arma::mat w_Cm_old(q,Kmax,arma::fill::ones);
  arma::mat w_Cm_fix1_old(q,fix1K,arma::fill::ones);
  arma::mat w_Cm_fix2_old(q,fix2K,arma::fill::ones);
  arma::vec zeta_old(p,arma::fill::zeros);
  arma::vec etap_old(q,arma::fill::zeros);
  arma::vec etam_old(q,arma::fill::zeros);
  zeta_old.fill(-5);
  etap_old.fill(-5);
  etam_old.fill(-5);
  
  double beta_old=.2;
  Rcpp::NumericVector gamma_old=Rcpp::NumericVector::create(0.1, 0.8, 0.1);
  arma::mat PB_kernel_old=arma::zeros(n,p);
  arma::mat PB_kernel_new=arma::zeros(n,p);
  arma::mat PCp_kernel_old=arma::zeros(n,q);
  arma::mat PCm_kernel_old=arma::zeros(n,q);
  arma::mat PCp_kernel_new=arma::zeros(n,q);
  arma::mat PCm_kernel_new=arma::zeros(n,q);
  arma::mat ll_z_old=arma::zeros(n,p);
  arma::mat ll_z_new=ll_z_old;
  arma::mat ll_y_old=arma::zeros(n,q);
  arma::mat ll_y_new=ll_y_old;
  arma::mat ll_y_new2=ll_y_old;
  for (i=0;i<n;i++){
    for (j=0;j<p;j++){
      PB_kernel_old(i,j)=sum(w_B_old.row(j)%P_old.row(i)%B_old.row(j))+zeta_old(j)+sum(w_B_fix1_old.row(j)%P_fix1.row(i)%B_fix1_old.row(j))+sum(w_B_fix2_old.row(j)%P_fix2_old.row(i)%B_fix2_old.row(j));
      ll_z_old(i,j)=-logsumexp0(PB_kernel_old(i,j))+z(i,j)*PB_kernel_old(i,j);
    }
    for (j=0;j<q;j++){
      PCp_kernel_old(i,j)=sum(w_Cp_old.row(j)%P_old.row(i)%(C_old.row(j)==1))+etap_old(j)+sum(w_Cp_fix1_old.row(j)%P_fix1.row(i)%(C_fix1_old.row(j)==1))+sum(w_Cp_fix2_old.row(j)%P_fix2_old.row(i)%(C_fix2_old.row(j)==1));
      PCm_kernel_old(i,j)=sum(w_Cm_old.row(j)%P_old.row(i)%(C_old.row(j)==-1))+etam_old(j)+sum(w_Cm_fix1_old.row(j)%P_fix1.row(i)%(C_fix1_old.row(j)==-1))+sum(w_Cm_fix2_old.row(j)%P_fix2_old.row(i)%(C_fix2_old.row(j)==-1));
      ll_y_old(i,j)=(y(i,j)==1)*PCp_kernel_old(i,j)+(y(i,j)==-1)*PCm_kernel_old(i,j)-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_old(i,j));
    }
  }
  double ll0=accu(ll_z_old)+accu(ll_y_old);
  arma::vec ll(N,arma::fill::zeros);
  int iter=0;
  double ac_w=0,ac_zeta=0,ac_eta=0;
  int count_w=0,count_zeta=0,count_eta=0;
  
  arma::rowvec sum_P(Kmax);
  arma::rowvec sum_P_fix2(fix2K);
  double log1,log0,logp,logp1,logm1,lr,w_new,w_p_new,w_m_new,zeta_new,etap_new,etam_new,d,d1,d2,d3;
  arma::uvec actB,actC,actP,actCp,actCm,actInd,inactP,inactInd;
  int K_new,tmp;
  arma::vec w_B_new(p);
  arma::vec w_Cp_new(q);
  arma::vec w_Cm_new(q);
  arma::vec B_new(p);
  arma::vec C_new(q);
  Rcpp::NumericVector logp_v(3);
  //MCMC starts here
  
  for (it=0;it<N;it++){
    Rcpp::checkUserInterrupt();
    
    //update P
    PB_kernel_new=PB_kernel_old;
    PCp_kernel_new=PCp_kernel_old;
    PCm_kernel_new=PCm_kernel_old;
    ll_z_new=ll_z_old;
    ll_y_new=ll_y_old;
    
    for (i=0;i<n;i++){
      iv(0)=i;
      //update P features with known disease
      if (fix2K>0){
        sum_P_fix2 = sum(P_fix2_old,0)-P_fix2_old.row(i);
        for (k=0;k<fix2K;k++){
          log1= log(sum_P_fix2(k)+alpha/fix2K);//finite IBP
          //log1= log(sum_P_fix2(k));
          log0= log(n-sum_P_fix2(k));
          actB = find(B_fix2_old.col(k)!=0); //active binary symtoms for disease k
          actC = find(C_fix2_old.col(k)!=0); //active categorical symtoms for disease k
          nb=actB.n_elem;
          nc=actC.n_elem;
          for (jj=0;jj<nb;jj++){
            j=actB(jj);
            if (P_fix2_old(i,k)==1){
              PB_kernel_new(i,j)=PB_kernel_old(i,j)-w_B_fix2_old(j,k);
              ll_z_new(i,j)=-logsumexp0(PB_kernel_new(i,j));
              if (z(i,j)==1){
                ll_z_new(i,j)+=PB_kernel_new(i,j);
              }
              log1+=ll_z_old(i,j);
              log0+=ll_z_new(i,j);
            }else{
              PB_kernel_new(i,j)=PB_kernel_old(i,j)+w_B_fix2_old(j,k);
              ll_z_new(i,j)=-logsumexp0(PB_kernel_new(i,j));
              if (z(i,j)==1){
                ll_z_new(i,j)+=PB_kernel_new(i,j);
              }
              log0+=ll_z_old(i,j);
              log1+=ll_z_new(i,j);
            }
          }
          for (jj=0;jj<nc;jj++){
            j=actC(jj);
            if (P_fix2_old(i,k)==1){
              if (C_fix2_old(j,k)==1){
                PCp_kernel_new(i,j)=PCp_kernel_old(i,j)-w_Cp_fix2_old(j,k);
                PCm_kernel_new(i,j)=PCm_kernel_old(i,j);
              }else{
                PCm_kernel_new(i,j)=PCm_kernel_old(i,j)-w_Cm_fix2_old(j,k);
                PCp_kernel_new(i,j)=PCp_kernel_old(i,j);
              }
              ll_y_new(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
              if (y(i,j)==1){
                ll_y_new(i,j)+=PCp_kernel_new(i,j);
              }else if(y(i,j)==-1){
                ll_y_new(i,j)+=PCm_kernel_new(i,j);
              }
              log1+=ll_y_old(i,j);
              log0+=ll_y_new(i,j);
            }else{
              if (C_fix2_old(j,k)==1){
                PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+w_Cp_fix2_old(j,k);
                PCm_kernel_new(i,j)=PCm_kernel_old(i,j);
              }else{
                PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+w_Cm_fix2_old(j,k);
                PCp_kernel_new(i,j)=PCp_kernel_old(i,j);
              }
              ll_y_new(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
              if (y(i,j)==1){
                ll_y_new(i,j)+=PCp_kernel_new(i,j);
              }else if(y(i,j)==-1){
                ll_y_new(i,j)+=PCm_kernel_new(i,j);
              }
              log0+=ll_y_old(i,j);
              log1+=ll_y_new(i,j);
            }
          }
          logp = log1 - logsumexp(log1, log0);
          if (log(R::runif(0,1)) < logp) {
            if (P_fix2_old(i,k)==0){
              P_fix2_old(i,k) = 1;
              PB_kernel_old.row(i)=PB_kernel_new.row(i);
              PCp_kernel_old.row(i)=PCp_kernel_new.row(i);
              PCm_kernel_old.row(i)=PCm_kernel_new.row(i);
              ll_y_old.row(i)=ll_y_new.row(i);
              ll_z_old.row(i)=ll_z_new.row(i);
            }else{
              PB_kernel_new.row(i)=PB_kernel_old.row(i);
              PCp_kernel_new.row(i)=PCp_kernel_old.row(i);
              PCm_kernel_new.row(i)=PCm_kernel_old.row(i);
              ll_y_new.row(i)=ll_y_old.row(i);
              ll_z_new.row(i)=ll_z_old.row(i);
            }
          } else {
            if (P_fix2_old(i,k)==1){
              P_fix2_old(i,k) = 0;
              PB_kernel_old.row(i)=PB_kernel_new.row(i);
              PCp_kernel_old.row(i)=PCp_kernel_new.row(i);
              PCm_kernel_old.row(i)=PCm_kernel_new.row(i);
              ll_y_old.row(i)=ll_y_new.row(i);
              ll_z_old.row(i)=ll_z_new.row(i);
            }else{
              PB_kernel_new.row(i)=PB_kernel_old.row(i);
              PCp_kernel_new.row(i)=PCp_kernel_old.row(i);
              PCm_kernel_new.row(i)=PCm_kernel_old.row(i);
              ll_y_new.row(i)=ll_y_old.row(i);
              ll_z_new.row(i)=ll_z_old.row(i);
            }
          }
        }
      }
      //update existing P features with latent disease
      if (K_old>0){
        sum_P = sum(P_old,0)-P_old.row(i);
        actP=find(sum_P>0); //active diseases
        np=actP.n_elem;
        inactP=find(sum_P==0); //inactive diseases
        P_old(iv,inactP).fill(0); //wipe out all inactive diseases
        for (kk=0;kk<np; kk++){
          k=actP(kk);
          log1= log(sum_P(k));
          log0= log(n-sum_P(k));
          actB = find(B_old.col(k)!=0); //active binary symtoms for disease k
          actC = find(C_old.col(k)!=0); //active categorical symtoms for disease k
          nb=actB.n_elem;
          nc=actC.n_elem;
          
          for (jj=0;jj<nb;jj++){
            j=actB(jj);
            if (P_old(i,k)==1){
              PB_kernel_new(i,j)=PB_kernel_old(i,j)-w_B_old(j,k);
              ll_z_new(i,j)=-logsumexp0(PB_kernel_new(i,j));
              if (z(i,j)==1){
                ll_z_new(i,j)+=PB_kernel_new(i,j);
              }
              log1+=ll_z_old(i,j);
              log0+=ll_z_new(i,j);
            }else{
              PB_kernel_new(i,j)=PB_kernel_old(i,j)+w_B_old(j,k);
              ll_z_new(i,j)=-logsumexp0(PB_kernel_new(i,j));
              if (z(i,j)==1){
                ll_z_new(i,j)+=PB_kernel_new(i,j);
              }
              log0+=ll_z_old(i,j);
              log1+=ll_z_new(i,j);
            }
          }
          
          for (jj=0;jj<nc;jj++){
            j=actC(jj);
            if (P_old(i,k)==1){
              if (C_old(j,k)==1){
                PCp_kernel_new(i,j)=PCp_kernel_old(i,j)-w_Cp_old(j,k);
                PCm_kernel_new(i,j)=PCm_kernel_old(i,j);
              }else{
                PCm_kernel_new(i,j)=PCm_kernel_old(i,j)-w_Cm_old(j,k);
                PCp_kernel_new(i,j)=PCp_kernel_old(i,j);
              }
              ll_y_new(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
              if (y(i,j)==1){
                ll_y_new(i,j)+=PCp_kernel_new(i,j);
              }else if(y(i,j)==-1){
                ll_y_new(i,j)+=PCm_kernel_new(i,j);
              }
              log1+=ll_y_old(i,j);
              log0+=ll_y_new(i,j);
            }else{
              if (C_old(j,k)==1){
                PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+w_Cp_old(j,k);
                PCm_kernel_new(i,j)=PCm_kernel_old(i,j);
              }else{
                PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+w_Cm_old(j,k);
                PCp_kernel_new(i,j)=PCp_kernel_old(i,j);
              }
              ll_y_new(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
              if (y(i,j)==1){
                ll_y_new(i,j)+=PCp_kernel_new(i,j);
              }else if(y(i,j)==-1){
                ll_y_new(i,j)+=PCm_kernel_new(i,j);
              }
              log0+=ll_y_old(i,j);
              log1+=ll_y_new(i,j);
            }
          }
          
          logp = log1 - logsumexp(log1, log0);
          if (log(R::runif(0,1)) < logp) {
            if (P_old(i,k)==0){
              P_old(i,k) = 1;
              PB_kernel_old.row(i)=PB_kernel_new.row(i);
              PCp_kernel_old.row(i)=PCp_kernel_new.row(i);
              PCm_kernel_old.row(i)=PCm_kernel_new.row(i);
              ll_y_old.row(i)=ll_y_new.row(i);
              ll_z_old.row(i)=ll_z_new.row(i);
            }else{
              PB_kernel_new.row(i)=PB_kernel_old.row(i);
              PCp_kernel_new.row(i)=PCp_kernel_old.row(i);
              PCm_kernel_new.row(i)=PCm_kernel_old.row(i);
              ll_y_new.row(i)=ll_y_old.row(i);
              ll_z_new.row(i)=ll_z_old.row(i);
            }
          } else {
            if (P_old(i,k)==1){
              P_old(i,k) = 0;
              PB_kernel_old.row(i)=PB_kernel_new.row(i);
              PCp_kernel_old.row(i)=PCp_kernel_new.row(i);
              PCm_kernel_old.row(i)=PCm_kernel_new.row(i);
              ll_y_old.row(i)=ll_y_new.row(i);
              ll_z_old.row(i)=ll_z_new.row(i);
            }else{
              PB_kernel_new.row(i)=PB_kernel_old.row(i);
              PCp_kernel_new.row(i)=PCp_kernel_old.row(i);
              PCm_kernel_new.row(i)=PCm_kernel_old.row(i);
              ll_y_new.row(i)=ll_y_old.row(i);
              ll_z_new.row(i)=ll_z_old.row(i);
            }
          }
        }
      }
      
      //update new features with latent disease
      inactInd=find(sum(P_old,0)==0);
      K_old=Kmax-inactInd.n_elem;
      if (K_old<Kmax){
        K_new=R::rbinom(1,alpha/n);//almost the same as rpoi(1,alpha/n) except it can't get 2 or larger; but it's easier for bookkeeping
        if (K_new==1){
          B_new=Rcpp::rbinom(p,1,beta_old);
          actB = find(B_new!=0);
          nb=actB.n_elem;
          C_new=rcateg(q,gamma_old);
          actCp = find(C_new==1);
          ncp=actCp.n_elem;
          actCm = find(C_new==-1);
          ncm=actCm.n_elem;
          w_B_new.fill(0);
          w_Cp_new.fill(0);
          w_Cm_new.fill(0);
          if (nb+ncp+ncm>0){
            lr=0;
            for (jj=0;jj<nb;jj++){
              j=actB(jj);
              w_B_new(j)=R::rgamma(1.0,w_sig);
              //w_B_new(j)=exp(R::rnorm(0,w_sig));
              PB_kernel_new(i,j)=PB_kernel_old(i,j)+w_B_new(j);
              ll_z_new(i,j)=-logsumexp0(PB_kernel_new(i,j))+z(i,j)*PB_kernel_new(i,j);
              lr += ll_z_new(i,j)-ll_z_old(i,j);
            }
            
            for (jj=0;jj<ncp;jj++){
              j=actCp(jj);
              w_Cp_new(j)=R::rgamma(1.0,w_sig);
              //w_Cp_new(j)=exp(R::rnorm(0,w_sig));
              PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+w_Cp_new(j);
              PCm_kernel_new(i,j)=PCm_kernel_old(i,j);
              ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_new(i,j)+(y(i,j)==-1)*PCm_kernel_new(i,j)-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
              lr += ll_y_new(i,j)-ll_y_old(i,j);
            }
            for (jj=0;jj<ncm;jj++){
              j=actCm(jj);
              w_Cm_new(j)=R::rgamma(1.0,w_sig);
              //w_Cm_new(j)=exp(R::rnorm(0,w_sig));
              PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+w_Cm_new(j);
              PCp_kernel_new(i,j)=PCp_kernel_old(i,j);
              ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_new(i,j)+(y(i,j)==-1)*PCm_kernel_new(i,j)-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
              lr += ll_y_new(i,j)-ll_y_old(i,j);
            }
            lr += R::dpois(K_new,alpha/n,1)-R::dpois(0,alpha/n,1)+R::dbinom(0,1,alpha/n,1)-R::dbinom(K_new,1,alpha/n,1);
            if (lr > log(R::runif(0,1))) {
              kk=inactInd(0);
              K_old++;
              w_B_old.col(kk)=w_B_new;
              w_Cp_old.col(kk)=w_Cp_new;
              w_Cm_old.col(kk)=w_Cm_new;
              B_old.col(kk)=B_new;
              C_old.col(kk)=C_new;
              PB_kernel_old.row(i)=PB_kernel_new.row(i);
              PCp_kernel_old.row(i)=PCp_kernel_new.row(i);
              PCm_kernel_old.row(i)=PCm_kernel_new.row(i);
              P_old(i,kk)=1;
              ll_y_old.row(i)=ll_y_new.row(i);
              ll_z_old.row(i)=ll_z_new.row(i);
            }else{
              PB_kernel_new.row(i)=PB_kernel_old.row(i);
              PCp_kernel_new.row(i)=PCp_kernel_old.row(i);
              PCm_kernel_new.row(i)=PCm_kernel_old.row(i);
              ll_y_new.row(i)=ll_y_old.row(i);
              ll_z_new.row(i)=ll_z_old.row(i);
            }
          }
        }
      }
    }
    Rcpp::checkUserInterrupt();
    
    ll_y_new2=ll_y_old;
    actInd=find(sum(P_old,0)>0);
    nk=actInd.n_elem;
    //update B
    for (j=0;j<p;j++){
      for (kk=0;kk<nk;kk++){
        k=actInd(kk);
        log1=log(beta_old);
        log0=log(1-beta_old);
        if (B_old(j,k)==1){//propose to turn off
          for (i=0;i<n;i++){
            log1+=ll_z_old(i,j);
            PB_kernel_new(i,j)=PB_kernel_old(i,j)-w_B_old(j,k)*P_old(i,k);
            ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
            log0+=ll_z_new(i,j);
          }
        }else{//propose to turn on
          w_new=R::rgamma(1.0,w_sig);
          //w_new=exp(R::rnorm(0,w_sig));
          for (i=0;i<n;i++){
            PB_kernel_new(i,j)=PB_kernel_old(i,j)+w_new*P_old(i,k);
            ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
            log0+=ll_z_old(i,j);
            log1+=ll_z_new(i,j);
          }
        }
        //draw binomial
        logp = log1 - logsumexp(log1, log0);
        if (log(R::runif(0,1)) < logp){
          if (B_old(j,k)==0){
            B_old(j,k)=1;
            PB_kernel_old.col(j)=PB_kernel_new.col(j);
            ll_z_old.col(j)=ll_z_new.col(j);
            w_B_old(j,k)=w_new;
          }
        }else{
          if (B_old(j,k)==1){
            B_old(j,k)=0;
            PB_kernel_old.col(j)=PB_kernel_new.col(j);
            ll_z_old.col(j)=ll_z_new.col(j);
            w_B_old(j,k)=0;
          }
        }
      }
    }
    //update C
    for (j=0;j<q;j++){
      for (kk=0;kk<nk;kk++){
        k=actInd(kk);
        logp1=log(gamma_old(2));//log prob +1
        log0=log(gamma_old(1));//0
        logm1=log(gamma_old(0));//-1
        if (C_old(j,k)==1){
          w_new=R::rgamma(1.0,w_sig);
          //w_new=exp(R::rnorm(0,w_sig));
          for (i=0;i<n;i++){
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)-P_old(i,k)*w_Cp_old(j,k);//C: 1 -> 0,-1;
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+P_old(i,k)*w_new;//C: 1 -> -1;
            logp1+=ll_y_old(i,j);
            ll_y_new(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_old(i,j));
            ll_y_new2(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
            if (y(i,j)==1){
              ll_y_new(i,j)+=PCp_kernel_new(i,j);
              ll_y_new2(i,j)+=PCp_kernel_new(i,j);
            }else if (y(i,j)==-1){
              ll_y_new(i,j)+=PCm_kernel_old(i,j);
              ll_y_new2(i,j)+=PCm_kernel_new(i,j);
            }
            log0+=ll_y_new(i,j);
            logm1+=ll_y_new2(i,j);
          }
        }else if (C_old(j,k)==-1){
          w_new=R::rgamma(1.0,w_sig);
          //w_new=exp(R::rnorm(0,w_sig));
          for (i=0;i<n;i++){
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)-P_old(i,k)*w_Cm_old(j,k);//C: -1 -> 0,1;
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+P_old(i,k)*w_new;//C: -1 -> 1;
            ll_y_new2(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
            ll_y_new(i,j)=-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_new(i,j));
            logm1+=ll_y_old(i,j);
            if (y(i,j)==1){
              ll_y_new2(i,j)+=PCp_kernel_new(i,j);
              ll_y_new(i,j)+=PCp_kernel_old(i,j);
            }else if (y(i,j)==-1){
              ll_y_new2(i,j)+=PCm_kernel_new(i,j);
              ll_y_new(i,j)+=PCm_kernel_new(i,j);
            }
            logp1+=ll_y_new2(i,j);
            log0+=ll_y_new(i,j);
          }
        }else{//C_old(j,k)==0
          w_p_new=R::rgamma(1.0,w_sig);
          w_m_new=R::rgamma(1.0,w_sig);
          //w_p_new=exp(R::rnorm(0,w_sig));
          //w_m_new=exp(R::rnorm(0,w_sig));
          for (i=0;i<n;i++){
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+P_old(i,k)*w_m_new;//C: 0 -> -1;
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+P_old(i,k)*w_p_new;//C: 0 -> 1;
            ll_y_new2(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_old(i,j));
            log0+=ll_y_old(i,j);
            ll_y_new(i,j)=-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_new(i,j));
            if (y(i,j)==1){
              ll_y_new2(i,j)+=PCp_kernel_new(i,j);
              ll_y_new(i,j)+=PCp_kernel_old(i,j);
            }else if (y(i,j)==-1){
              ll_y_new2(i,j)+=PCm_kernel_old(i,j);
              ll_y_new(i,j)+=PCm_kernel_new(i,j);
            }
            logp1+=ll_y_new2(i,j);
            logm1+=ll_y_new(i,j);
          }
        }
        logp_v(0)=logm1;logp_v(1)=log0;logp_v(2)=logp1;
        logp_v= logp_v-logsumexp(logm1,log0,logp1);
        tmp=rcateg(exp(logp_v));
        if (tmp==0){
          if (C_old(j,k)==1){
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
            w_Cp_old(j,k)=0;
          }else if(C_old(j,k)==-1){
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
            w_Cm_old(j,k)=0;
          }
        }else if (tmp==1){
          if (C_old(j,k)==0){
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new2.col(j);
            w_Cp_old(j,k)=w_p_new;
          }else if (C_old(j,k)==-1){
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new2.col(j);
            w_Cp_old(j,k)=w_new;
            w_Cm_old(j,k)=0;
          }
        }else{//tmp==-1
          if (C_old(j,k)==1){
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new2.col(j);
            w_Cm_old(j,k)=w_new;
            w_Cp_old(j,k)=0;
          }else if (C_old(j,k)==0){
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
            w_Cm_old(j,k)=w_m_new;
          }
        }
        C_old(j,k)=tmp;
      }
    }
    //update w_B;
    for (j=0;j<p;j++){
      for (kk=0;kk<nk;kk++){
        k=actInd(kk);
        if (B_old(j,k)==1){
          count_w++;
          w_new=R::rlnorm(log(pow(w_B_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_B_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_B_old(j,k),2)+1)));
          for (i=0;i<n;i++){
            PB_kernel_new(i,j)=PB_kernel_old(i,j)+(w_new-w_B_old(j,k))*P_old(i,k);
            ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
          }
          lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_B_old(j,k),1,w_sig,1)+R::dlnorm(w_B_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_B_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_B_old(j,k),2)+1)),1);
          //lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_B_old(j,k)),0,w_sig,1)+R::dlnorm(w_B_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_B_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_B_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w++;
            w_B_old(j,k)=w_new;
            PB_kernel_old.col(j)=PB_kernel_new.col(j);
            ll_z_old.col(j)=ll_z_new.col(j);
          }
        }
      }
    }
    //update w_C;
    for (j=0;j<q;j++){
      for (kk=0;kk<nk;kk++){
        k=actInd(kk);
        if (C_old(j,k)==1){
          count_w++;
          w_new=R::rlnorm(log(pow(w_Cp_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cp_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_old(j,k),2)+1)));
          for (i=0;i<n;i++){
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+(w_new-w_Cp_old(j,k))*P_old(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_new(i,j)+(y(i,j)==-1)*PCm_kernel_old(i,j)-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_old(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cp_old(j,k),1,w_sig,1)+R::dlnorm(w_Cp_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cp_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_old(j,k),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cp_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cp_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cp_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w++;
            w_Cp_old(j,k)=w_new;
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }else if (C_old(j,k)==-1){
          count_w++;
          w_new=R::rlnorm(log(pow(w_Cm_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cm_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_old(j,k),2)+1)));
          for (i=0;i<n;i++){
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+(w_new-w_Cm_old(j,k))*P_old(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_old(i,j)+(y(i,j)==-1)*PCm_kernel_new(i,j)-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_new(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cm_old(j,k),1,w_sig,1)+R::dlnorm(w_Cm_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cm_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_old(j,k),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cm_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cm_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cm_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w++;
            w_Cm_old(j,k)=w_new;
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }
      }
    }
    
    ll_y_new2=ll_y_old;
    actInd=find(sum(P_fix2_old,0)>0);
    nk=actInd.n_elem;
    
    
    
    //update w_B_fix2;
    for (j=0;j<p;j++){
      for (kk=0;kk<nk;kk++){
        k=actInd(kk);
        if (B_fix2_old(j,k)==1){
          count_w++;
          w_new=R::rlnorm(log(pow(w_B_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_B_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix2_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PB_kernel_new(i,j)=PB_kernel_old(i,j)+(w_new-w_B_fix2_old(j,k))*P_fix2_old(i,k);
            ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
          }
          lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_B_fix2_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_B_fix2_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_B_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix2_old(j,k)+pow(10,-4),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w++;
            w_B_fix2_old(j,k)=w_new;
            PB_kernel_old.col(j)=PB_kernel_new.col(j);
            ll_z_old.col(j)=ll_z_new.col(j);
          }
        }
      }
    }
    
    //update w_C_fix2;
    for (j=0;j<q;j++){
      for (kk=0;kk<nk;kk++){
        k=actInd(kk);
        if (C_fix2_old(j,k)==1){
          count_w++;
          w_new=R::rlnorm(log(pow(w_Cp_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix2_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+(w_new-w_Cp_fix2_old(j,k))*P_fix2_old(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_new(i,j)+(y(i,j)==-1)*PCm_kernel_old(i,j)-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_old(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cp_fix2_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_Cp_fix2_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix2_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cp_fix2_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cp_fix2_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_fix2_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix2_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix2_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w++;
            w_Cp_fix2_old(j,k)=w_new;
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }else if (C_fix2_old(j,k)==-1){
          count_w++;
          w_new=R::rlnorm(log(pow(w_Cm_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix2_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+(w_new-w_Cm_fix2_old(j,k))*P_fix2_old(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_old(i,j)+(y(i,j)==-1)*PCm_kernel_new(i,j)-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_new(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cm_fix2_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_Cm_fix2_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix2_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cm_fix2_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cm_fix2_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_fix2_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix2_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix2_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w++;
            w_Cm_fix2_old(j,k)=w_new;
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }
      }
    }
    
    //update w_B_fix1;
    for (j=0;j<p;j++){
      for (k=0;k<fix1K;k++){
        if (B_fix1_old(j,k)==1){
          count_w++;
          w_new=R::rlnorm(log(pow(w_B_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_B_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix1_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PB_kernel_new(i,j)=PB_kernel_old(i,j)+(w_new-w_B_fix1_old(j,k))*P_fix1(i,k);
            ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
          }
          lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_B_fix1_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_B_fix1_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_B_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix1_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_B_fix1_old(j,k)),0,w_sig,1)+R::dlnorm(w_B_fix1_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_fix1_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_B_fix1_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix1_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w++;
            w_B_fix1_old(j,k)=w_new;
            PB_kernel_old.col(j)=PB_kernel_new.col(j);
            ll_z_old.col(j)=ll_z_new.col(j);
          }
        }
      }
    }
    
    //update w_C_fix1;
    for (j=0;j<q;j++){
      for (k=0;k<fix1K;k++){
        if (C_fix1_old(j,k)==1){
          count_w++;
          w_new=R::rlnorm(log(pow(w_Cp_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix1_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+(w_new-w_Cp_fix1_old(j,k))*P_fix1(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_new(i,j)+(y(i,j)==-1)*PCm_kernel_old(i,j)-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_old(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cp_fix1_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_Cp_fix1_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix1_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cp_fix1_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cp_fix1_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_fix1_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix1_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix1_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w++;
            w_Cp_fix1_old(j,k)=w_new;
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }else if (C_fix1_old(j,k)==-1){
          count_w++;
          w_new=R::rlnorm(log(pow(w_Cm_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix1_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+(w_new-w_Cm_fix1_old(j,k))*P_fix1(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_old(i,j)+(y(i,j)==-1)*PCm_kernel_new(i,j)-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_new(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cm_fix1_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_Cm_fix1_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix1_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cm_fix1_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cm_fix1_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_fix1_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix1_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix1_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w++;
            w_Cm_fix1_old(j,k)=w_new;
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }
      }
    }
    
    //update zeta
    for (j=0;j<p;j++){
      count_zeta++;
      zeta_new=R::rnorm(zeta_old(j),zeta_sd);
      //zeta_new=-5;//!!!!
      for (i=0;i<n;i++){
        PB_kernel_new(i,j)=PB_kernel_old(i,j)+zeta_new-zeta_old(j);
        ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
      }
      lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dnorm4(zeta_new,log(1.0/99),zeta_sig,1)-R::dnorm4(zeta_old(j),log(1.0/99),zeta_sig,1);
      if (lr>log(R::runif(0,1))){
        ac_zeta++;
        zeta_old(j)=zeta_new;
        PB_kernel_old.col(j)=PB_kernel_new.col(j);
        ll_z_old.col(j)=ll_z_new.col(j);
      }
    }
    //update etap, etam
    for (j=0;j<q;j++){
      count_eta++;
      etap_new = R::rnorm(etap_old(j),etap_sd);
      etam_new = R::rnorm(etam_old(j),etam_sd);
      //etap_new=-5;//!!!!
      //etam_new=-5;//!!!!
      for (i=0;i<n;i++){
        PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+etap_new-etap_old(j);
        PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+etam_new-etam_old(j);
        ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_new(i,j)+(y(i,j)==-1)*PCm_kernel_new(i,j)-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
      }
      lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(etap_new,log(1.0/198),eta_sig,1)-R::dnorm4(etap_old(j),log(1.0/198),eta_sig,1)+R::dnorm4(etam_new,log(1.0/198),eta_sig,1)-R::dnorm4(etam_old(j),log(1.0/198),eta_sig,1);
      if (lr>log(R::runif(0,1))){
        ac_eta++;
        etap_old(j)=etap_new;
        etam_old(j)=etam_new;
        PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
        PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
        ll_y_old.col(j)=ll_y_new.col(j);
      }
    }
    //remove empty features
    inactInd=find(my_NAND(sum(P_old,0),my_OR(sum(B_old,0),sum(abs(C_old),0))));//double check
    P_old.cols(inactInd).fill(0);
    B_old.cols(inactInd).fill(0);
    C_old.cols(inactInd).fill(0);
    w_B_old.cols(inactInd).fill(0);
    w_Cp_old.cols(inactInd).fill(0);
    w_Cm_old.cols(inactInd).fill(0);
    K_old=Kmax-inactInd.n_elem;
    inactInd=find(sum(P_fix2_old,0)==0);
    B_fix2_old.cols(inactInd)=B_fix2.cols(inactInd);
    C_fix2_old.cols(inactInd)=C_fix2.cols(inactInd);
    w_B_fix2_old.cols(inactInd).fill(0);
    w_Cp_fix2_old.cols(inactInd).fill(0);
    w_Cm_fix2_old.cols(inactInd).fill(0);
    
    //update beta
    d=accu(B_old);
    d1=accu(C_old==-1);
    d3=accu(C_old==1);
    d2=K_old*q-d1-d3;
    d1+=pi(0);
    d2+=pi(1);
    d3+=pi(2);
    
    beta_old=R::rbeta(a_beta+d,b_beta+p*K_old-d);
    //update gamma
    gamma_old(0)=R::rgamma(d1,1);
    gamma_old(1)=R::rgamma(d2,1);
    gamma_old(2)=R::rgamma(d3,1);
    gamma_old=gamma_old/sum(gamma_old);
    
    ll(it)=accu(ll_z_old)+accu(ll_y_old);
    if (it%1000==0){
      Rcpp::Rcout<<"MCMC: "<<it<<"/"<<N<<" completed"<<std::endl;
    }
    //write
    if (it>=burnin&&it%thin==0){
      P.slice(iter)=P_old;
      P_fix2.slice(iter)=P_fix2_old;
      K(iter)=K_old;
      iter++;
    }
  }//end of MCMC
  //K.save("K.csv",csv_ascii);
  ac_w/=count_w;
  ac_zeta/=count_zeta;
  ac_eta/=count_eta;
  arma::vec K_freq=K_FREQ(K);
  arma::uword K_est=index_max(K_freq);
  if (K_est==0){
    Rcpp::Rcout<<"Program stops because K_est=0. No resutls returned."<<std::endl;
    return Rcpp::List::create(Rcpp::Named("K")=K,Rcpp::Named("K_est")=K_est,Rcpp::Named("ll")=ll,Rcpp::Named("ll0")=ll0,Rcpp::Named("P")=P,Rcpp::Named("P_fix2")=P_fix2,Rcpp::Named("ac_w")=ac_w,Rcpp::Named("ac_zeta")=ac_zeta,Rcpp::Named("ac_eta")=ac_eta);
  }
  arma::uvec K_ind=find(K==K_est);
  
  arma::cube P_tmp(n,Kmax,K_ind.n_elem);
  for (i=0;i<K_ind.n_elem;i++){
    P_tmp.slice(i)=P.slice(K_ind(i));
  }
  double K_choose = MAP(P_tmp);
  
  arma::mat P_est = P_tmp.slice(K_choose);
  
  P_est = P_est.cols(sort_index(sum(P_est,0),"descend"));
  
  P_est= P_est.cols(0,K_est-1);
  //P_est=P_est.cols(find(sum(P_est,0)>=.05*n));//keep diseases with at least 5% patients
  //K_est=P_est.n_cols;
  arma::mat P_fix2_est;
  if (fix2K>0){
    K_choose = MAP(P_fix2);
    P_fix2_est = P_fix2.slice(K_choose);
    //P_fix2_est=P_fix2_est.cols(sort_index(sum(P_fix2_est,0),"descend"));
    // if (fix2K>1){
    //   P_fix2_est = P_fix2_est.cols(sort_index(sum(P_fix2_est,0),"descend"));
    //   P_fix2_est = P_fix2_est.cols(sum(P_fix2_est,0)>=.05*n);//keep diseases with at least 5% patients
    // }else if(accu(P_fix2_est)<.05*n){
    //   P_fix2_est.fill(0);//keep diseases with at least 5% patients
    // }
  }
  
  
  
  int effN2 = (N2-burnin2)/thin2;
  arma::cube B=arma::zeros(p,K_est,effN2);
  arma::cube B_fix1_save=arma::zeros(p,fix1K,effN2);
  arma::cube B_fix2_save=arma::zeros(p,fix2K,effN2);
  arma::cube C=arma::zeros(q,K_est,effN2);
  arma::cube C_fix1_save=arma::zeros(q,fix1K,effN2);
  arma::cube C_fix2_save=arma::zeros(q,fix2K,effN2);
  arma::vec beta(effN2,arma::fill::zeros);
  arma::mat gamma=arma::zeros(3,effN2);
  arma::cube w_B=arma::zeros(p,K_est,effN2);
  arma::cube w_B_fix1=arma::zeros(p,fix1K,effN2);
  arma::cube w_B_fix2=arma::zeros(p,fix2K,effN2);
  arma::cube w_Cp=arma::zeros(q,K_est,effN2);
  arma::cube w_Cp_fix1=arma::zeros(q,fix1K,effN2);
  arma::cube w_Cp_fix2=arma::zeros(q,fix2K,effN2);
  arma::cube w_Cm=arma::zeros(q,K_est,effN2);
  arma::cube w_Cm_fix1=arma::zeros(q,fix1K,effN2);
  arma::cube w_Cm_fix2=arma::zeros(q,fix2K,effN2);
  arma::mat zeta=arma::zeros(p,effN2);
  arma::mat etap=arma::zeros(q,effN2);
  arma::mat etam=arma::zeros(q,effN2);
  
  
  B_fix1_old=B_fix1;
  B_fix2_old=B_fix2;
  C_fix1_old=C_fix1;
  C_fix2_old=C_fix2;
  
  B_old=arma::zeros(p,K_est);
  C_old=arma::zeros(q,K_est);
  w_B_old=arma::ones(p,K_est);
  w_Cp_old=arma::ones(q,K_est);
  w_Cm_old=arma::ones(q,K_est);
  for (i=0;i<n;i++){
    for (j=0;j<p;j++){
      PB_kernel_old(i,j)=sum(w_B_old.row(j)%P_est.row(i)%B_old.row(j))+zeta_old(j)+sum(w_B_fix1_old.row(j)%P_fix1.row(i)%B_fix1_old.row(j))+sum(w_B_fix2_old.row(j)%P_fix2_est.row(i)%B_fix2_old.row(j));
      ll_z_old(i,j)=-logsumexp0(PB_kernel_old(i,j))+z(i,j)*PB_kernel_old(i,j);
    }
    for (j=0;j<q;j++){
      PCp_kernel_old(i,j)=sum(w_Cp_old.row(j)%P_est.row(i)%(C_old.row(j)==1))+etap_old(j)+sum(w_Cp_fix1_old.row(j)%P_fix1.row(i)%(C_fix1_old.row(j)==1))+sum(w_Cp_fix2_old.row(j)%P_fix2_est.row(i)%(C_fix2_old.row(j)==1));
      PCm_kernel_old(i,j)=sum(w_Cm_old.row(j)%P_est.row(i)%(C_old.row(j)==-1))+etam_old(j)+sum(w_Cm_fix1_old.row(j)%P_fix1.row(i)%(C_fix1_old.row(j)==-1))+sum(w_Cm_fix2_old.row(j)%P_fix2_est.row(i)%(C_fix2_old.row(j)==-1));
      ll_y_old(i,j)=(y(i,j)==1)*PCp_kernel_old(i,j)+(y(i,j)==-1)*PCm_kernel_old(i,j)-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_old(i,j));
    }
  }
  arma::vec ll2(N2,arma::fill::zeros);
  iter=0;
  double ac_w2=0,ac_zeta2=0,ac_eta2=0;
  int count_w2=0,count_zeta2=0,count_eta2=0;
  actInd=find(sum(P_fix2_est,0)>0);
  nk=actInd.n_elem;
  
  for (it=0;it<N2;it++){
    Rcpp::checkUserInterrupt();
    
    PB_kernel_new=PB_kernel_old;
    PCp_kernel_new=PCp_kernel_old;
    PCm_kernel_new=PCm_kernel_old;
    ll_z_new=ll_z_old;
    ll_y_new=ll_y_old;
    ll_y_new2=ll_y_old;
    //update B
    for (j=0;j<p;j++){
      for (k=0;k<K_est;k++){
        log1=log(beta_old);
        log0=log(1-beta_old);
        if (B_old(j,k)==1){//propose to turn off
          for (i=0;i<n;i++){
            log1+=ll_z_old(i,j);
            PB_kernel_new(i,j)=PB_kernel_old(i,j)-w_B_old(j,k)*P_est(i,k);
            ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
            log0+=ll_z_new(i,j);
          }
        }else{//propose to turn on
          w_new=R::rgamma(1.0,w_sig);
          //w_new=exp(R::rnorm(0,w_sig));
          for (i=0;i<n;i++){
            PB_kernel_new(i,j)=PB_kernel_old(i,j)+w_new*P_est(i,k);
            ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
            log0+=ll_z_old(i,j);
            log1+=ll_z_new(i,j);
          }
        }
        //draw binomial
        logp = log1 - logsumexp(log1, log0);
        if (log(R::runif(0,1)) < logp){
          if (B_old(j,k)==0){
            B_old(j,k)=1;
            PB_kernel_old.col(j)=PB_kernel_new.col(j);
            ll_z_old.col(j)=ll_z_new.col(j);
            w_B_old(j,k)=w_new;
          }
        }else{
          if (B_old(j,k)==1){
            B_old(j,k)=0;
            PB_kernel_old.col(j)=PB_kernel_new.col(j);
            ll_z_old.col(j)=ll_z_new.col(j);
            w_B_old(j,k)=0;
          }
        }
      }
    }
    //update C
    for (j=0;j<q;j++){
      for (k=0;k<K_est;k++){
        logp1=log(gamma_old(2));//log prob +1
        log0=log(gamma_old(1));//0
        logm1=log(gamma_old(0));//-1
        if (C_old(j,k)==1){
          w_new=R::rgamma(1.0,w_sig);
          //w_new=exp(R::rnorm(0,w_sig));
          for (i=0;i<n;i++){
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)-P_est(i,k)*w_Cp_old(j,k);//C: 1 -> 0,-1;
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+P_est(i,k)*w_new;//C: 1 -> -1;
            logp1+=ll_y_old(i,j);
            ll_y_new(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_old(i,j));
            ll_y_new2(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
            if (y(i,j)==1){
              ll_y_new(i,j)+=PCp_kernel_new(i,j);
              ll_y_new2(i,j)+=PCp_kernel_new(i,j);
            }else if (y(i,j)==-1){
              ll_y_new(i,j)+=PCm_kernel_old(i,j);
              ll_y_new2(i,j)+=PCm_kernel_new(i,j);
            }
            log0+=ll_y_new(i,j);
            logm1+=ll_y_new2(i,j);
          }
        }else if (C_old(j,k)==-1){
          w_new=R::rgamma(1.0,w_sig);
          //w_new=exp(R::rnorm(0,w_sig));
          for (i=0;i<n;i++){
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)-P_est(i,k)*w_Cm_old(j,k);//C: -1 -> 0,1;
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+P_est(i,k)*w_new;//C: -1 -> 1;
            ll_y_new2(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
            ll_y_new(i,j)=-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_new(i,j));
            logm1+=ll_y_old(i,j);
            if (y(i,j)==1){
              ll_y_new2(i,j)+=PCp_kernel_new(i,j);
              ll_y_new(i,j)+=PCp_kernel_old(i,j);
            }else if (y(i,j)==-1){
              ll_y_new2(i,j)+=PCm_kernel_new(i,j);
              ll_y_new(i,j)+=PCm_kernel_new(i,j);
            }
            logp1+=ll_y_new2(i,j);
            log0+=ll_y_new(i,j);
          }
        }else{//C_old(j,k)==0
          w_p_new=R::rgamma(1.0,w_sig);
          w_m_new=R::rgamma(1.0,w_sig);
          //w_p_new=exp(R::rnorm(0,w_sig));
          //w_m_new=exp(R::rnorm(0,w_sig));
          for (i=0;i<n;i++){
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+P_est(i,k)*w_m_new;//C: 0 -> -1;
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+P_est(i,k)*w_p_new;//C: 0 -> 1;
            ll_y_new2(i,j)=-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_old(i,j));
            log0+=ll_y_old(i,j);
            ll_y_new(i,j)=-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_new(i,j));
            if (y(i,j)==1){
              ll_y_new2(i,j)+=PCp_kernel_new(i,j);
              ll_y_new(i,j)+=PCp_kernel_old(i,j);
            }else if (y(i,j)==-1){
              ll_y_new2(i,j)+=PCm_kernel_old(i,j);
              ll_y_new(i,j)+=PCm_kernel_new(i,j);
            }
            logp1+=ll_y_new2(i,j);
            logm1+=ll_y_new(i,j);
          }
        }
        logp_v(0)=logm1;logp_v(1)=log0;logp_v(2)=logp1;
        logp_v= logp_v-logsumexp(logm1,log0,logp1);
        tmp=rcateg(exp(logp_v));
        if (tmp==0){
          if (C_old(j,k)==1){
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
            w_Cp_old(j,k)=0;
          }else if(C_old(j,k)==-1){
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
            w_Cm_old(j,k)=0;
          }
        }else if (tmp==1){
          if (C_old(j,k)==0){
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new2.col(j);
            w_Cp_old(j,k)=w_p_new;
          }else if (C_old(j,k)==-1){
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new2.col(j);
            w_Cp_old(j,k)=w_new;
            w_Cm_old(j,k)=0;
          }
        }else{//tmp==-1
          if (C_old(j,k)==1){
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new2.col(j);
            w_Cm_old(j,k)=w_new;
            w_Cp_old(j,k)=0;
          }else if (C_old(j,k)==0){
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
            w_Cm_old(j,k)=w_m_new;
          }
        }
        C_old(j,k)=tmp;
      }
    }
    
    //update w_B;
    for (j=0;j<p;j++){
      for (k=0;k<K_est;k++){
        if (B_old(j,k)==1){
          count_w2++;
          w_new=R::rlnorm(log(pow(w_B_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_B_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_B_old(j,k),2)+1)));
          for (i=0;i<n;i++){
            PB_kernel_new(i,j)=PB_kernel_old(i,j)+(w_new-w_B_old(j,k))*P_est(i,k);
            ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
          }
          lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_B_old(j,k),1,w_sig,1)+R::dlnorm(w_B_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_B_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_B_old(j,k),2)+1)),1);
          //lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_B_old(j,k)),0,w_sig,1)+R::dlnorm(w_B_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_B_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_B_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w2++;
            w_B_old(j,k)=w_new;
            PB_kernel_old.col(j)=PB_kernel_new.col(j);
            ll_z_old.col(j)=ll_z_new.col(j);
          }
        }
      }
    }
    //update w_C;
    for (j=0;j<q;j++){
      for (k=0;k<K_est;k++){
        if (C_old(j,k)==1){
          count_w2++;
          w_new=R::rlnorm(log(pow(w_Cp_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cp_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_old(j,k),2)+1)));
          for (i=0;i<n;i++){
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+(w_new-w_Cp_old(j,k))*P_est(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_new(i,j)+(y(i,j)==-1)*PCm_kernel_old(i,j)-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_old(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cp_old(j,k),1,w_sig,1)+R::dlnorm(w_Cp_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cp_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_old(j,k),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cp_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cp_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cp_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w2++;
            w_Cp_old(j,k)=w_new;
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }else if (C_old(j,k)==-1){
          count_w2++;
          w_new=R::rlnorm(log(pow(w_Cm_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cm_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_old(j,k),2)+1)));
          for (i=0;i<n;i++){
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+(w_new-w_Cm_old(j,k))*P_est(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_old(i,j)+(y(i,j)==-1)*PCm_kernel_new(i,j)-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_new(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cm_old(j,k),1,w_sig,1)+R::dlnorm(w_Cm_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cm_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_old(j,k),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cm_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cm_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cm_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w2++;
            w_Cm_old(j,k)=w_new;
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }
      }
    }
    
    ll_y_new2=ll_y_old;
    
    //update w_B_fix2;
    for (j=0;j<p;j++){
      for (kk=0;kk<nk;kk++){
        k=actInd(kk);
        if (B_fix2_old(j,k)==1){
          count_w2++;
          w_new=R::rlnorm(log(pow(w_B_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_B_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix2_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PB_kernel_new(i,j)=PB_kernel_old(i,j)+(w_new-w_B_fix2_old(j,k))*P_fix2_est(i,k);
            ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
          }
          lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_B_fix2_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_B_fix2_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_B_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix2_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_B_fix2_old(j,k)),0,w_sig,1)+R::dlnorm(w_B_fix2_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_fix2_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_B_fix2_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix2_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w2++;
            w_B_fix2_old(j,k)=w_new;
            PB_kernel_old.col(j)=PB_kernel_new.col(j);
            ll_z_old.col(j)=ll_z_new.col(j);
          }
        }
      }
    }
    //update w_C_fix2;
    for (j=0;j<q;j++){
      for (kk=0;kk<nk;kk++){
        k=actInd(kk);
        if (C_fix2_old(j,k)==1){
          count_w2++;
          w_new=R::rlnorm(log(pow(w_Cp_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix2_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+(w_new-w_Cp_fix2_old(j,k))*P_fix2_est(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_new(i,j)+(y(i,j)==-1)*PCm_kernel_old(i,j)-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_old(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cp_fix2_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_Cp_fix2_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix2_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cp_fix2_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cp_fix2_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_fix2_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix2_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix2_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w2++;
            w_Cp_fix2_old(j,k)=w_new;
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }else if (C_fix2_old(j,k)==-1){
          count_w2++;
          w_new=R::rlnorm(log(pow(w_Cm_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix2_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+(w_new-w_Cm_fix2_old(j,k))*P_fix2_est(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_old(i,j)+(y(i,j)==-1)*PCm_kernel_new(i,j)-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_new(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cm_fix2_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_Cm_fix2_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_fix2_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix2_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix2_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cm_fix2_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cm_fix2_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_fix2_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix2_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix2_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w2++;
            w_Cm_fix2_old(j,k)=w_new;
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }
      }
    }
    //update w_B_fix1;
    for (j=0;j<p;j++){
      for (k=0;k<fix1K;k++){
        if (B_fix1_old(j,k)==1){
          count_w2++;
          w_new=R::rlnorm(log(pow(w_B_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_B_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix1_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PB_kernel_new(i,j)=PB_kernel_old(i,j)+(w_new-w_B_fix1_old(j,k))*P_fix1(i,k);
            ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
          }
          lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_B_fix1_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_B_fix1_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_B_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix1_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_B_fix1_old(j,k)),0,w_sig,1)+R::dlnorm(w_B_fix1_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_B_fix1_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_B_fix1_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_B_fix1_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w2++;
            w_B_fix1_old(j,k)=w_new;
            PB_kernel_old.col(j)=PB_kernel_new.col(j);
            ll_z_old.col(j)=ll_z_new.col(j);
          }
        }
      }
    }
    //update w_C_fix1;
    for (j=0;j<q;j++){
      for (k=0;k<fix1K;k++){
        if (C_fix1_old(j,k)==1){
          count_w2++;
          w_new=R::rlnorm(log(pow(w_Cp_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix1_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+(w_new-w_Cp_fix1_old(j,k))*P_fix1(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_new(i,j)+(y(i,j)==-1)*PCm_kernel_old(i,j)-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_old(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cp_fix1_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_Cp_fix1_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix1_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cp_fix1_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cp_fix1_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cp_fix1_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cp_fix1_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cp_fix1_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w2++;
            w_Cp_fix1_old(j,k)=w_new;
            PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }else if (C_fix1_old(j,k)==-1){
          count_w2++;
          w_new=R::rlnorm(log(pow(w_Cm_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix1_old(j,k)+pow(10,-4),2)+1)));
          for (i=0;i<n;i++){
            PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+(w_new-w_Cm_fix1_old(j,k))*P_fix1(i,k);
            ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_old(i,j)+(y(i,j)==-1)*PCm_kernel_new(i,j)-logsumexp0(PCp_kernel_old(i,j),PCm_kernel_new(i,j));
          }
          lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dgamma(w_new,1,w_sig,1)-R::dgamma(w_Cm_fix1_old(j,k)+pow(10,-4),1,w_sig,1)+R::dlnorm(w_Cm_fix1_old(j,k)+pow(10,-4),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_fix1_old(j,k)+pow(10,-4),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix1_old(j,k)+pow(10,-4),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix1_old(j,k)+pow(10,-4),2)+1)),1);
          //lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(log(w_new),0,w_sig,1)-R::dnorm4(log(w_Cm_fix1_old(j,k)),0,w_sig,1)+R::dlnorm(w_Cm_fix1_old(j,k),log(pow(w_new,2)/sqrt(pow(w_sd,2)+pow(w_new,2))),sqrt(log(pow(w_sd,2)/pow(w_new,2)+1)),1)-R::dlnorm(w_new,log(pow(w_Cm_fix1_old(j,k),2)/sqrt(pow(w_sd,2)+pow(w_Cm_fix1_old(j,k),2))),sqrt(log(pow(w_sd,2)/pow(w_Cm_fix1_old(j,k),2)+1)),1);
          if (lr>log(R::runif(0,1))){
            ac_w2++;
            w_Cm_fix1_old(j,k)=w_new;
            PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
            ll_y_old.col(j)=ll_y_new.col(j);
          }
        }
      }
    }
    
    //update zeta
    for (j=0;j<p;j++){
      count_zeta2++;
      zeta_new=R::rnorm(zeta_old(j),zeta_sd);
      //zeta_new=-5;//!!!!
      for (i=0;i<n;i++){
        PB_kernel_new(i,j)=PB_kernel_old(i,j)+zeta_new-zeta_old(j);
        ll_z_new(i,j)=z(i,j)*PB_kernel_new(i,j)-logsumexp0(PB_kernel_new(i,j));
      }
      lr = sum(ll_z_new.col(j))-sum(ll_z_old.col(j))+R::dnorm4(zeta_new,log(1.0/99),zeta_sig,1)-R::dnorm4(zeta_old(j),log(1.0/99),zeta_sig,1);
      if (lr>log(R::runif(0,1))){
        ac_zeta2++;
        zeta_old(j)=zeta_new;
        PB_kernel_old.col(j)=PB_kernel_new.col(j);
        ll_z_old.col(j)=ll_z_new.col(j);
      }
    }
    //update etap, etam
    for (j=0;j<q;j++){
      count_eta2++;
      etap_new = R::rnorm(etap_old(j),etap_sd);
      etam_new = R::rnorm(etam_old(j),etam_sd);
      //etap_new=-5;//!!!!
      //etam_new=-5;//!!!!
      
      for (i=0;i<n;i++){
        PCp_kernel_new(i,j)=PCp_kernel_old(i,j)+etap_new-etap_old(j);
        PCm_kernel_new(i,j)=PCm_kernel_old(i,j)+etam_new-etam_old(j);
        ll_y_new(i,j)=(y(i,j)==1)*PCp_kernel_new(i,j)+(y(i,j)==-1)*PCm_kernel_new(i,j)-logsumexp0(PCp_kernel_new(i,j),PCm_kernel_new(i,j));
      }
      lr = sum(ll_y_new.col(j))-sum(ll_y_old.col(j))+R::dnorm4(etap_new,log(1.0/198),eta_sig,1)-R::dnorm4(etap_old(j),log(1.0/198),eta_sig,1)+R::dnorm4(etam_new,log(1.0/198),eta_sig,1)-R::dnorm4(etam_old(j),log(1.0/198),eta_sig,1);
      if (lr>log(R::runif(0,1))){
        ac_eta2++;
        etap_old(j)=etap_new;
        etam_old(j)=etam_new;
        PCp_kernel_old.col(j)=PCp_kernel_new.col(j);
        PCm_kernel_old.col(j)=PCm_kernel_new.col(j);
        ll_y_old.col(j)=ll_y_new.col(j);
      }
    }
    
    //update beta
    d=accu(B_old);
    d1=accu(C_old==-1);
    d3=accu(C_old==1);
    d2=K_old*q-d1-d3;
    d1+=pi(0);
    d2+=pi(1);
    d3+=pi(2);
    
    
    beta_old=R::rbeta(a_beta+d,b_beta+p*K_est-d);
    //update gamma
    gamma_old(0)=R::rgamma(d1,1);
    gamma_old(1)=R::rgamma(d2,1);
    gamma_old(2)=R::rgamma(d3,1);
    gamma_old=gamma_old/sum(gamma_old);
    
    ll2(it)=accu(ll_z_old)+accu(ll_y_old);
    
    
    //write
    if (it>=burnin2&&it%thin2==0){
      B.slice(iter)=B_old;
      B_fix1_save.slice(iter)=B_fix1_old;
      B_fix2_save.slice(iter)=B_fix2_old;
      C.slice(iter)=C_old;
      C_fix1_save.slice(iter)=C_fix1_old;
      C_fix2_save.slice(iter)=C_fix2_old;
      w_B.slice(iter)=w_B_old;
      w_B_fix1.slice(iter)=w_B_fix1_old;
      w_B_fix2.slice(iter)=w_B_fix2_old;
      w_Cp.slice(iter)=w_Cp_old;
      w_Cp_fix1.slice(iter)=w_Cp_fix1_old;
      w_Cp_fix2.slice(iter)=w_Cp_fix2_old;
      w_Cm.slice(iter)=w_Cm_old;
      w_Cm_fix1.slice(iter)=w_Cm_fix1_old;
      w_Cm_fix2.slice(iter)=w_Cm_fix2_old;
      zeta.col(iter)=zeta_old;
      etap.col(iter)=etap_old;
      etam.col(iter)=etam_old;
      beta(iter)=beta_old;
      gamma.col(iter)=Rcpp::as<arma::vec>(gamma_old);
      iter++;
    }
  }
  ac_w2/=count_w2;
  ac_zeta2/=count_zeta2;
  ac_eta2/=count_eta2;
  
  arma::mat B_rate=mean(B,2);
  arma::umat B_est=(B_rate>.5);
  arma::mat B_fix1_rate=mean(B_fix1_save,2);
  arma::umat B_fix1_est=(B_fix1_rate>.5);
  arma::mat B_fix2_rate=mean(B_fix2_save,2);
  arma::umat B_fix2_est=(B_fix2_rate>.5);
  arma::ucube C_tmp = (C==1);
  arma::mat Cp_rate=mean(arma::conv_to<arma::cube>::from(C_tmp),2);
  C_tmp = (C==-1);
  arma::mat Cm_rate=mean(arma::conv_to<arma::cube>::from(C_tmp),2);
  arma::cube C_rate=arma::zeros(q,K_est,3);
  C_rate.slice(0)=Cm_rate;
  C_rate.slice(1)=1-Cm_rate-Cp_rate;
  C_rate.slice(2)=Cp_rate;
  arma::umat C_tmp0=index_max(C_rate,2);
  arma::mat C_est=arma::conv_to<arma::mat>::from(C_tmp0)-1;
  C_tmp = (C_fix1_save==1);
  arma::mat Cp_fix1_rate=mean(arma::conv_to<arma::cube>::from(C_tmp),2);
  C_tmp = (C_fix1_save==-1);
  arma::mat Cm_fix1_rate=mean(arma::conv_to<arma::cube>::from(C_tmp),2);
  arma::cube C_fix1_rate=arma::zeros(q,fix1K,3);
  C_fix1_rate.slice(0)=Cm_fix1_rate;
  C_fix1_rate.slice(1)=1-Cm_fix1_rate-Cp_fix1_rate;
  C_fix1_rate.slice(2)=Cp_fix1_rate;
  C_tmp0=index_max(C_fix1_rate,2);
  arma::mat C_fix1_est=arma::conv_to<arma::mat>::from(C_tmp0)-1;
  C_tmp=(C_fix2_save==1);
  arma::mat Cp_fix2_rate=mean(arma::conv_to<arma::cube>::from(C_tmp),2);
  C_tmp=(C_fix2_save==-1);
  arma::mat Cm_fix2_rate=mean(arma::conv_to<arma::cube>::from(C_tmp),2);
  arma::cube C_fix2_rate=arma::zeros(q,fix2K,3);
  C_fix2_rate.slice(0)=Cm_fix2_rate;
  C_fix2_rate.slice(1)=1-Cm_fix2_rate-Cp_fix2_rate;
  C_fix2_rate.slice(2)=Cp_fix2_rate;
  C_tmp0=index_max(C_fix2_rate,2);
  arma::mat C_fix2_est=arma::conv_to<arma::mat>::from(C_tmp0)-1;
  
  
  
  arma::mat w_B_est=mean(w_B,2);
  w_B_est = w_B_est%B_est;
  arma::mat w_B_fix1_est=mean(w_B_fix1,2);
  w_B_fix1_est=w_B_fix1_est%B_fix1_est;
  arma::mat w_B_fix2_est=mean(w_B_fix2,2);
  w_B_fix2_est=w_B_fix2_est%B_fix2_est;
  arma::mat w_Cp_est=mean(w_Cp,2);
  w_Cp_est=w_Cp_est%(C_est==1);
  arma::mat w_Cp_fix1_est=mean(w_Cp_fix1,2);
  w_Cp_fix1_est=w_Cp_fix1_est%(C_fix1_est==1);
  arma::mat w_Cp_fix2_est=mean(w_Cp_fix2,2);
  w_Cp_fix2_est=w_Cp_fix2_est%(C_fix2_est==1);
  arma::mat w_Cm_est=mean(w_Cm,2);
  w_Cm_est=w_Cm_est%(C_est==-1);
  arma::mat w_Cm_fix1_est=mean(w_Cm_fix1,2);
  w_Cm_fix1_est=w_Cm_fix1_est%(C_fix1_est==-1);
  arma::mat w_Cm_fix2_est=mean(w_Cm_fix2,2);
  w_Cm_fix2_est=w_Cm_fix2_est%(C_fix2_est==-1);
  arma::vec zeta_est=mean(zeta,1);
  arma::vec etap_est=mean(etap,1);
  arma::vec etam_est=mean(etam,1);
  double beta_est=mean(beta);
  arma::vec gamma_est=mean(gamma,1);
  
  return Rcpp::List::create(
    Rcpp::List::create(
      Rcpp::Named("P_est")=P_est,
      Rcpp::Named("P_fix2_est")=P_fix2_est,
      Rcpp::Named("B_est")=B_est,
      Rcpp::Named("B_rate")=B_rate,
      Rcpp::Named("B_fix1_est")=B_fix1_est,
      Rcpp::Named("B_fix1_rate")=B_fix1_rate,
      Rcpp::Named("B_fix2_est")=B_fix2_est,
      Rcpp::Named("B_fix2_rate")=B_fix2_rate,
      Rcpp::Named("C_est")=C_est,
      Rcpp::Named("C_rate")=C_rate,
      Rcpp::Named("C_fix1_est")=C_fix1_est,
      Rcpp::Named("C_fix1_rate")=C_fix1_rate,
      Rcpp::Named("C_fix2_est")=C_fix2_est,
      Rcpp::Named("C_fix2_rate")=C_fix2_rate,
      Rcpp::Named("K_est")=K_est,
      Rcpp::Named("K_freq")=K_freq,
      Rcpp::Named("K")=K,
      Rcpp::Named("P")=P,
      Rcpp::Named("P_fix2")=P_fix2),
      Rcpp::List::create(
        Rcpp::Named("w_B_est")=w_B_est,
        Rcpp::Named("w_B_fix1_est")=w_B_fix1_est,
        Rcpp::Named("w_B_fix2_est")=w_B_fix2_est,
        Rcpp::Named("w_Cp_est")=w_Cp_est,
        Rcpp::Named("w_Cp_fix1_est")=w_Cp_fix1_est,
        Rcpp::Named("w_Cp_fix2_est")=w_Cp_fix2_est,
        Rcpp::Named("w_Cm_est")=w_Cm_est,
        Rcpp::Named("w_Cm_fix1_est")=w_Cm_fix1_est,
        Rcpp::Named("w_Cm_fix2_est")=w_Cm_fix2_est),
        Rcpp::List::create(
          Rcpp::Named("ac_w")=ac_w,
          Rcpp::Named("ac_zeta")=ac_zeta,
          Rcpp::Named("ac_eta")=ac_eta,
          Rcpp::Named("ll")=ll,
          Rcpp::Named("ll2")=ll2,
          Rcpp::Named("ll0")=ll0,
          Rcpp::Named("ac_w2")=ac_w2,
          Rcpp::Named("ac_zeta2")=ac_zeta2,
          Rcpp::Named("ac_eta2")=ac_eta2,
          Rcpp::Named("beta_est")=beta_est,
          Rcpp::Named("gamma_est")=gamma_est,
          Rcpp::Named("zeta_est")=zeta_est,
          Rcpp::Named("etap_est")=etap_est,
          Rcpp::Named("etam_est")=etam_est
        )
  );
}




