#ifndef MODSTRING_H
#define MODSTRING_H

arma::umat sub(int n,arma::uvec v);

arma::umat my_permutations(int n);

arma::mat hamming_matrix(arma::mat x);

double hamming_perm (arma::urowvec perm, arma::mat z, arma::mat zp);

arma::vec hamming_vec_matrix(arma::mat z, arma::mat zp, arma::uvec ind);

arma::vec hamming_vec_matrix(arma::vec z, arma::mat zp);

double Dist_perm(arma::mat z, arma::mat zp);

arma::vec Dist_perm_PBC(arma::mat z, arma::mat zp,arma::mat a,arma::mat ap,arma::mat b,arma::mat bp);

arma::urowvec Dist_perm_K(arma::mat z, arma::mat zp,int K);

double Dist_seq(arma::mat z, arma::mat zp);

Rcpp::List Dist_seq_ord(arma::mat z, arma::mat zp);

arma::rowvec Dist(arma::mat z, arma::cube za, arma::uword flag);

arma::uword MAP(arma::cube z);

arma::vec K_FREQ(arma::vec K);

arma::uvec my_OR(arma::rowvec x, arma::rowvec y);

arma::uvec my_NAND(arma::rowvec x, arma::uvec y);
arma::uvec my_NAND(arma::rowvec x, arma::rowvec y);
int rcateg(Rcpp::NumericVector prob);

arma::vec rcateg(int n, Rcpp::NumericVector prob);

double logsumexp(double x,double y);

double logsumexp(double x,double y,double z);

double logsumexp0(double x);

double logsumexp0(double x,double y);

#endif
