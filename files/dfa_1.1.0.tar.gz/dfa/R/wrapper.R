#' Categorical matrix factorization via double feature allocation with prior information
#' 
#' `DFA` returns the posterior samples and estimates of DFA parameters. 
#' 
#' This function implements the MCMC algorithm for posterior inference with double feature allocation model. 
#' It essentially factorizes a categorical matrix into two low dimensional latent matrices. 
#' Prior information of the latent matrices is incorporated when the optional parameters are provided.
#' It takes less than 5 minutes to run on a laptop for 300 observations, 50 variables and 5000 MCMC iterations.
#' 
#' @param y categorical matrix with entries -1, 0 or 1
#' @param z binary matrix with entries 0 or 1
#' @param N number of MCMC iterations
#' @param burnin number of iterations discarded as burn-in
#' @param thin keep every thin-th MCMC samples. 
#' @param P_fix1 (optional) n by K1 binary matrix of fixed patient-disease relationships. P_fix1[i,k] = 1 iff patient i has disease k
#' @param B_fix1 (optional) p by K1 binary matrix of fixed symptom-disease relationships. B_fix1[j,k] = 1 iff binary symptom j is related to disease k
#' @param C_fix1 (optional) q by K1 categorical matrix of fixed symptom-disease relationships. C_fix1[j,k] = 1 or -1 iff ternary symptom j is related to disease k
#' @param B_fix2,C_fix2 (optional)  similar to B_fix1 and C_fix1 except that there are no known associated patient-disease relationships.
#' @return List of posterior samples and estimates of DFA parameters. The definition of each parameter is defined in the paper ``Bayesian Double Feature Allocation for Phenotyping with Electronic Health Records" arXiv:1809.08988
#' @export

DFA <- function(y=NULL, z=NULL,  N=1000, burnin=0, thin=1, P_fix1=NULL, B_fix1=NULL, B_fix2=NULL, C_fix1=NULL, C_fix2=NULL){
  if (is.null(y)&&is.null(z)){
    stop("Error: one of y or z has to be non-null.")
  }
  if (is.null(P_fix1)){
    if (is.null(z)){
      return (dfa_without_prior_ternary(as.matrix(y), N, burnin, thin))
    }else if (is.null(y)){
      return (dfa_without_prior_binary(as.matrix(z), N, burnin, thin))
    }else{
      return (dfa_without_prior(as.matrix(y), as.matrix(z), N, burnin, thin))
    }
  }else{
    if (is.null(z)){
      return (dfa_with_prior_ternary(as.matrix(y), P_fix1, C_fix1, C_fix2, N, burnin, thin))
    }else if (is.null(y)){
      return (dfa_with_prior_binary(as.matrix(z), P_fix1, B_fix1, B_fix2, N, burnin, thin))
    }else{
      return (dfa_with_prior(as.matrix(y), as.matrix(z), P_fix1, B_fix1, C_fix1, B_fix2, C_fix2, N, burnin, thin))
    }
  }
}
